#if UNITY_EDITOR
using System;
using UnityEngine;
public sealed class WalkthroughRecordingHost:MonoBehaviour {public Action shutdown;void OnDisable(){if(shutdown!=null)shutdown();}}
#endif
