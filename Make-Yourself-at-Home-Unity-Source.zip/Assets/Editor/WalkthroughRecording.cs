using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEditor.Recorder;
using UnityEditor.Recorder.Encoder;
using UnityEditor.Recorder.Input;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ThirdDay;
namespace ThirdDayRecording {
public class WalkthroughRecording {
 const string Output="C:/Users/yxr/Documents/Codex/2026-10-31/clip-ai-x20/outputs/Make-Yourself-at-Home-Full-Walkthrough";
 const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
 [Serializable]class Step{public string time,description,replySource;}
 [Serializable]class Report{public string status="running",current="",error="",ending="",video=Output+".mp4";public int width=1920,height=1080,fps=30;public List<Step> steps=new List<Step>();}
 ApartmentGame g;RecorderController recorder;Report report=new Report();float began,lastSend=-100;bool finished;
 [MenuItem("Third Day/Record Full Walkthrough")]
 public static void StartRun(){if(!EditorApplication.isPlaying)throw new Exception("Play mode required");var driver=new WalkthroughRecording();var host=new GameObject("Walkthrough recording driver").AddComponent<WalkthroughRecordingHost>();host.shutdown=()=>driver.Finish(false);host.StartCoroutine(driver.Monitor());}
 object Get(string name)=>typeof(ApartmentGame).GetField(name,Private).GetValue(g);
 void Set(string name,object value)=>typeof(ApartmentGame).GetField(name,Private).SetValue(g,value);
 void Call(string name,params object[] args)=>typeof(ApartmentGame).GetMethod(name,Private).Invoke(g,args);
 void Check(bool condition,string message){if(!condition)throw new Exception(message);}
 void Mark(string text){report.current=text;report.steps.Add(new Step{time=TimeSpan.FromSeconds(Time.unscaledTime-began).ToString(@"mm\:ss"),description=text,replySource=g.LastReplySource});Write();Debug.Log("[Walkthrough] "+text);}
 void Write(){File.WriteAllText(Output+"-report.json",JsonUtility.ToJson(report,true));}
 IEnumerator Monitor(){
  g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();g.validationMode=true;g.ShowMenu();began=Time.unscaledTime;
  var settings=ScriptableObject.CreateInstance<RecorderControllerSettings>();var movie=ScriptableObject.CreateInstance<MovieRecorderSettings>();movie.name="Full walkthrough";movie.Enabled=true;movie.CaptureAlpha=false;movie.CaptureAudio=true;movie.EncoderSettings=new CoreEncoderSettings{EncodingQuality=CoreEncoderSettings.VideoEncodingQuality.High,Codec=CoreEncoderSettings.OutputCodec.MP4};movie.ImageInputSettings=new GameViewInputSettings{OutputWidth=1920,OutputHeight=1080};movie.OutputFile=Output;settings.AddRecorderSettings(movie);settings.SetRecordModeToManual();settings.FrameRate=30;settings.FrameRatePlayback=FrameRatePlayback.Constant;settings.CapFrameRate=true;recorder=new RecorderController(settings);recorder.PrepareRecording();recorder.StartRecording();
  var stack=new Stack<IEnumerator>();stack.Push(Route());
  while(stack.Count>0){object next=null;bool moved=false;try{moved=stack.Peek().MoveNext();if(moved)next=stack.Peek().Current;else stack.Pop();}catch(Exception e){report.error=e.GetBaseException().ToString();Debug.LogException(e);Finish(false);yield break;}if(!moved)continue;if(next is IEnumerator)stack.Push((IEnumerator)next);else yield return next;}
  Finish(true);
 }
 void Finish(bool success){if(finished)return;finished=true;if(recorder!=null)recorder.StopRecording();report.status=success?"passed":"failed";report.ending=g.state.ending;Write();g.ShowMenu();g.validationMode=false;Debug.Log("[Walkthrough] "+report.status+" / "+report.ending);}
 void OnDestroy(){if(!finished&&recorder!=null){report.error="Recording interrupted";Finish(false);}}
 Button FindButton(string name)=>g.GetComponentsInChildren<Button>().First(b=>b.name==name&&b.gameObject.activeInHierarchy);
 IEnumerator Wait(float seconds,bool followVacuum=false){float until=Time.unscaledTime+seconds;while(Time.unscaledTime<until){if(followVacuum)FollowVacuum();yield return null;}}
 void FollowVacuum(){if(g.TalkingTo!="vacuum")return;var target=g.DevicePosition("vacuum");target.y=g.Player.position.y;if(Vector3.Distance(target,g.Player.position)>1.05f&&Get("playerPath")==null)Set("playerPath",g.Navigation.Path(g.Player.position,target));}
 IEnumerator CloseUI(){if(g.Mode=="talk")Call("CloseTalk",true);else if(g.Mode=="reading")FindButton("收好").onClick.Invoke();yield return Wait(.35f);}
 IEnumerator Walk(Vector3 target){yield return CloseUI();var path=g.Navigation.Path(g.Player.position,target);Check(path!=null,"No walking path to "+target);Set("playerPath",path);Set("afterWalk",null);float until=Time.unscaledTime+50;while(Get("playerPath")!=null&&Time.unscaledTime<until)yield return null;Check(Vector3.Distance(g.Player.position,target)<.3f,"Walking did not reach "+target);yield return Wait(.35f);}
 IEnumerator Object(string id,float read=3){var o=g.Data.objects.First(x=>x.id==id);yield return Walk(new Vector3(o.approach[0],o.floor,-o.approach[1]));Mark("查看："+o.name);if(id=="bed")g.InteractNearest();else g.Inspect(id);yield return Wait(read);yield return CloseUI();}
 IEnumerator Actor(string id){yield return CloseUI();for(int attempt=0;attempt<4;attempt++){var d=g.Data.devices.First(x=>x.id==id);var target=id=="vacuum"?g.Navigation.Nearest(g.DevicePosition(id)):new Vector3(d.approach[0],0,-d.approach[1]);target.y=g.Player.position.y;yield return Walk(target);if(g.InRange(id))break;}g.OpenTalk(id);Check(g.TalkingTo==id,"Cannot interact with "+id);yield return Wait(.3f);var field=g.GetComponentsInChildren<TMP_InputField>().FirstOrDefault(x=>x.gameObject.activeInHierarchy);if(field)field.DeactivateInputField();EventSystem.current.SetSelectedGameObject(null);yield return Wait(1.4f,id=="vacuum");}
 IEnumerator TypeSend(string text){
  bool vacuum=g.TalkingTo=="vacuum";while(Time.unscaledTime-lastSend<11)yield return Wait(.15f,vacuum);
  var field=g.GetComponentsInChildren<TMP_InputField>().FirstOrDefault(x=>x.gameObject.activeInHierarchy);Check(field!=null,"Dialogue input unavailable");field.ActivateInputField();field.text="";
  foreach(char ch in text){field.text+=ch;yield return Wait(.045f);}
  Mark((g.Mode=="dark"?"开灯":g.DeviceName(g.TalkingTo))+" ← "+text);lastSend=Time.unscaledTime;FindButton("发送").onClick.Invoke();field.DeactivateInputField();EventSystem.current.SetSelectedGameObject(null);
  float deadline=Time.unscaledTime+65;while(g.LastReplySource=="pending"&&Time.unscaledTime<deadline)yield return Wait(.1f,vacuum);
  if(g.Mode!="dark"&&g.state.opened&&text!="小灯泡，开灯")Check(g.LastReplySource=="model"||g.LastReplySource=="offline","AI reply failed: "+g.LastAIError);
  yield return Wait(Mathf.Clamp(g.LastSpeech.Length*.085f,3.5f,7),vacuum);
 }
 IEnumerator Say(string id,params string[] lines){yield return Actor(id);foreach(var line in lines){if(g.TalkingTo!=id)yield return Actor(id);yield return TypeSend(line);}yield return CloseUI();}
 IEnumerator Route(){
  Mark("封面 / 开始完整通关录制");yield return Wait(4);FindButton("新游戏").onClick.Invoke();yield return Wait(.5f);
  for(int i=0;i<3;i++){while(Time.unscaledTime-(float)Get("introStarted")<(float)Get("introNextLine")+1.8f)yield return null;Call("HandleIntroClick");yield return Wait(.5f);}
  Check(g.Mode=="dark","Introduction did not reach dark arrival");yield return Wait(6.5f);yield return TypeSend("小灯泡，开灯");Check(g.state.opened,"Opening lights failed");
  Mark("第一天 / 熟悉设备与协作取纸");yield return Object("notice",5);yield return Object("chair");Check(g.Has("chair"),"Chair missing");
  yield return Say("light","照清地上的血迹");yield return Say("vacuum","扫描地上的血迹","别擦血迹，保留现场");Check(g.Has("traceScan"),"Scan missing");
  yield return Object("pothos");yield return Say("waterer","啾啾让你停止浇水","先停止浇水，这是我的决定");Check(g.state.waterStop,"Water did not stop");
  yield return Say("ac","吹干盆底的纸");yield return Object("backup",7);Check(g.Has("notes"),"Paper missing");
  yield return Object("hatch",1);yield return Object("panel",3);Check(g.Has("battery"),"Battery missing");yield return Object("ladder",1);
  yield return Say("speaker","换舒缓的音乐");yield return Object("bed",4);Check(g.state.day==2,"First-day rest failed");
  Mark("第二天 / 原始记录与独立授权");
  yield return Say("light","周岚那晚走过哪里？","保留记录并授权给知秋");
  yield return Say("lock","那晚的原始门禁记录","把原始记录授权给知秋");
  yield return Say("mirror","想核实那晚有没有人被困","只展示时间和人数给知秋");
  yield return Say("fridge","周岚最后的订单");yield return Say("tv","现在对照原始记录");Check(g.Has("timeline"),"Original timeline missing");
  yield return Say("vacuum","充电座后面的钢片");Check(g.Has("steel"),"Steel missing");
  Call("OpenNotebook");yield return Wait(3);FindButton("设备").onClick.Invoke();yield return Wait(3);FindButton("动态").onClick.Invoke();yield return Wait(3);yield return CloseUI();
  yield return Object("bed",4);Check(g.state.day==3,"Second-day rest failed");
  Mark("第三天 / 降噪接线与广播");yield return Say("vacuum","短螺丝刀和垫圈");Check(g.Has("tools"),"Tools missing");
  yield return Say("ac","把风小一点");yield return Say("speaker","把白管的线接上","备用电供广播","录下陈实的姓名和1907房间号","把录音发出去");Check(g.Has("sent"),"Broadcast failed");
  Mark("第三天 / 现场证明与机械开门");yield return Say("mirror","授权把必要的存在证明交给老扣和大呼");Check(g.Has("liveProof"),"Live proof missing");
  yield return Say("lock","请用现场证明机械复核","用垫圈垫稳椅子短腿","踩着椅子揭开门框盖板找红绳","用钢片顶住锈处，再拉红绳并压下把手");Check(g.Has("open"),"Mechanical release failed");
  yield return Object("door",4);Check(g.Has("escaped"),"Exit failed");yield return Say("speaker","出来了，末尾加上这句");Check(g.Has("last"),"Final voice confirmation missing");
  yield return Object("hatch",1);yield return Object("printer",5);Check(g.Has("offline"),"Offline receipt missing");yield return Object("pullLamp",1);Check(g.state.ending=="canon","Canonical ending not reached");
  Mark("正式结局 / 灯一直亮着");yield return Wait(12);
  var endingScroll=g.GetComponentsInChildren<ScrollRect>().FirstOrDefault();if(endingScroll){endingScroll.verticalNormalizedPosition=.5f;yield return Wait(7);endingScroll.verticalNormalizedPosition=0;yield return Wait(7);}Check(g.Mode=="end","Ending UI interrupted");
 }
}
}
