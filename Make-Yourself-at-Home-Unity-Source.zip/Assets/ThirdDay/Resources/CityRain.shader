Shader "ThirdDay/City Rain"
{
    Properties { _RainColor("Rain colour", Color) = (.48,.53,.60,1) }
    SubShader
    {
        Tags { "Queue"="Transparent+100" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" }
        Pass
        {
            Tags { "LightMode"="SRPDefaultUnlit" }
            Blend SrcAlpha OneMinusSrcAlpha
            Cull Off
            ZWrite Off
            ZTest Always
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            struct Attributes
            {
                float4 positionOS : POSITION;
                float2 corner : TEXCOORD0;
                float2 seed : TEXCOORD1;
                float4 profile : TEXCOORD2;
            };
            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float3 rayOriginWS : TEXCOORD0;
                float2 corner : TEXCOORD1;
                half opacity : TEXCOORD2;
            };
            CBUFFER_START(UnityPerMaterial)
                half4 _RainColor;
            CBUFFER_END

            Varyings vert(Attributes v)
            {
                Varyings o;
                float phase = frac(v.seed.y + _Time.y * v.profile.z);
                float wind = .105 + sin(_Time.y * .31) * .025;
                float aspect = _ScreenParams.x / _ScreenParams.y;
                float2 centre = float2(v.seed.x * 1.12 - .06 + phase * wind / aspect,
                                      1.08 - phase * 1.16);
                float2 offset = float2(v.corner.x * v.profile.x - v.corner.y * v.profile.y * wind,
                                       v.corner.y * v.profile.y);
                offset.x /= aspect;
                float2 screen = centre + offset;
                float3 positionVS = float3((screen * 2 - 1) * unity_OrthoParams.xy, -2);
                o.rayOriginWS = mul(UNITY_MATRIX_I_V, float4(positionVS, 1)).xyz;
                o.positionCS = TransformWorldToHClip(o.rayOriginWS);
                o.corner = v.corner;
                o.opacity = v.profile.w;
                return o;
            }

            bool HitsRoom(float3 origin, float3 inverseDirection, float3 low, float3 high)
            {
                float3 a = (low - origin) * inverseDirection;
                float3 b = (high - origin) * inverseDirection;
                float3 entry = min(a, b), exit = max(a, b);
                return min(exit.x, min(exit.y, exit.z)) >= max(0, max(entry.x, max(entry.y, entry.z)));
            }

            half4 frag(Varyings i) : SV_Target
            {
                // Shield the cutaway apartments along the actual camera ray,
                // so rain never crosses the rooms even when the view follows a
                // character, zooms for dialogue, or visits the equipment room.
                float3 direction = -UNITY_MATRIX_V[2].xyz;
                float3 inv = rcp(direction);
                if (HitsRoom(i.rayOriginWS, inv, float3(-.18,-.85,-13.18), float3(18.18,2.95,.18)) ||
                    HitsRoom(i.rayOriginWS, inv, float3(-.30,-8.9,-13.1), float3(18.1,-4.7,.22)) ||
                    HitsRoom(i.rayOriginWS, inv, float3(0,-16.5,-13.35), float3(18.4,-12.3,.1)) ||
                    HitsRoom(i.rayOriginWS, inv, float3(-.30,-24.1,-13.1), float3(18.1,-19.9,.22)) ||
                    HitsRoom(i.rayOriginWS, inv, float3(-2.8,-.4,-12.65), float3(.02,1.15,-5.35)) ||
                    HitsRoom(i.rayOriginWS, inv, float3(21.75,-5.15,-7.25), float3(27.25,-1.8,-1.75))) discard;
                half edge = saturate((.5 - abs(i.corner.x)) * 3);
                half ends = saturate((.5 - abs(i.corner.y)) * 5);
                return half4(_RainColor.rgb, edge * ends * i.opacity * _RainColor.a);
            }
            ENDHLSL
        }
    }
}
