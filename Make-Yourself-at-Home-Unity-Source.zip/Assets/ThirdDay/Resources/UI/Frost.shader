Shader "ThirdDay/UI Frost" {
 Properties { _Opacity("Opacity",Range(0,1))=1  [PerRendererData] _MainTex("Texture",2D)="white"{} _StencilComp("Stencil Comparison",Float)=8 _Stencil("Stencil ID",Float)=0 _StencilOp("Stencil Operation",Float)=0 _StencilWriteMask("Stencil Write Mask",Float)=255 _StencilReadMask("Stencil Read Mask",Float)=255 _ColorMask("Color Mask",Float)=15 }
 SubShader { Tags {"Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" "IgnoreProjector"="True"}
 Stencil { Ref [_Stencil] Comp [_StencilComp] Pass [_StencilOp] ReadMask [_StencilReadMask] WriteMask [_StencilWriteMask] }
 Cull Off ZWrite Off ZTest [unity_GUIZTestMode] Blend SrcAlpha OneMinusSrcAlpha ColorMask [_ColorMask]
 Pass { HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 struct appdata {float4 vertex:POSITION;float4 color:COLOR;};struct v2f {float4 vertex:SV_POSITION;float4 color:COLOR;float4 screen:TEXCOORD0;};
 float _Opacity;
 sampler2D _CameraOpaqueTexture;float4 _CameraOpaqueTexture_TexelSize;
 v2f vert(appdata v){v2f o;o.vertex=UnityObjectToClipPos(v.vertex);o.screen=ComputeScreenPos(o.vertex);o.color=v.color;return o;}
 half4 frag(v2f i):SV_Target {float2 uv=i.screen.xy/i.screen.w;float2 d=_CameraOpaqueTexture_TexelSize.xy*7;half3 c=tex2D(_CameraOpaqueTexture,uv).rgb*.2;c+=(tex2D(_CameraOpaqueTexture,uv+d).rgb+tex2D(_CameraOpaqueTexture,uv-d).rgb+tex2D(_CameraOpaqueTexture,uv+float2(d.x,-d.y)).rgb+tex2D(_CameraOpaqueTexture,uv+float2(-d.x,d.y)).rgb)*.2;c=lerp(dot(c,half3(.2126,.7152,.0722)).xxx,c,.6);return half4(lerp(c,i.color.rgb,i.color.a),_Opacity);}
 ENDHLSL }
 }}
