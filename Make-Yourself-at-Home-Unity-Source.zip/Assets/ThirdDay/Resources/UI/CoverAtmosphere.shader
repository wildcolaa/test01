Shader "ThirdDay/UI Cover Atmosphere" {
 SubShader {
 Tags {"Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline"}
 Cull Off ZWrite Off ZTest Always Blend SrcAlpha OneMinusSrcAlpha
 Pass { HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 struct a {float4 vertex:POSITION;float2 uv:TEXCOORD0;float4 color:COLOR;};
 struct v {float4 vertex:SV_POSITION;float2 uv:TEXCOORD0;float4 color:COLOR;};
 v vert(a i){v o;o.vertex=UnityObjectToClipPos(i.vertex);o.uv=i.uv;o.color=i.color;return o;}
 half4 frag(v i):SV_Target {
 float left=1-smoothstep(.20,.73,i.uv.x);
 float edge=pow(saturate(length((i.uv-.5)*float2(1.1,1.4))),2);
 return half4(half3(.009,.012,.018),saturate(.12+left*.80+edge*.22)*i.color.a);
 }
 ENDHLSL }
 }
}
