Shader "ThirdDay/UI Cover Hover Frost" {
 Properties { [PerRendererData] _MainTex("Texture",2D)="white"{} }
 SubShader { Tags {"Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline"}
 Cull Off ZWrite Off ZTest Always Blend SrcAlpha OneMinusSrcAlpha
 Pass { HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 struct a {float4 vertex:POSITION;float4 color:COLOR;};
 struct v {float4 vertex:SV_POSITION;float4 color:COLOR;float4 screen:TEXCOORD0;};
 sampler2D _CameraOpaqueTexture;float4 _CameraOpaqueTexture_TexelSize;
 v vert(a i){v o;o.vertex=UnityObjectToClipPos(i.vertex);o.screen=ComputeScreenPos(o.vertex);o.color=i.color;return o;}
 half4 frag(v i):SV_Target {
 clip(i.color.a-.001);float2 uv=i.screen.xy/i.screen.w;
 float2 d=_CameraOpaqueTexture_TexelSize.xy*9;
 half3 c=tex2D(_CameraOpaqueTexture,uv).rgb*.2;
 c+=(tex2D(_CameraOpaqueTexture,uv+d).rgb+tex2D(_CameraOpaqueTexture,uv-d).rgb+tex2D(_CameraOpaqueTexture,uv+float2(d.x,-d.y)).rgb+tex2D(_CameraOpaqueTexture,uv+float2(-d.x,d.y)).rgb)*.2;
 c=lerp(dot(c,half3(.2126,.7152,.0722)).xxx,c,.25);
 return half4(lerp(c,half3(.11,.125,.15),.64),i.color.a*.91);
 }
 ENDHLSL }
 }
}
