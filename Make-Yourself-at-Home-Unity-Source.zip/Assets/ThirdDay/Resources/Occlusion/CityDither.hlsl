#ifndef THIRD_DAY_DITHER
#define THIRD_DAY_DITHER
float _ThirdDayVisibility;
void ThirdDayDither(float2 pixel) {
 const float threshold[16]={0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5};
 uint2 p=(uint2)floor(pixel)%4;
 clip(_ThirdDayVisibility-(threshold[p.y*4+p.x]+.5)/16);
}
#endif
