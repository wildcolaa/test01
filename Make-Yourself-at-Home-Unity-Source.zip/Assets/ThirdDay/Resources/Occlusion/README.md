ApartmentOccluder.shader and the five render pass HLSL files are adapted from Unity URP 17.3, package com.unity.render-pipelines.universal (37e06a5b08b3). Original lighting, texture handling, output signatures and shader variants are retained. Each render pass adds ThirdDayDither from CityDither.hlsl. The runtime only assigns this shader to the original eight Occluder roots.

See LICENSE.md for the original Unity package license. Regenerate the adapted shader files with work/create-occlusion-shader.mjs when updating URP, and recheck rendering in Unity.
