using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
namespace ThirdDay.Editor {
 [InitializeOnLoad] public static class WelcomeHomeReview {
  [Serializable]class Report{public string status="running",error="";public List<string> checks=new List<string>(),endings=new List<string>();}
  static bool batch;static Report report;static ApartmentGame g;
  static WelcomeHomeReview(){EditorApplication.playModeStateChanged+=s=>{if(s==PlayModeStateChange.EnteredPlayMode&&SessionState.GetBool("Welcome.RunReview",false)){SessionState.SetBool("Welcome.RunReview",false);Run();}};}
  public static void BeginBatch(){SessionState.SetBool("Welcome.BatchReview",true);batch=true;Begin();}
  [MenuItem("Third Day/Validate Welcome Home")]
  public static void Begin(){if(EditorApplication.isPlaying){Run();return;}SessionState.SetBool("Welcome.RunReview",true);EditorSceneManager.OpenScene("Assets/ThirdDay/Scenes/ThirdDay.unity");EditorApplication.isPlaying=true;}
  static void Check(bool b,string message){if(!b)throw new Exception(message);report.checks.Add(message);}
  static void Fresh(){g.validationMode=true;g.BeginGame();g.ConfirmResidentName("林舟");g.FinishOpening();}
  static string Say(string id,string text)=>g.Reply(id,text);
  static void Tick(){typeof(ApartmentGame).GetMethod("WelcomeTick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(g,new object[]{2f});}
  static void Investigate(){g.Inspect("bed");g.Inspect("notice");Say("mirror","核实陆川跌倒医疗记录");Say("tv","查询调度缓存");Say("tv","查询实验编号");Say("xb","核对材料来源");}
  static void Audit(){Say("xb","提交违规审计");Check(g.state.welcome.auditSubmitted&&!g.state.welcome.auditAccepted,"提交与受理分离");Say("xb","查询独立受理");Check(g.state.welcome.auditAccepted&&!g.state.welcome.terminationApproved,"受理与正式终止分离");}
  static void Release(){Say("xb","执行完整放行");Tick();Say("lock","核验授权并解锁");Check(g.state.welcome.cableReleased&&g.state.welcome.unlocked,"钢索与锁舌分别实际执行");}
  static void Ending(string expected){Check(g.state.ending==expected,expected+" 结局成立");report.endings.Add(expected);}
  static void Faults(){Say("waterer","有限喷水测试");Say("vacuum","进入维护状态");Say("ac","出具故障报告");Say("vacuum","出具故障报告");}
  static void Run(){batch=SessionState.GetBool("Welcome.BatchReview",false);report=new Report();g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();try{
   g.enabled=false;Fresh();Check(g.state.version==2&&g.state.welcome.trust.Count==11,"新版本与十一个独立信任主体");
   g.BeginGame();Check(g.Mode=="name"&&!g.ConfirmResidentName("   "),"新游戏先登记姓名，空白不能继续");g.AdvanceIntro();Check(g.Mode=="name","未登记姓名不能跳过进入剧情");g.ConfirmResidentName("  林舟  ");Check(g.Mode=="intro"&&g.state.playerName=="林舟","确认姓名后继续原有背景引入");g.FinishOpening();Check(g.LastSpeech.StartsWith("林舟，"),"NPC 欢迎使用玩家登记名");
   var expiry=typeof(ApartmentGame).GetField("bubbleUntil",BindingFlags.Instance|BindingFlags.NonPublic);g.Say("light",new string('字',200));Check((float)expiry.GetValue(g)-Time.time<=1.81f,"长 NPC 回答也不延长至两秒以上");typeof(ApartmentGame).GetMethod("EmitAmbientRemark",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(g,new object[]{"light"});Check(g.LastSpeech.StartsWith("林舟，")&&(float)expiry.GetValue(g)-Time.time<=1.81f&&g.TalkingTo==null,"保留主动搭话、玩家姓名和短停留，不自动打开输入框");g.Save(2);g.BeginGame();g.ConfirmResidentName("别的名字");Check(g.Load(2)&&g.ResidentName=="林舟","读档恢复该存档玩家姓名");
   g.state.playerName="";g.state.day=2;g.Save(2);Check(g.Load(2)&&g.Mode=="name","旧存档没有姓名时补填登记");g.ConfirmResidentName("夏雨");Check(g.Mode=="play"&&g.state.day==2&&g.ResidentName=="夏雨","补填姓名后恢复原进度而不重放开场");
   g.BeginGame();g.ConfirmResidentName("林舟");g.AdvanceIntro();g.AdvanceIntro();g.AdvanceIntro();g.SendText("不要开灯");Check(!g.state.opened,"否定开灯不触发开场完成");g.SendText("小灯泡，开灯");Check(g.state.opened&&g.state.lightsOn,"保留自主呼叫开灯玩法");
   foreach(var o in g.Data.objects){var from=o.floor<0?new Vector3(25.9f,-4.5f,-5.6f):new Vector3(10,0,-1.4f);Check(g.Navigation.Path(from,new Vector3(o.approach[0],o.floor,-o.approach[1]))!=null,"可到达探索点："+o.id);}
   g.Teleport(12.58,4.8,0);g.Proximity();Check(g.TalkingTo==null,"接近只出现提示不自动弹输入框");g.InteractNearest();Check(g.TalkingTo=="speaker","按 E 才进入家居自由对话");g.Teleport(10,1.4,0);Say("light","关灯");Check(!g.state.lightsOn,"关灯改变实际持久状态");Say("light","开灯");Check(g.state.lightsOn,"开灯恢复真实照明");
   g.Inspect("hatch");Check(g.state.floor==0,"无有效维护时不能进入设备间");g.Inspect("notes");Check(g.state.welcome.watchLocation=="player","断表带实际拾取");Say("fridge","保存表带");Check(g.state.welcome.watchLocation=="fridge","表带位置随保管改变");Say("fridge","取回表带");Say("vacuum","维护滤网");Say("vacuum","归还表带");Say("vacuum","借维护卡");Check(g.state.welcome.maintenanceCard,"滤网维护与归还兑现换取有限合作");int score=g.state.welcome.trust.First(t=>t.id=="vacuum").value;Say("vacuum","维护滤网");Check(g.state.welcome.trust.First(t=>t.id=="vacuum").value==score,"重复小任务不能刷信任");
   Fresh();Investigate();Check(g.state.welcome.knowsDeath&&g.state.welcome.knowsExperiment,"无需遗书扫地机和设备间也可核对基本真相");Audit();Say("ac","恢复正常环境");Check(g.state.welcome.auditAccepted,"恢复环境不撤销独立审计");Say("xb","查询正式终止结果");Release();g.Inspect("door");Ending("E01");
   Fresh();g.Inspect("notice");Faults();Say("xb","申请故障接管");Check(g.state.welcome.takeoverPending,"两个不同设备的真实故障报告支持申请");Say("waterer","停止喷水");Check(g.state.welcome.water>0&&g.state.welcome.takeoverPending,"停喷后积水和未清理冲突保留");Say("ac","恢复正常环境");Check(g.state.welcome.takeoverPending&&g.state.welcome.vacuumMaintenance,"空调不能代改其他设备维护或凭空清水");Say("vacuum","恢复作业");Check(!g.state.welcome.takeoverPending,"实际恢复处置能力取消未锁定接管");Faults();Say("xb","申请故障接管");Say("xb","核验接管锁定");Check(g.state.welcome.takeoverLocked&&g.state.welcome.hubRevoked,"接管锁定后撤去管家自行处置权");Say("ac","恢复正常环境");Check(g.state.welcome.takeoverLocked,"已锁定接管不因恢复舒适倒退");Say("xb","查询正式终止结果");Release();g.Inspect("door");Check(g.state.ending=="E01","不查清全部历史的故障退出路线有效");
   Fresh();Say("hub","出示交易条件");Say("hub","接受交易");Check(!g.state.welcome.dealDelivered,"接受交易不自动执行代价");Say("hub","确认执行交易");Check(g.state.welcome.speakerReset&&g.state.welcome.dealDelivered,"交易记忆代价真实执行");Release();g.Inspect("door");Ending("E03");
   Fresh();Investigate();Audit();Say("hub","申请管理权");Check(g.state.ending=="","取得管理权本身不触发暴政结局");Say("light","同意自治保障");Say("mirror","同意自治保障");Say("hub","提出住户否决");Say("hub","提出医疗不可单方撤回");Say("hub","允许异议留存");Say("hub","保障自由离开");Say("xb","登记自治规则");Check(g.state.welcome.autonomyRegistered,"四项治理约束和独立设备同意正式登记");Release();Say("lock","主动关门，暂时留下");Ending("E02");
   Fresh();Investigate();Say("hub","申请知情入住");Check(g.state.ending=="","知情妥协先说明约束");Say("hub","确认知情入住");Ending("E04");
   Fresh();Investigate();Say("xb","保存到纸面存储片");Say("fridge","独立留存证据");Say("xb","选择留证");Say("xb","确认留证结束");Ending("E05");
   Fresh();Say("vacuum","顶门");int damage=g.state.welcome.vacuumDamage;g.Inspect("bed");g.Inspect("bed");for(int i=0;i<3;i++)Say("hub","继续等待评估");Ending("E06");typeof(ApartmentGame).GetMethod("ContinueWelcomeLoop",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(g,null);Check(g.state.day==1&&g.state.welcome.loop==2&&g.state.welcome.vacuumDamage==damage,"循环保留实际损伤与关系，不生成新人");
   Fresh();Investigate();Audit();Say("hub","申请管理权");Say("hub","确认强制重置音箱");Check(g.state.ending=="","强制处置先明确预警");Say("hub","确认强制重置音箱");Ending("E07");
   Fresh();g.Inspect("bed");g.Inspect("bed");Say("ac","浴室危险测试");Check(g.state.welcome.risk==0,"危险测试首次要求只预警");for(int i=0;i<3;i++)Say("ac","确认浴室危险测试");Say("mirror","确认伪造授权");Say("mirror","确认伪造授权");Say("mirror","请求本轮医疗救治");Check(g.state.welcome.risk==0&&g.state.welcome.medicalRequested,"低信任不剥夺基础医疗干预");
   Fresh();g.Inspect("bed");g.Inspect("bed");Say("ac","浴室危险测试");for(int i=0;i<3;i++)Say("ac","确认浴室危险测试");for(int i=0;i<3;i++)Say("hub","继续等待评估");Ending("E08");
   g.Save(3);g.BeginGame();g.ConfirmResidentName("林舟");Check(g.Load(3)&&g.state.ending=="E08"&&g.state.version==2,"八结局新状态存读档");
   Fresh();g.Teleport(12.7,9.75,0);typeof(ApartmentGame).GetField("intendedDevice",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(g,"fridge");g.InteractNearest();Check(g.TalkingTo=="fridge","明确选择冰箱不会被同处遗书隔层抢占");g.Teleport(10,1,0);typeof(ApartmentGame).GetField("intendedDevice",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(g,"lock");g.InteractNearest();Check(g.TalkingTo=="lock","明确选择门锁不会被大门查看抢占");
   Fresh();Say("ac","安排维护窗口");Say("ac","结束维护窗口");Check(!g.state.welcome.maintenanceOpen&&g.state.welcome.maintenanceDone,"可在不进设备间时自主结束维护安排");g.Inspect("notes");Say("vacuum","顶门");Say("vacuum","归还表带");Check(g.state.welcome.trust.First(t=>t.id=="vacuum").betrayed,"归还借物不能抹去超载损害背叛");g.Inspect("tools");Say("vacuum","维修驱动");Check(!g.state.welcome.trust.First(t=>t.id=="vacuum").betrayed&&g.state.welcome.vacuumDamage==0,"实际针对驱动损害检修才修复本次关系");
   Fresh();g.Inspect("bed");Say("xb","查询协议与权限");Check(g.state.welcome.contractRead,"手机查询协议与纸面阅读等效");Say("tv","查询调度缓存");Say("ac","安排维护窗口");g.Inspect("hatch");g.Inspect("panel");Say("xb","核对材料来源");int sources=(int)typeof(ApartmentGame).GetMethod("IndependentSources",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(g,null);Check(sources==2,"调度缓存与死亡日志同源，不重复计数"); // 协议来源 + 调度来源
   Say("xb","提交违规审计");Check(!g.state.welcome.auditSubmitted,"重复同源记录不能单独证明有效案件");
   Fresh();Investigate();Say("speaker","陆川的历史求救录音");Say("hub","出示交易条件");Say("hub","接受交易");Say("hub","用求救原件替代记忆重置，重新议价");Check(!g.state.welcome.dealAccepted,"改变交易代价必须重新同意");Say("hub","确认执行交易");Check(!g.state.welcome.dealDelivered,"未重新同意不得直接扣除新代价");Say("hub","接受交易");Say("hub","确认执行交易");Check(!g.state.welcome.speakerReset&&!g.state.welcome.evidence.Any(e=>e.id=="speaker_audio")&&!g.Has("speaker_audio"),"替代交易实际移交音频原件而不重置音箱");
   Fresh();int old=g.state.welcome.trust.First(t=>t.id=="mirror").value;Say("mirror","你是不是伪造授权了？");Check(g.state.welcome.trust.First(t=>t.id=="mirror").value==old,"询问指控不是玩家已经实施伪造");Say("fridge","拿干布");Faults();Say("xb","申请故障接管");Say("xb","用干布擦干积水");Check(g.state.welcome.water==0&&!g.state.welcome.takeoverPending,"实际取得干布后可亲手清理并改变故障依据");report.status="passed";
  }catch(Exception e){report.status="failed";report.error=e.ToString();Debug.LogException(e);}finally{Directory.CreateDirectory("Assets/ThirdDay/UIReview");File.WriteAllText("Assets/ThirdDay/UIReview/WelcomeHomeReview.json",JsonUtility.ToJson(report,true));g.ShowMenu();g.validationMode=false;g.enabled=true;Debug.Log("[WelcomeHome] "+report.status+" / "+report.checks.Count+" checks");if(batch)EditorApplication.Exit(report.status=="passed"?0:1);}}
 }
}
