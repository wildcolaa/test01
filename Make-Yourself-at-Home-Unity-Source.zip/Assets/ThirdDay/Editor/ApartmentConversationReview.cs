using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEditor;
using TMPro;
namespace ThirdDay.Editor {
 public static class ApartmentConversationReview {
  const BindingFlags Flags=BindingFlags.Instance|BindingFlags.NonPublic;
  [Serializable]class Report {public string status="running";public bool proximityHasNoInput,eOpensInput,verticalBubbles,coloursUnchanged,walkingAwayClosesInput;public float zoomBefore,zoomFirstStep,zoomSettled,zoomAfterExit;}
  static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
  [MenuItem("Third Day/Legacy V1/Review Conversation")]
  public static void Start(){if(!EditorApplication.isPlaying)return;var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Conversation review").AddComponent<ApartmentValidationHost>().StartCoroutine(Run(g));}
  static IEnumerator Run(ApartmentGame g){
   var report=new Report();var keyboard=Keyboard.current;Directory.CreateDirectory("Assets/ThirdDay/UIReview");g.validationMode=true;
   var keyField=typeof(ApartmentGame).GetField("key",Flags);var originalKey=keyField.GetValue(g);keyField.SetValue(g,"");
   try{
    g.BeginGame();g.FinishOpening();g.Teleport(12.58,4.8,0);g.Proximity();yield return new WaitForSecondsRealtime(1);
    report.proximityHasNoInput=g.Mode=="play"&&g.TalkingTo==null&&!g.GetComponentsInChildren<TMP_InputField>().Any(f=>f.gameObject.activeInHierarchy);Check(report.proximityHasNoInput,"Proximity opened dialogue");
    report.zoomBefore=g.View.orthographicSize;ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/E-prompt-before.png"));yield return new WaitForEndOfFrame();yield return null;
    InputSystem.QueueStateEvent(keyboard,new KeyboardState(Key.E));yield return null;yield return null;InputSystem.QueueStateEvent(keyboard,new KeyboardState());
    report.eOpensInput=g.Mode=="talk"&&g.TalkingTo=="speaker"&&g.GetComponentsInChildren<TMP_InputField>().Any(f=>f.gameObject.activeInHierarchy);Check(report.eOpensInput,"E did not open dialogue");report.zoomFirstStep=g.View.orthographicSize;Check(report.zoomFirstStep<report.zoomBefore&&report.zoomFirstStep>6.57f,"Conversation camera snapped instead of transitioning");
    yield return new WaitForSecondsRealtime(1);report.zoomSettled=g.View.orthographicSize;Check(report.zoomSettled<report.zoomBefore*.85f,"Conversation did not zoom in");
    var input=g.GetComponentsInChildren<TMP_InputField>().First(f=>f.gameObject.activeInHierarchy);input.text="你知道什么？";input.onSubmit.Invoke(input.text);yield return new WaitForSecondsRealtime(.3f);
    var speech=(TMP_Text)typeof(ApartmentGame).GetField("speechLabel",Flags).GetValue(g);var npc=(RectTransform)speech.transform.parent;var question=(RectTransform)typeof(ApartmentGame).GetField("questionPanel",Flags).GetValue(g);
    report.verticalBubbles=Mathf.Abs(npc.anchoredPosition.x-question.anchoredPosition.x)<1&&-question.anchoredPosition.y+question.rect.height+20<=-npc.anchoredPosition.y;Check(report.verticalBubbles,"Conversation bubbles were not vertically stacked");
    var nc=npc.GetComponent<ApartmentGraphic>().color;var qc=question.GetComponent<ApartmentGraphic>().color;report.coloursUnchanged=Mathf.Abs(nc.r-222/255f)<.01f&&Mathf.Abs(qc.r-40/255f)<.01f&&Mathf.Abs(qc.a-.86f)<.01f;Check(report.coloursUnchanged,"Bubble colours changed");
    ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/Conversation-stacked.png"));yield return new WaitForEndOfFrame();yield return null;
    g.Player.position=new Vector3(10,0,-7);g.Proximity();yield return null;yield return null;report.walkingAwayClosesInput=g.TalkingTo==null&&g.Mode=="play"&&!g.GetComponentsInChildren<TMP_InputField>().Any(f=>f.gameObject.activeInHierarchy);Check(report.walkingAwayClosesInput,"Walking away did not close dialogue");
    yield return new WaitForSecondsRealtime(1);report.zoomAfterExit=g.View.orthographicSize;Check(report.zoomAfterExit>report.zoomSettled+1,"Camera did not return to exploration zoom");report.status="passed";
   }finally{keyField.SetValue(g,originalKey);InputSystem.QueueStateEvent(keyboard,new KeyboardState());g.validationMode=false;g.ShowMenu();File.WriteAllText("Assets/ThirdDay/UIReview/ConversationReview.json",JsonUtility.ToJson(report,true));}
   Debug.Log("[ThirdDay] E interaction, smooth camera and conversation layout: "+report.status);
  }
 }
}
