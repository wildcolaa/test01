using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using ThirdDay;
namespace ThirdDay.Editor {
 [InitializeOnLoad]public static class ApartmentUtopiaReview {
  const string Dir="Assets/ThirdDay/UIReview/Utopia";const BindingFlags F=BindingFlags.Instance|BindingFlags.NonPublic;
  [Serializable]class Report {public string status="running",error="";public int addedTriangles,staticBatches,vehicles,renderers,colliders;public List<string> checks=new List<string>();}
  static Report report;static ApartmentGame g;
  static ApartmentUtopiaReview(){EditorApplication.playModeStateChanged+=s=>{if(s==PlayModeStateChange.EnteredPlayMode&&SessionState.GetBool("Welcome.UtopiaReview",false)){SessionState.SetBool("Welcome.UtopiaReview",false);g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Utopia scene review").AddComponent<WelcomeReviewHost>().StartCoroutine(Run());}};}
  public static void BeginBatch(){SessionState.SetBool("Welcome.UtopiaBatch",true);Begin();}
  [MenuItem("Third Day/Review Utopia Atmosphere")]
  public static void Begin(){SessionState.SetBool("Welcome.UtopiaReview",true);EditorSceneManager.OpenScene("Assets/ThirdDay/Scenes/ThirdDay.unity");EditorApplication.isPlaying=true;}
  static void Check(bool ok,string text){if(!ok)throw new Exception(text);report.checks.Add(text);}
  static IEnumerator View(string name,float x,float z,float zoom,float floor=0){g.Teleport(x,z,floor);typeof(ApartmentGame).GetField("zoom",F).SetValue(g,zoom);typeof(ApartmentGame).GetField("bubbleUntil",F).SetValue(g,0f);yield return new WaitForSecondsRealtime(1.2f);Capture(name);}
  static void Capture(string name){var canvas=g.GetComponentInChildren<Canvas>();var mode=canvas.renderMode;var originalCamera=canvas.worldCamera;var rt=new RenderTexture(1920,1080,24);var previous=RenderTexture.active;g.View.targetTexture=rt;canvas.renderMode=RenderMode.ScreenSpaceCamera;canvas.worldCamera=g.View;canvas.planeDistance=10;Canvas.ForceUpdateCanvases();typeof(ApartmentGame).GetMethod("LateUpdate",F).Invoke(g,null);if(g.Mode=="menu")foreach(var fade in g.GetComponentsInChildren<ApartmentCoverFade>())fade.enabled=false;Canvas.ForceUpdateCanvases();g.View.Render();RenderTexture.active=rt;var tex=new Texture2D(1920,1080,TextureFormat.RGB24,false);tex.ReadPixels(new Rect(0,0,1920,1080),0,0);tex.Apply();File.WriteAllBytes(Dir+"/"+name+".png",tex.EncodeToPNG());RenderTexture.active=previous;g.View.targetTexture=null;canvas.renderMode=mode;canvas.worldCamera=originalCamera;UnityEngine.Object.Destroy(tex);rt.Release();UnityEngine.Object.Destroy(rt);}
  static IEnumerator Run(){report=new Report();Directory.CreateDirectory(Dir);g.validationMode=true;g.BeginGame();g.ConfirmResidentName("林舟");g.FinishOpening();yield return new WaitForSecondsRealtime(.7f);
   try{var root=g.transform.Find("Utopia · household and civic services");Check(root!=null,"室内与室外服务设施已创建");report.addedTriangles=g.DressingTriangleCount;report.staticBatches=g.DressingStaticBatches;report.vehicles=g.DressingVehicles;report.renderers=root.GetComponentsInChildren<Renderer>().Length;report.colliders=root.GetComponentsInChildren<Collider>().Length;Check(report.staticBatches<=8,"静态道具限制为八个共享材质批次");Check(report.addedTriangles<16000,"新增几何保持低于一万六千三角面");Check(report.vehicles==7,"五架配送机、一台接驳车、一台玻璃养护机");Check(report.colliders==0,"道具不增加碰撞与物理模拟");Check(root.GetComponentsInChildren<Light>().Length==0,"场景布置不新增实时灯光");
    foreach(var o in g.Data.objects.Where(o=>o.id.StartsWith("utopia_"))){var start=o.floor<0?new Vector3(25.9f,-4.5f,-5.6f):new Vector3(10,0,-1.4f);Check(g.Navigation.Path(start,new Vector3(o.approach[0],o.floor,-o.approach[1]))!=null,"观察点可以到达："+o.id);}
    
   }catch(Exception e){report.error=e.ToString();report.status="failed";Debug.LogException(e);Finish();yield break;}
   var courierCheck=g.transform.Find("Utopia · household and civic services/Scheduled courier 0");var before=courierCheck.position;yield return new WaitForSecondsRealtime(.4f);if(Vector3.Distance(before,courierCheck.position)<=.02f){report.status="failed";report.error="配送机未移动";Finish();yield break;}report.checks.Add("配送机沿航线实际移动");yield return View("01-overview",8.5f,5.5f,13.2f);yield return View("02-living-balcony",1.3f,8.7f,7.8f);yield return View("03-kitchen",14.7f,10.0f,6.2f);yield return View("04-bedroom",15.4f,4.4f,6.2f);yield return View("05-entry-bath-storage",6.2f,2.0f,7.3f);yield return View("06-equipment",24.9f,4.8f,5.4f,-4.5f);yield return View("07-civic-corridor",-1.1f,7.3f,12.8f);g.ShowMenu();yield return new WaitForSecondsRealtime(1.2f);Capture("08-cover");report.status="passed";Finish();
  }
  static void Finish(){File.WriteAllText(Dir+"/Review.json",JsonUtility.ToJson(report,true));g.ShowMenu();g.validationMode=false;Debug.Log("[Utopia] "+report.status+" / "+report.addedTriangles+" triangles / "+report.staticBatches+" static batches");if(SessionState.GetBool("Welcome.UtopiaBatch",false))EditorApplication.Exit(report.status=="passed"?0:1);}
 }
}
