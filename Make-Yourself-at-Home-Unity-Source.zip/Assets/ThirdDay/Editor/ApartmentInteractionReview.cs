using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEditor;
using TMPro;
namespace ThirdDay.Editor {
 public static class ApartmentInteractionReview {
  const BindingFlags Flags=BindingFlags.Instance|BindingFlags.NonPublic;
  [Serializable]class Report {public string status="running";public int width,height,microphoneDevices,capturedSamples;public float uiScale,logicalHeight;public bool caretConfigured,pressedFeedback,typingDoesNotRecord,spaceStartsRecording,spaceTapStopsRecording,deviceStopped;public bool transcriptionTested=false;}
  static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
  static object Read(ApartmentGame g,string field)=>typeof(ApartmentGame).GetField(field,Flags).GetValue(g);
  static void Call(ApartmentGame g,string method)=>typeof(ApartmentGame).GetMethod(method,Flags).Invoke(g,null);
  [MenuItem("Third Day/Review Input And Microphone")]
  public static void Start(){if(!EditorApplication.isPlaying)return;var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Input and device review").AddComponent<ApartmentValidationHost>().StartCoroutine(Run(g));}
  static IEnumerator Run(ApartmentGame g){
   var report=new Report();var keyField=typeof(ApartmentGame).GetField("key",Flags);var originalKey=keyField.GetValue(g);var keyboard=Keyboard.current;
   Directory.CreateDirectory("Assets/ThirdDay/UIReview");g.validationMode=true;
   try {
    g.BeginGame();g.FinishOpening();g.Teleport(12.58,4.8,0);g.Proximity();g.InteractNearest();yield return new WaitForSecondsRealtime(.4f);
    var canvas=g.GetComponentsInChildren<Canvas>().First();report.width=Screen.width;report.height=Screen.height;report.uiScale=canvas.scaleFactor;report.logicalHeight=canvas.GetComponent<RectTransform>().rect.height;Check(Mathf.Abs(report.logicalHeight-675)<1,"UI readability reference height");
    var input=g.GetComponentsInChildren<TMP_InputField>().First(f=>f.gameObject.activeInHierarchy);input.text="光标测试";input.ActivateInputField();yield return new WaitForSecondsRealtime(.2f);
    report.caretConfigured=input.isFocused&&input.customCaretColor&&input.caretWidth>=2&&input.caretColor.r<.2f;Check(report.caretConfigured,"Visible caret");input.caretBlinkRate=0;input.caretPosition=input.text.Length;input.ForceLabelUpdate();yield return null;yield return new WaitForEndOfFrame();var caretMesh=(Mesh)typeof(TMP_InputField).GetField("m_Mesh",Flags).GetValue(input);Check(caretMesh&&caretMesh.vertexCount>=4,"Caret geometry missing");Check(caretMesh.bounds.center.y<-5&&caretMesh.bounds.center.y>-40,"Caret is not aligned with typed text");ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/Input-caret.png"));yield return new WaitForEndOfFrame();yield return null;input.caretBlinkRate=.85f;
    InputSystem.QueueStateEvent(keyboard,new KeyboardState(Key.Space));yield return null;yield return null;report.typingDoesNotRecord=!(bool)Read(g,"recording");Check(report.typingDoesNotRecord,"Typing space triggered recording");InputSystem.QueueStateEvent(keyboard,new KeyboardState());yield return null;
    var send=g.GetComponentsInChildren<Button>().First(b=>b.name=="发送"&&b.gameObject.activeInHierarchy);var pointer=new PointerEventData(EventSystem.current){button=PointerEventData.InputButton.Left};ExecuteEvents.Execute(send.gameObject,pointer,ExecuteEvents.pointerDownHandler);yield return null;
    report.pressedFeedback=send.GetComponent<ApartmentGraphic>().color.r<.3f&&send.GetComponentInChildren<TMP_Text>().color.r>.8f;Check(report.pressedFeedback,"Send button has no pressed feedback");ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/Send-pressed.png"));yield return new WaitForEndOfFrame();yield return null;ExecuteEvents.Execute(send.gameObject,pointer,ExecuteEvents.pointerUpHandler);
    input.DeactivateInputField();EventSystem.current.SetSelectedGameObject(null);yield return null;yield return null;
    report.microphoneDevices=Microphone.devices.Length;
    if(report.microphoneDevices>0){
     // Probe local capture only. Never submit the test recording to a service.
     keyField.SetValue(g,"local-capture-test-no-transmission");InputSystem.QueueStateEvent(keyboard,new KeyboardState(Key.Space));yield return new WaitForSecondsRealtime(.7f);
     report.spaceStartsRecording=(bool)Read(g,"recording")&&Microphone.IsRecording(null);report.capturedSamples=Microphone.GetPosition(null);Check(report.spaceStartsRecording&&report.capturedSamples>0,"Space did not start microphone capture");
     Call(g,"CancelVoice");InputSystem.QueueStateEvent(keyboard,new KeyboardState());yield return null;yield return null;
     InputSystem.QueueStateEvent(keyboard,new KeyboardState(Key.Space));InputSystem.QueueStateEvent(keyboard,new KeyboardState());yield return null;yield return null;report.spaceTapStopsRecording=!(bool)Read(g,"recording")&&!Microphone.IsRecording(null);Check(report.spaceTapStopsRecording,"Space tap left microphone open");
    }
    report.deviceStopped=!Microphone.IsRecording(null);report.status=report.microphoneDevices>0?"passed":"no-microphone-device";
   } finally {
    Call(g,"CancelVoice");keyField.SetValue(g,originalKey);if(keyboard!=null)InputSystem.QueueStateEvent(keyboard,new KeyboardState());g.validationMode=false;g.ShowMenu();File.WriteAllText("Assets/ThirdDay/UIReview/InteractionReview.json",JsonUtility.ToJson(report,true));
   }
   Debug.Log("[ThirdDay] Input and microphone review: "+report.status);
  }
 }
}
