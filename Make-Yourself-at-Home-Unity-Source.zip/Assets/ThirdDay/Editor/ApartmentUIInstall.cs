using UnityEditor;
using UnityEngine;
using System.IO;
namespace ThirdDay.Editor {
[InitializeOnLoad]public static class ApartmentUIInstall {
 static ApartmentUIInstall(){EditorApplication.delayCall+=Install;}
 static void Install(){if(EditorApplication.isPlayingOrWillChangePlaymode)return;if(File.Exists("Assets/TextMesh Pro/Resources/TMP Settings.asset"))return;var packages=UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages();foreach(var p in packages)if(p.name=="com.unity.ugui"){AssetDatabase.ImportPackage(Path.Combine(p.resolvedPath,"Package Resources/TMP Essential Resources.unitypackage"),false);break;}}
}}
