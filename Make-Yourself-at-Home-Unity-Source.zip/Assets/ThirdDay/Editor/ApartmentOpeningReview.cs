using System;
using System.IO;
using System.Linq;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using TMPro;
namespace ThirdDay.Editor {
 public static class ApartmentOpeningReview {
  [MenuItem("Third Day/Review Opening")]
  public static void Start(){if(!EditorApplication.isPlaying)return;var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Opening Review").AddComponent<ApartmentValidationHost>().StartCoroutine(Run(g));}
  static int Lines(ApartmentGame g)=>g.GetComponentsInChildren<TMP_Text>().Count(t=>t.gameObject.activeInHierarchy&&(t.text=="欢迎回家。"||t.text=="前三天是生活适应期。需要的时候，家会提醒你。"||t.text=="滚滚说别费劲了，墙上的开关去年就封上了。叫一声小灯泡就成。"));
  static void Check(bool yes,string message){if(!yes)throw new Exception(message);}
  static IEnumerator Run(ApartmentGame g){
   g.validationMode=true;g.BeginGame();g.AdvanceIntro();g.AdvanceIntro();g.AdvanceIntro();yield return new WaitForSecondsRealtime(.2f);
   Check(Lines(g)==0,"Opening did not start empty");Check(!g.GetComponentsInChildren<TMP_InputField>().Any(),"Input visible before dialogue");
   Check(!g.GetComponentsInChildren<Button>().Any(b=>b.name=="呼叫小灯泡"||b.name=="摸索墙壁"),"Removed buttons still present");
   yield return new WaitForSecondsRealtime(1.4f);Check(Lines(g)==1,"First line timing");var stack=g.GetComponentsInChildren<RectTransform>().First(t=>t.name=="Arrival dialogue");var first=(RectTransform)stack.GetChild(0);float firstY=first.anchoredPosition.y;Check(Mathf.Abs((-firstY+first.rect.height)-(g.GetComponentsInChildren<Canvas>().First().GetComponent<RectTransform>().rect.height-114))<4,"First line was not at bottom");Check(!g.GetComponentsInChildren<TMP_InputField>().Any(),"Input visible after first line");ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/opening-1-line.png"));
   yield return new WaitForSecondsRealtime(2);Check(Lines(g)==2,"Second line timing");Check(first.anchoredPosition.y>firstY+30,"Old line did not move upward");Check(!g.GetComponentsInChildren<TMP_InputField>().Any(),"Input visible after second line");ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/opening-2-lines.png"));
   yield return new WaitForSecondsRealtime(2.8f);Check(Lines(g)==3,"Third line timing");var input=g.GetComponentsInChildren<TMP_InputField>().First(f=>f.gameObject.activeInHierarchy);ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/UIReview/04-dark-opening.png"));yield return new WaitForEndOfFrame();yield return null;
   input.text="小灯泡，开灯";input.onSubmit.Invoke(input.text);yield return null;Check(g.state.opened&&g.Mode!="dark","Typed opening failed");
   g.BeginGame();g.AdvanceIntro();g.AdvanceIntro();g.AdvanceIntro();yield return new WaitForSecondsRealtime(.2f);Check(Lines(g)==0,"Replay timing did not reset");
   g.FinishOpening();yield return new WaitForSecondsRealtime(1.5f);Check(g.Mode!="dark"&&Lines(g)==0,"Opening continued after lights came on");g.validationMode=false;g.ShowMenu();
   File.WriteAllText("Assets/ThirdDay/UIReview/OpeningReview.json","{\"status\":\"passed\",\"timingSeconds\":[1.4,3.4,5.8],\"bottomAnchored\":true,\"olderLinesMoveUp\":true,\"inputOnlyAfterLastLine\":true,\"removedButtons\":true,\"typedLightRequest\":true,\"replayReset\":true,\"noLateDialogue\":true}");Debug.Log("[ThirdDay] Opening sequence review passed.");
  }
 }
}
