using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace ThirdDay.Editor
{
    [InitializeOnLoad]
    public static class ApartmentImporter
    {
        const string Base="Assets/ThirdDay",ScenePath=Base+"/Scenes/ThirdDay.unity";
        static ApartmentImporter(){EditorApplication.delayCall+=AutoInstall;EditorApplication.playModeStateChanged+=OnPlay;}
        static void AutoInstall()
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)return;
            if(!File.Exists(Base+"/Source/Apartment.json"))return;
            if(File.Exists(ScenePath)){if(!File.Exists(Base+"/Generated/LegacyColorSpace.txt"))CorrectColors();return;}
            try{Build();}catch(Exception e){Debug.LogException(e);File.WriteAllText(Base+"/ImportError.txt",e.ToString());}
        }
        [MenuItem("Third Day/Open Game")]
        public static void Open(){if(File.Exists(ScenePath))EditorSceneManager.OpenScene(ScenePath);else Build();ApartmentGameView.Show();}
        [MenuItem("Third Day/Rebuild Scene")]
        public static void Build()
        {
            if(EditorApplication.isPlaying)throw new InvalidOperationException("先退出运行模式。");
            foreach(var dir in new[]{"Generated","Generated/Meshes","Generated/Materials","Scenes"})Directory.CreateDirectory(Base+"/"+dir);
            var data=JsonUtility.FromJson<ApartmentData>(File.ReadAllText(Base+"/Source/Apartment.json"));var mats=new Dictionary<string,Material>();
            foreach(var item in data.materials)
            {
                var shader=Shader.Find(item.vertexColors?"ThirdDay/CityGradient":item.unlit?"Universal Render Pipeline/Unlit":"Universal Render Pipeline/Lit");if(!shader)throw new Exception("Shader missing: "+item.name);
                var material=new Material(shader){name=item.name,enableInstancing=true};var color=new Color(item.color[0],item.color[1],item.color[2],item.color[3]).gamma;material.SetColor("_BaseColor",color);
                if(item.vertexColors){
                    material.SetTexture("_PaperGrain",Resources.Load<Texture2D>("UI/PrintGrain"));
                    material.EnableKeyword("CITY_PRINT_GRAIN");
                }
                if(!string.IsNullOrEmpty(item.texture)){var path=Base+"/Art/Textures/"+item.texture+".png";var importer=AssetImporter.GetAtPath(path) as TextureImporter;if(importer){importer.wrapMode=TextureWrapMode.Repeat;importer.maxTextureSize=1024;importer.SaveAndReimport();}material.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>(path));}
                if(material.HasProperty("_Metallic"))material.SetFloat("_Metallic",item.metal);if(material.HasProperty("_Smoothness"))material.SetFloat("_Smoothness",1-item.roughness);
                if(item.emissionStrength>0){material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",new Color(item.emission[0],item.emission[1],item.emission[2])*item.emissionStrength);}
                if(item.transparent){material.SetFloat("_Surface",1);material.SetFloat("_Blend",0);material.SetFloat("_SrcBlend",(float)BlendMode.SrcAlpha);material.SetFloat("_DstBlend",(float)BlendMode.OneMinusSrcAlpha);material.SetFloat("_ZWrite",0);material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");material.SetOverrideTag("RenderType","Transparent");material.renderQueue=3000;}
                if(item.doubleSided)material.SetFloat("_Cull",(float)CullMode.Off);
                SaveAsset(material,Base+"/Generated/Materials/"+item.name+".mat");mats[item.name]=AssetDatabase.LoadAssetAtPath<Material>(Base+"/Generated/Materials/"+item.name+".mat");
            }
            var previous=SceneManager.GetActiveScene();var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);SceneManager.SetActiveScene(scene);
            var root=new GameObject("Third Day — 1907");var world=new GameObject("World").transform;world.SetParent(root.transform);var transforms=new Dictionary<string,Transform>{{"Static",world}};
            foreach(var r in data.roots){var go=new GameObject(r.name);transforms[r.name]=go.transform;go.transform.SetParent(world,false);}
            foreach(var r in data.roots){var t=transforms[r.name];if(!string.IsNullOrEmpty(r.parent))t.SetParent(transforms[r.parent],false);t.localPosition=V3(r.position);t.localRotation=new Quaternion(r.rotation[0],r.rotation[1],r.rotation[2],r.rotation[3]);t.localScale=V3(r.scale);t.gameObject.SetActive(r.visible);}
            int triangles=0;
            foreach(var item in data.meshes)
            {
                var mesh=new Mesh{name=item.name,indexFormat=IndexFormat.UInt32};var vertices=new Vector3[item.p.Length/3];var normals=new Vector3[vertices.Length];var uv=new Vector2[vertices.Length];var colors=new Color[vertices.Length];
                for(int i=0;i<vertices.Length;i++){vertices[i]=new Vector3(item.p[i*3],item.p[i*3+1],item.p[i*3+2]);normals[i]=new Vector3(item.n[i*3],item.n[i*3+1],item.n[i*3+2]);uv[i]=new Vector2(item.uv[i*2],item.uv[i*2+1]);colors[i]=new Color(item.c[i*4],item.c[i*4+1],item.c[i*4+2],item.c[i*4+3]);}
                mesh.vertices=vertices;mesh.normals=normals;mesh.uv=uv;mesh.colors=colors;mesh.triangles=item.indices;mesh.RecalculateBounds();triangles+=item.indices.Length/3;
                var assetPath=Base+"/Generated/Meshes/"+item.name.Replace('/','_')+".asset";SaveAsset(mesh,assetPath);mesh=AssetDatabase.LoadAssetAtPath<Mesh>(assetPath);
                var go=new GameObject(item.name.Split('/').Last());go.transform.SetParent(transforms[item.root],false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=mats[item.material];renderer.shadowCastingMode=item.root=="Static"&&data.materials.First(m=>m.name==item.material).vertexColors?ShadowCastingMode.Off:ShadowCastingMode.On;renderer.receiveShadows=true;if(item.root=="Static")go.isStatic=true;
            }
            var cameraGO=new GameObject("Main Camera");cameraGO.tag="MainCamera";cameraGO.transform.SetParent(root.transform);var camera=cameraGO.AddComponent<Camera>();camera.orthographic=true;camera.orthographicSize=11.3f;camera.nearClipPlane=.1f;camera.farClipPlane=400;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.14f,.15f,.17f);camera.allowHDR=true;cameraGO.AddComponent<AudioListener>();cameraGO.AddComponent<UniversalAdditionalCameraData>().renderPostProcessing=true;camera.transform.position=new Vector3(9,0,-6)+new Vector3(1,1.16f,-1).normalized*70;camera.transform.LookAt(new Vector3(9,0,-6));
            MakeLight(root,"City fill",LightType.Directional,new Vector3(-20,18,20),.65f,new Color(.68f,.72f,.84f),Quaternion.Euler(48,-35,0),true);
            foreach(var lamp in data.lamps)MakeLight(root,"Lamp_"+lamp.id,LightType.Point,ApartmentCoordinates.World(lamp.position),1.5f,new Color(1,.94f,.84f),Quaternion.identity,false,8.5f);
            MakeLight(root,"Bathroom",LightType.Point,new Vector3(2.4f,2.3f,-1.8f),1.2f,new Color(.54f,.45f,1),Quaternion.identity,false,7);
            MakeLight(root,"Equipment room",LightType.Point,new Vector3(24.5f,-2.2f,-4.5f),1.5f,new Color(1,.8f,.6f),Quaternion.identity,false,9);
            var volumeGO=new GameObject("Atmosphere");volumeGO.transform.SetParent(root.transform);var volume=volumeGO.AddComponent<Volume>();volume.isGlobal=true;var profile=ScriptableObject.CreateInstance<VolumeProfile>();var bloom=profile.Add<Bloom>();bloom.intensity.Override(.2f);bloom.threshold.Override(.9f);var grade=profile.Add<ColorAdjustments>();grade.saturation.Override(-14);var tone=profile.Add<Tonemapping>();tone.mode.Override(TonemappingMode.Neutral);SaveAsset(profile,Base+"/Generated/Atmosphere.asset");volume.sharedProfile=AssetDatabase.LoadAssetAtPath<VolumeProfile>(Base+"/Generated/Atmosphere.asset");
            RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=new Color(.48f,.51f,.58f);RenderSettings.ambientEquatorColor=new Color(.32f,.34f,.39f);RenderSettings.ambientGroundColor=new Color(.12f,.12f,.14f);RenderSettings.fog=true;RenderSettings.fogMode=FogMode.Linear;RenderSettings.fogColor=new Color(.18f,.19f,.21f);RenderSettings.fogStartDistance=85;RenderSettings.fogEndDistance=190;
            var game=root.AddComponent<ApartmentGame>();game.source=AssetDatabase.LoadAssetAtPath<TextAsset>(Base+"/Source/Apartment.json");game.chineseFont=AssetDatabase.LoadAssetAtPath<Font>(Base+"/Resources/Chinese.ttf");game.music=AssetDatabase.LoadAssetAtPath<AudioClip>(Base+"/Audio/City86.wav");
            var audioImporter=AssetImporter.GetAtPath(Base+"/Audio/City86.wav") as AudioImporter;if(audioImporter){var settings=audioImporter.defaultSampleSettings;settings.loadType=AudioClipLoadType.CompressedInMemory;settings.compressionFormat=AudioCompressionFormat.Vorbis;settings.quality=.7f;audioImporter.defaultSampleSettings=settings;audioImporter.SaveAndReimport();}
            EditorSceneManager.SaveScene(scene,ScenePath);File.WriteAllText(Base+"/Generated/LegacyColorSpace.txt","Three r128 material color values restored");var buildScenes=EditorBuildSettings.scenes.Where(s=>s.path!=ScenePath).ToList();buildScenes.Insert(0,new EditorBuildSettingsScene(ScenePath,true));EditorBuildSettings.scenes=buildScenes.ToArray();
            if(previous.IsValid()&&!previous.isDirty&&previous.path.EndsWith("SampleScene.unity"))EditorSceneManager.CloseScene(previous,true);
            Selection.activeGameObject=root;SceneView.lastActiveSceneView?.Frame(new Bounds(new Vector3(9,0,-6),new Vector3(24,8,18)),false);AssetDatabase.SaveAssets();
            File.WriteAllText(Base+"/ImportReport.json","{\"status\":\"imported\",\"meshes\":"+data.meshes.Length+",\"triangles\":"+triangles+",\"scene\":\""+ScenePath+"\"}");Debug.Log("[ThirdDay] Native scene imported: "+triangles+" triangles.");
            SessionState.SetBool("Welcome.RunReview",true);EditorApplication.delayCall+=()=>{EditorApplication.ExecuteMenuItem("Window/General/Game");EditorApplication.isPlaying=true;};
        }
        static Vector3 V3(float[] v)=>new Vector3(v[0],v[1],v[2]);
        static void CorrectColors()
        {
            var data=JsonUtility.FromJson<ApartmentData>(File.ReadAllText(Base+"/Source/Apartment.json"));foreach(var s in data.materials){var m=AssetDatabase.LoadAssetAtPath<Material>(Base+"/Generated/Materials/"+s.name+".mat");if(!m)continue;m.SetColor("_BaseColor",new Color(s.color[0],s.color[1],s.color[2],s.color[3]).gamma);EditorUtility.SetDirty(m);}File.WriteAllText(Base+"/Generated/LegacyColorSpace.txt","Three r128 material color values restored");AssetDatabase.SaveAssets();
        }
        static void SaveAsset(UnityEngine.Object obj,string path){var existing=AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(path);if(existing){EditorUtility.CopySerialized(obj,existing);UnityEngine.Object.DestroyImmediate(obj);}else AssetDatabase.CreateAsset(obj,path);}
        static void MakeLight(GameObject root,string name,LightType type,Vector3 position,float intensity,Color color,Quaternion rotation,bool shadows,float range=0){var go=new GameObject(name);go.transform.SetParent(root.transform);go.transform.position=position;go.transform.rotation=rotation;var light=go.AddComponent<Light>();light.type=type;light.intensity=intensity;light.color=color;light.range=range;light.shadows=shadows?LightShadows.Soft:LightShadows.None;light.shadowResolution=LightShadowResolution.Medium;}
        [MenuItem("Third Day/Validate Port")]
        public static void Validate(){WelcomeHomeReview.Begin();}
        static void OnPlay(PlayModeStateChange state){if(state!=PlayModeStateChange.EnteredPlayMode||!SessionState.GetBool("ThirdDay.Validate",false))return;SessionState.SetBool("ThirdDay.Validate",false);var game=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();if(game){var host=new GameObject("Validation Host").AddComponent<ApartmentValidationHost>();host.StartCoroutine(ApartmentValidation.Run(game,()=>EditorApplication.isPlaying=false));}}
    }
}
