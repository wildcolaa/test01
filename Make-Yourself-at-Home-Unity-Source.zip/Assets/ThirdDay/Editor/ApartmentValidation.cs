using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace ThirdDay.Editor
{
    public sealed class ApartmentValidationHost : MonoBehaviour { }
    public static class ApartmentValidation
    {
        [Serializable] class Report { public string status; public List<string> passed=new List<string>(); public string error=""; public int renderers; public float sampledFrameMilliseconds; }
        static void Check(bool condition,string message){if(!condition)throw new Exception(message);}
        public static IEnumerator Run(ApartmentGame g,Action done)
        {
            var report=new Report();g.validationMode=true;yield return null;
            try
            {
                g.BeginGame();g.AdvanceIntro();g.AdvanceIntro();g.AdvanceIntro();g.SendText("不要开灯");Check(!g.state.opened,"Negative opening unexpectedly accepted");g.SendText("小灯泡，开灯");Check(g.state.opened&&g.state.lightsOn,"Opening");report.passed.Add("Opening light interaction");
                g.Teleport(25,12,0);g.OpenTalk("speaker");Check(g.TalkingTo==null,"Remote dialogue");g.Teleport(12.58,4.8,0);g.Proximity();Check(g.TalkingTo==null,"Proximity opened dialogue without E");g.InteractNearest();Check(g.TalkingTo=="speaker","E interaction entry");g.Player.position=new Vector3(10,0,-7);g.Proximity();Check(g.TalkingTo==null,"Proximity exit");report.passed.Add("Proximity dialogue and walking away");
                foreach(var target in new[]{new Vector3(2.9f,0,-6.35f),new Vector3(-1,0,-10.2f),new Vector3(13.45f,0,-3.95f),new Vector3(6.45f,0,-2.95f),new Vector3(10,0,-.95f)})Check(g.Navigation.Path(new Vector3(10,0,-1.4f),target)!=null,"Unreachable exploration point: "+target);
                report.passed.Add("Room, balcony, bed, door and basement entrance navigation");
                g.ChangeDay(2);g.Reply("tv","核对原始记录");Check(!g.Has("timeline"),"Premature truth");g.Reply("mirror","给我私人影像");Check(!g.Has("presence"),"Privacy bypass");
                g.Reply("mirror","想核实那晚有没有人被困");g.Reply("lock","那晚的原始门禁记录");g.Reply("light","周岚那晚走过哪里");Check(g.Has("presence")&&g.Has("access")&&g.Has("motion"),"Evidence collection");g.Reply("tv","核对时间线");Check(!g.Has("timeline"),"Authorization bypass");g.Reply("mirror","不要把记录给知秋");Check(!g.state.authMirror,"Negative authorization");
                g.Reply("light","保留记录并授权给知秋");g.Reply("lock","把原始记录授权给知秋");g.Reply("mirror","只展示时间和人数给知秋");g.Reply("tv","现在对照原始记录");Check(g.Has("timeline"),"Raw timeline");report.passed.Add("Nonlinear evidence, privacy and three separate authorizations");
                g.Reply("waterer","先停止浇水，这是我的决定");g.Reply("ac","吹干盆底的纸");g.Inspect("backup");g.Inspect("panel");g.Inspect("chair");g.Reply("vacuum","充电座后面那块钢片呢");g.ChangeDay(3);g.Reply("lock","用钢片撬开门");Check(!g.Has("open"),"Premature mechanical exit");g.Reply("speaker","把白管里的线接上");Check(!g.Has("wire"),"Missing tools bypass");
                g.Reply("vacuum","有短螺丝刀和垫圈吗");g.Reply("ac","把风小一点");g.Reply("speaker","把套着白管的线接上");g.Reply("speaker","不要接备用电");Check(!g.Has("powered"),"Negative power");g.Reply("speaker","把备用电接到你这边供广播");g.Reply("speaker","录下陈实的姓名和1907房间号");g.Reply("speaker","把这份录音发出去");Check(g.Has("sent"),"Broadcast");report.passed.Add("Tools, wiring, finite power and spoken broadcast");
                g.Reply("mirror","授权把必要的存在证明交给老扣和大呼");g.Reply("lock","请用现场证明机械复核");g.Inspect("chair");Check(!g.Has("rope"),"Click solved puzzle");g.Reply("lock","踩着椅子揭开门框盖板，找红绳");g.Reply("lock","用钢片顶住，再拉红绳");Check(!g.Has("open"),"Unstable chair");g.Reply("lock","用垫圈垫稳椅子短腿");g.Reply("lock","用钢片顶住锈处，再拉红绳并压下把手");Check(g.Has("open"),"Mechanical release");g.Inspect("door");g.Reply("speaker","我出来了，末尾加上这句");g.Inspect("console");g.Inspect("pullLamp");Check(g.state.ending=="canon","Canonical ending");report.passed.Add("Conversational mechanical escape, offline receipt and canonical ending");
                g.Save(1);g.BeginGame();Check(g.Load(1)&&g.state.ending=="canon"&&g.Has("offline"),"Save/load");g.BeginGame();g.FinishOpening();g.ChangeDay(3);g.Reply("hub","不接受恢复资格");Check(string.IsNullOrEmpty(g.state.ending),"Negative deal");g.Reply("hub","如果接受恢复资格会怎样？");Check(string.IsNullOrEmpty(g.state.ending),"Question accepted as consent");g.Reply("hub","接受，把材料交给统一复核");Check(g.state.ending=="stay","Alternative ending");report.passed.Add("Save/load, conditional consent and alternative ending");
                g.BeginGame();g.FinishOpening();g.Teleport(8,7,0);report.renderers=g.GetComponentsInChildren<MeshRenderer>().Length;report.status="passed";
            }
            catch(Exception e){report.status="failed";report.error=e.ToString();Debug.LogException(e);}
            File.WriteAllText("Assets/ThirdDay/ValidationReport.json",JsonUtility.ToJson(report,true));
            yield return new WaitForSecondsRealtime(3);
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("Assets/ThirdDay/Validation-Game.png"));
            float start=Time.realtimeSinceStartup;int frames=0;while(frames<90){frames++;yield return null;}report.sampledFrameMilliseconds=(Time.realtimeSinceStartup-start)*1000/frames;
            File.WriteAllText("Assets/ThirdDay/ValidationReport.json",JsonUtility.ToJson(report,true));Debug.Log("[ThirdDay] Validation "+report.status+": "+report.passed.Count+" checks. "+report.error);
            g.ShowMenu();yield return new WaitForSeconds(.5f);done();
        }
    }
}
