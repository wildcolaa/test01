using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
namespace ThirdDay.Editor {
public static class ApartmentCooperationReview {
 [Serializable] class Report {public string status="running",error="";public List<string> passed=new List<string>();}
 static void Check(bool b,string message){if(!b)throw new Exception(message);}
 static void Play(ApartmentGame g){typeof(ApartmentGame).GetProperty("Mode").GetSetMethod(true).Invoke(g,new object[]{"play"});}
 [MenuItem("Third Day/Legacy V1/Review Cooperation")]
 public static void Start(){if(!EditorApplication.isPlaying)return;var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Cooperation review").AddComponent<ApartmentValidationHost>().StartCoroutine(Run(g));}
 static IEnumerator Run(ApartmentGame g){var r=new Report();g.validationMode=true;try{
  g.BeginGame();g.AdvanceIntro();g.AdvanceIntro();g.AdvanceIntro();g.SendText("这里太黑了，帮忙照亮");Check(g.state.opened,"Natural opening blocked");
  g.Teleport(13.45,3.95,0);g.InteractNearest();Check(g.state.day==2,"E at bed intercepted by nearby NPC");r.passed.Add("Natural opening and real E interaction advances first day");
  g.BeginGame();g.FinishOpening();g.Reply("ac","吹干盆底的纸");Check(!g.state.paperDry,"Drying ignored incoming water");g.Reply("waterer","啾啾让你停止浇水");Check(!g.state.waterStop,"Distrust had no consequence");g.Reply("waterer","先停止浇水，这是我的决定");Check(g.state.waterStop,"Direct responsibility rejected");g.Inspect("backup");Check(!g.Has("notes"),"Wet paper gate bypassed");g.Reply("ac","吹干盆底的纸");g.Inspect("backup");Check(g.Has("notes")&&g.state.paperDry,"Waterer and AC cooperation failed");Play(g);r.passed.Add("Waterer distrust, direct consent, AC drying and recoverable paper");
  g.BeginGame();g.FinishOpening();g.Reply("waterer","停下浇水");g.Reply("fridge","拿一块干毛巾");g.Inspect("backup");Check(g.Has("notes"),"Cloth alternative failed");Play(g);r.passed.Add("Fridge cloth provides alternative route");
  g.Reply("vacuum","都是你的错");g.ChangeDay(2);g.Reply("vacuum","充电座后面的钢片");Check(!g.Has("steel"),"Hostility had no consequence");g.Reply("light","照清地上的血迹");g.Reply("vacuum","扫描地上的血迹");g.Reply("vacuum","充电座后面的钢片");Check(g.Has("traceScan")&&g.Has("steel"),"Verifiable scan did not repair cooperation");r.passed.Add("Light and vacuum scan, hostility and evidence-based repair");
  g.Reply("vacuum","擦掉地上的血迹");var vacuum=g.GetComponentsInChildren<Transform>().First(t=>t.name=="Vacuum");vacuum.position=g.Navigation.Nearest(new Vector3(9.2f,0,-2.6f));typeof(ApartmentGame).GetMethod("UpdateCooperation",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(g,new object[]{.016f});Check(g.state.traceCleaned,"Cleaning did not change scene");Check(!g.GetComponentsInChildren<Transform>(true).First(t=>t.name=="FloorTrace").gameObject.activeSelf,"Trace still visible");g.Reply("vacuum","读取尘盒扫描");Check(g.Has("traceScan"),"Cleaning destroyed only evidence");r.passed.Add("Physical cleaning removes trace while preserving archive");
  g.Reply("speaker","换舒缓的音乐");Check(g.state.musicMood==1&&Mathf.Abs(g.GetComponent<AudioSource>().pitch-.82f)<.01f,"Music did not change audio");g.Reply("speaker","停止音乐");Check(g.GetComponent<AudioSource>().mute,"Music stop failed");g.Reply("speaker","恢复原来的音乐");g.Reply("light","调暗灯光");Check(g.state.lightsOn&&g.state.lightLevel<.5f,"Dimming switched light off");r.passed.Add("Real soundtrack changes and actual light dimming");
  g.Reply("mirror","想核实那晚有没有人被困");g.Reply("lock","那晚的原始门禁记录");g.Reply("light","周岚那晚走过哪里");g.Reply("light","保留记录并授权给知秋");g.Reply("lock","把原始记录授权给知秋");g.Reply("mirror","只展示时间和人数给知秋");g.Reply("tv","现在对照原始记录");Check(g.Has("timeline"),"Independent original records failed");
  g.Inspect("panel");g.Inspect("chair");g.ChangeDay(3);g.Reply("vacuum","短螺丝刀和垫圈");g.Reply("speaker","把白管的线接上");Check(!g.Has("wire"),"Noisy line test bypassed");g.Reply("ac","把风小一点");g.Reply("speaker","把白管的线接上");Check(g.Has("wire"),"Quiet line test failed");g.Reply("speaker","备用电供广播");g.Reply("speaker","录下陈实和1907房间号");g.Reply("speaker","把录音发出去");Check(g.Has("sent"),"Broadcast failed");r.passed.Add("AC quieting, speaker line test, finite power and broadcast");
  g.Reply("mirror","授权把必要的存在证明交给老扣和大呼");g.Reply("lock","用现场证明机械复核");g.Reply("lock","踩着椅子揭开门框盖板找红绳");g.Reply("lock","用垫圈垫稳椅子短腿");g.Reply("lock","用钢片顶住锈处，再拉红绳并压下把手");g.Inspect("door");g.Reply("speaker","出来了，末尾加上这句");g.Inspect("printer");g.Inspect("pullLamp");Check(g.state.ending=="canon","Cooperative canonical ending unreachable");r.passed.Add("Full cooperative escape, printer receipt and canonical ending");
  g.Save(2);g.BeginGame();Check(g.Load(2)&&g.Has("offline")&&g.state.traceCleaned&&g.state.airMode==1,"Capability state lost on load");g.BeginGame();g.FinishOpening();g.ChangeDay(3);g.Reply("hub","如果接受恢复资格会怎样？");Check(g.state.ending=="","Hypothetical triggered ending");g.Reply("hub","接受，把材料交给统一复核");Check(g.state.ending=="stay","Alternative ending broken");r.passed.Add("Save/load of capability state and both endings");r.status="passed";
 }catch(Exception e){r.status="failed";r.error=e.ToString();Debug.LogException(e);}finally{g.ShowMenu();g.validationMode=false;Directory.CreateDirectory("Assets/ThirdDay/UIReview");File.WriteAllText("Assets/ThirdDay/UIReview/CooperationReview.json",JsonUtility.ToJson(r,true));}Debug.Log("[ThirdDay] Cooperation review: "+r.status);yield break;}
}
}
