using System;
using System.IO;
using System.Linq;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using TMPro;
namespace ThirdDay.Editor {
public static class ApartmentUIReview {
 [MenuItem("Third Day/Legacy V1/Review UI")]
 public static void Start(){if(!EditorApplication.isPlaying){Debug.LogError("先点击 Play。");return;}var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();var host=new GameObject("UI Review").AddComponent<ApartmentValidationHost>();host.StartCoroutine(Run(g));}
 static string dir="Assets/ThirdDay/UIReview";
 static Button Find(ApartmentGame g,string name)=>g.GetComponentsInChildren<Button>().First(b=>b.name==name&&b.gameObject.activeInHierarchy);
 static IEnumerator Shot(string name){yield return new WaitForSecondsRealtime(.65f);ScreenCapture.CaptureScreenshot(Path.GetFullPath(dir+"/"+name+".png"));yield return new WaitForEndOfFrame();yield return null;}
 static IEnumerator Run(ApartmentGame g){Directory.CreateDirectory(dir);g.validationMode=true;g.ShowMenu();yield return Shot("01-cover");Find(g,"新游戏").onClick.Invoke();yield return Shot("02-city-intro");g.AdvanceIntro();yield return Shot("03-allocation");g.AdvanceIntro();g.AdvanceIntro();yield return new WaitForSecondsRealtime(6);yield return Shot("04-dark-opening");var openingInput=g.GetComponentsInChildren<TMP_InputField>().First(x=>x.gameObject.activeInHierarchy);openingInput.text="小灯泡，开灯";openingInput.onSubmit.Invoke(openingInput.text);yield return new WaitForSecondsRealtime(.3f);g.Teleport(12.58,4.8,0);g.Proximity();g.InteractNearest();yield return Shot("05-device-dialogue");var f=g.GetComponentsInChildren<TMP_InputField>().First(x=>x.gameObject.activeInHierarchy);f.text="你好";f.onSubmit.Invoke(f.text);yield return Shot("06-dialogue-reply");g.ReadDocument("随身记录",new[]{"还没有记下什么。","日期相同，不一定说的是同一种资格。把各自记得的事并排看看。"});yield return Shot("07-record-paper");Find(g,"收好").onClick.Invoke();g.GetType().GetProperty("Mode").GetSetMethod(true).Invoke(g,new object[]{"pause"});yield return Shot("08-pause");Find(g,"读取").onClick.Invoke();yield return Shot("09-saves");Find(g,"返回").onClick.Invoke();yield return null;Find(g,"设置").onClick.Invoke();yield return Shot("10-settings");Find(g,"返回").onClick.Invoke();g.End("canon");yield return Shot("11-ending");g.ShowMenu();yield return Shot("12-cover-return");File.WriteAllText(dir+"/Review.json","{\"status\":\"passed\",\"screens\":12,\"renderer\":\"uGUI + TextMeshPro + custom Graphic + URP frost shader\",\"font\":\"Noto Sans SC / Noto Serif SC / JetBrains Mono\",\"checks\":[\"new-game button\",\"allocation paper\",\"light call\",\"proximity dialogue\",\"TMP input submit\",\"record close\",\"save list\",\"settings return\",\"ending\",\"cover return\"]}");Debug.Log("[ThirdDay] UI review passed, 12 screenshots.");}
}}
