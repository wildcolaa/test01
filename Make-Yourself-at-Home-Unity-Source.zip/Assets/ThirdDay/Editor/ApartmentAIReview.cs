using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
namespace ThirdDay.Editor {
 public static class ApartmentAIReview {
  [Serializable]class Turn{public string character,question,reply,source;}
  [Serializable]class Report{public string status="running";public List<Turn> turns=new List<Turn>();public bool groundedAction;}
  static Report report;
  [MenuItem("Third Day/Legacy V1/Review AI Dialogue")]
  public static void Start(){if(!EditorApplication.isPlaying)return;var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Live AI dialogue review").AddComponent<ApartmentValidationHost>().StartCoroutine(Run(g));}
  static IEnumerator Ask(ApartmentGame g,string text){g.SendText(text);float until=Time.realtimeSinceStartup+35;while(g.LastReplySource=="pending"&&Time.realtimeSinceStartup<until)yield return null;report.turns.Add(new Turn{character=g.DeviceName(g.TalkingTo),question=text,reply=g.LastSpeech,source=g.LastReplySource});if(g.LastReplySource!="model")throw new Exception("Live actor generation failed: "+g.LastAIError);}
  static IEnumerator Run(ApartmentGame g){report=new Report();g.validationMode=true;try{
   g.BeginGame();g.FinishOpening();g.Teleport(12.58,4.8,0);g.OpenTalk("speaker");
   yield return Ask(g,"你好，你平时喜欢听什么声音？");yield return Ask(g,"你刚才说的那些声音，为什么会喜欢呢？");
   g.Teleport(12.7,9.75,0);g.OpenTalk("fridge");yield return Ask(g,"一个人住有点孤单，你会怎么陪我？");
   g.Teleport(5.75,9.45,0);g.OpenTalk("light");yield return Ask(g,"把灯调暗一点，今天眼睛很累。");report.groundedAction=g.state.lightsOn&&g.state.lightLevel<.5f;if(!report.groundedAction)throw new Exception("Model bypassed local action");report.status="passed";
  }finally{g.validationMode=false;g.ShowMenu();Directory.CreateDirectory("Assets/ThirdDay/UIReview");File.WriteAllText("Assets/ThirdDay/UIReview/AIReview.json",JsonUtility.ToJson(report,true));}Debug.Log("[ThirdDay] Live personality dialogue review: "+report.status);}
 }
}
