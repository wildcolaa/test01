using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace ThirdDay.Editor
{
    [InitializeOnLoad]
    public static class ApartmentGameView
    {
        const BindingFlags Flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
        static ApartmentGameView(){EditorApplication.playModeStateChanged+=OnPlay;}

        static void OnPlay(PlayModeStateChange state)
        {
            if(state!=PlayModeStateChange.EnteredPlayMode||!UnityEngine.Object.FindFirstObjectByType<ApartmentGame>())return;
            Show();EditorApplication.delayCall+=Show;
        }

        [MenuItem("Third Day/Fit Game Preview")]
        public static void Show()
        {
            // Unity 6 retains Game View zoom and pan across sessions. A zoomed preview
            // can crop the entire left-hand start menu even though it renders correctly.
            var type=typeof(EditorWindow).Assembly.GetType("UnityEditor.GameView");
            if(type==null)return;
            var window=EditorWindow.GetWindow(type);window.Show();window.Focus();
            try
            {
                // Render at the physical pixel density instead of enlarging a low-DPI image.
                type.GetProperty("lowResolutionForAspectRatios",Flags)?.SetValue(window,false);
                var serialized=new SerializedObject(window);var filter=serialized.FindProperty("m_TextureFilterMode");
                if(filter!=null){filter.intValue=(int)FilterMode.Bilinear;serialized.ApplyModifiedPropertiesWithoutUndo();}
                type.GetMethod("UpdateZoomAreaAndParent",Flags)?.Invoke(window,null);
                var fit=(float)(type.GetProperty("minScale",Flags)?.GetValue(window)??1f);
                var area=type.GetField("m_ZoomArea",Flags)?.GetValue(window);
                area?.GetType().GetMethod("SetTransform",Flags,null,new[]{typeof(Vector2),typeof(Vector2)},null)?.Invoke(area,new object[]{Vector2.zero,Vector2.one*fit});
                type.GetMethod("SnapZoom",Flags)?.Invoke(window,new object[]{fit});
                type.GetField("m_Stats",Flags)?.SetValue(window,false);
                type.GetField("m_Gizmos",Flags)?.SetValue(window,false);
            }
            catch(Exception e){Debug.LogWarning("[ThirdDay] Preview fit: "+e.GetBaseException().Message);}
            window.Repaint();
        }

        [MenuItem("Third Day/Full HD Preview")]
        public static void FullHD()
        {
            var assembly=typeof(EditorWindow).Assembly;var type=assembly.GetType("UnityEditor.GameView");
            var sizesType=assembly.GetType("UnityEditor.GameViewSizes");
            var sizes=sizesType.BaseType.GetProperty("instance",BindingFlags.Public|BindingFlags.Static).GetValue(null);
            var group=sizesType.GetProperty("currentGroup",Flags).GetValue(sizes);var groupType=group.GetType();
            int count=(int)groupType.GetMethod("GetTotalCount").Invoke(group,null);
            var window=EditorWindow.GetWindow(type);
            for(int i=0;i<count;i++){
                var size=groupType.GetMethod("GetGameViewSize").Invoke(group,new object[]{i});var sizeType=size.GetType();
                if((int)sizeType.GetProperty("width").GetValue(size)==1920&&(int)sizeType.GetProperty("height").GetValue(size)==1080){type.GetProperty("selectedSizeIndex",Flags).SetValue(window,i);break;}
            }
            Show();
        }
    }
}
