using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
namespace ThirdDay.Editor {
 [InitializeOnLoad] public static class ApartmentDisplayProfile {
  // Keep the installation marker outside the exported Assets bundle, so importing
  // the bundle into another project applies the display settings there as well.
  const string Marker="ProjectSettings/ThirdDayDisplayProfile.txt";
  static ApartmentDisplayProfile(){EditorApplication.delayCall+=Install;}
  static void Install(){
   if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling||File.Exists(Marker)||!File.Exists("Assets/ThirdDay/Scenes/ThirdDay.unity"))return;
   var pipeline=QualitySettings.renderPipeline as UniversalRenderPipelineAsset;
   if(!pipeline)pipeline=GraphicsSettings.defaultRenderPipeline as UniversalRenderPipelineAsset;
   if(pipeline){pipeline.renderScale=1;pipeline.msaaSampleCount=4;EditorUtility.SetDirty(pipeline);}
   PlayerSettings.defaultScreenWidth=1920;PlayerSettings.defaultScreenHeight=1080;PlayerSettings.resizableWindow=true;
   ApartmentGameView.FullHD();AssetDatabase.SaveAssets();
   File.WriteAllText(Marker,"1920 x 1080 default window; native render scale 1; 4x MSAA; high-DPI preview; bilinear preview filtering.");
   Debug.Log("[ThirdDay] Full HD display profile installed.");
  }
 }
}
