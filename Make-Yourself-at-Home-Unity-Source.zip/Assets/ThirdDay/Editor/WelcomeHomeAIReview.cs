using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
namespace ThirdDay.Editor {
 [InitializeOnLoad] public static class WelcomeHomeAIReview {
  const BindingFlags F=BindingFlags.Instance|BindingFlags.NonPublic;
  [Serializable]class Report {public string status="running",error="",model;public bool semanticLight,freeReply,semanticAgent,residentNameUsed,speechExpired;}
  static WelcomeHomeAIReview(){EditorApplication.playModeStateChanged+=s=>{if(s==PlayModeStateChange.EnteredPlayMode&&SessionState.GetBool("Welcome.AI",false)){SessionState.SetBool("Welcome.AI",false);new GameObject("Welcome AI review").AddComponent<WelcomeReviewHost>().StartCoroutine(Run());}};}
  public static void BeginBatch(){SessionState.SetBool("Welcome.AIBatch",true);Begin();}
  [MenuItem("Third Day/Review Welcome Home AI")]
  public static void Begin(){if(EditorApplication.isPlaying){new GameObject("Welcome AI review").AddComponent<WelcomeReviewHost>().StartCoroutine(Run());return;}SessionState.SetBool("Welcome.AI",true);EditorSceneManager.OpenScene("Assets/ThirdDay/Scenes/ThirdDay.unity");EditorApplication.isPlaying=true;}
  static IEnumerator Run(){var g=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();var report=new Report{model=PlayerPrefs.GetString("ThirdDay.Model","openai/gpt-oss-120b")};g.validationMode=true;
   if(string.IsNullOrWhiteSpace(PlayerPrefs.GetString("ThirdDay.Key","")))report.status="skipped_no_key";
   else {
    g.BeginGame();g.ConfirmResidentName("林舟");g.FinishOpening();g.Teleport(5.75,9.45,0);g.OpenTalk("light");g.Say("light","林舟，灯亮着。");yield return new WaitForSecondsRealtime(2.05f);report.speechExpired=!((RectTransform)typeof(ApartmentGame).GetField("speechRoot",F).GetValue(g)).gameObject.activeSelf;g.SendText("这盏灯照得眼睛有点晃，把亮度收下来，好吗？");float until=Time.realtimeSinceStartup+40;while((bool)typeof(ApartmentGame).GetField("busy",F).GetValue(g)&&Time.realtimeSinceStartup<until)yield return null;report.semanticLight=g.state.lightLevel<.5f&&g.LastDeviceAction=="light_dim";
    g.SendText("请说出登记的住户姓名，除此以外不写其他内容。");until=Time.realtimeSinceStartup+40;while((bool)typeof(ApartmentGame).GetField("busy",F).GetValue(g)&&Time.realtimeSinceStartup<until)yield return null;report.freeReply=g.LastReplySource=="model"&&!string.IsNullOrWhiteSpace(g.LastSpeech);report.residentNameUsed=g.LastSpeech.Contains("林舟")&&!g.LastSpeech.Contains("陈实");
    g.ChangeDay(2);g.Reply("mirror","核实陆川跌倒医疗记录");g.Reply("tv","查询调度缓存");typeof(ApartmentGame).GetField("input",F).SetValue(g,"这两份出处帮忙放在一起看看，有什么对不上的地方？");typeof(ApartmentGame).GetMethod("Friend",F).Invoke(g,null);until=Time.realtimeSinceStartup+40;while((bool)typeof(ApartmentGame).GetField("friendBusy",F).GetValue(g)&&Time.realtimeSinceStartup<until)yield return null;report.semanticAgent=g.state.welcome.evidence.Count(e=>e.verified)>=2;
    report.status=report.semanticLight&&report.freeReply&&report.semanticAgent&&report.residentNameUsed&&report.speechExpired?"passed":"failed";if(report.status=="failed")report.error="检查语义动作、自由闲聊与手机代理工具的结果；未记录服务密钥。";
   }
   Directory.CreateDirectory("Assets/ThirdDay/UIReview");File.WriteAllText("Assets/ThirdDay/UIReview/WelcomeAIReview.json",JsonUtility.ToJson(report,true));Debug.Log("[Welcome AI] "+report.status);g.ShowMenu();g.validationMode=false;if(SessionState.GetBool("Welcome.AIBatch",false))EditorApplication.Exit(report.status=="failed"?1:0);
  }
 }
}
