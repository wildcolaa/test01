using System;
using System.IO;
using System.Collections;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
namespace ThirdDay.Editor {
 [InitializeOnLoad] public static class WelcomeHomeVisualReview {
  const string Dir="Assets/ThirdDay/UIReview/WelcomeV2";
  static WelcomeHomeVisualReview(){EditorApplication.playModeStateChanged+=s=>{if(s==PlayModeStateChange.EnteredPlayMode&&SessionState.GetBool("Welcome.Visual",false)){SessionState.SetBool("Welcome.Visual",false);StartRun();}};}
  public static void BeginBatch(){SessionState.SetBool("Welcome.VisualBatch",true);Begin();}
  static ApartmentGame game;
  static void StartRun(){game=UnityEngine.Object.FindFirstObjectByType<ApartmentGame>();new GameObject("Welcome visual review").AddComponent<WelcomeReviewHost>().StartCoroutine(Run(game));}
  [MenuItem("Third Day/Review Welcome Home Visuals")]
  public static void Begin(){Directory.CreateDirectory(Dir);if(EditorApplication.isPlaying){StartRun();return;}SessionState.SetBool("Welcome.Visual",true);EditorSceneManager.OpenScene("Assets/ThirdDay/Scenes/ThirdDay.unity");EditorApplication.isPlaying=true;}
  static IEnumerator Shot(string file){yield return new WaitForSecondsRealtime(1.2f);Capture(file);yield return null;}
  static void Capture(string file){
   var canvas=game.GetComponentInChildren<Canvas>();var mode=canvas.renderMode;var camera=canvas.worldCamera;var rt=new RenderTexture(1920,1080,24);var active=RenderTexture.active;game.View.targetTexture=rt;canvas.renderMode=RenderMode.ScreenSpaceCamera;canvas.worldCamera=game.View;canvas.planeDistance=10;Canvas.ForceUpdateCanvases();
   typeof(ApartmentGame).GetMethod("LateUpdate",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(game,null);Canvas.ForceUpdateCanvases();game.View.Render();RenderTexture.active=rt;var tex=new Texture2D(1920,1080,TextureFormat.RGB24,false);tex.ReadPixels(new Rect(0,0,1920,1080),0,0);tex.Apply();File.WriteAllBytes(Dir+"/"+file+".png",tex.EncodeToPNG());RenderTexture.active=active;game.View.targetTexture=null;canvas.renderMode=mode;canvas.worldCamera=camera;UnityEngine.Object.Destroy(tex);rt.Release();UnityEngine.Object.Destroy(rt);
  }
  static IEnumerator Run(ApartmentGame g){
   g.validationMode=true;g.ShowMenu();yield return Shot("01-cover");
   g.BeginGame();typeof(ApartmentGame).GetField("residentNameDraft",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(g,"林舟");yield return Shot("00-resident-name");g.ConfirmResidentName("林舟");g.AdvanceIntro();yield return new WaitForSecondsRealtime(7);yield return Shot("02-allocation");
   g.AdvanceIntro();g.AdvanceIntro();yield return new WaitForSecondsRealtime(1.8f);yield return Shot("03-opening-from-bottom");
   g.FinishOpening();g.Teleport(7.8,5.9,0);yield return Shot("04-apartment");
   g.ChangeDay(2);g.Inspect("notice");yield return Shot("05-protocol");
   g.Reply("ac","安排维护窗口");g.Inspect("hatch");yield return Shot("06-equipment-room");g.Inspect("ladder");
   g.Reply("mirror","核实陆川跌倒医疗记录");g.Reply("tv","查询调度缓存");g.Reply("tv","查询实验编号");g.Reply("xb","核对材料来源");g.Reply("xb","提交违规审计");g.Reply("xb","查询独立受理");g.Reply("xb","查询正式终止结果");g.Teleport(10,1,0);g.Reply("xb","执行完整放行");yield return new WaitForSecondsRealtime(2);g.Reply("lock","核验授权并解锁");g.Inspect("door");yield return Shot("07-completed-release");
   g.BeginGame();g.ConfirmResidentName("林舟");g.FinishOpening();g.ChangeDay(3);for(int i=0;i<3;i++)g.Reply("hub","继续等待评估");yield return Shot("08-loop");
   File.WriteAllText(Dir+"/VisualReview.json","{\"captured\":9,\"scope\":\"cover, allocation, opening, room, protocol, basement, E01, E06\"}");g.ShowMenu();g.validationMode=false;if(SessionState.GetBool("Welcome.VisualBatch",false))EditorApplication.Exit(0);
  }
 }
}
