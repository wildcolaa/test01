using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;
namespace ThirdDay {
 public sealed class ApartmentSendFeedback:MonoBehaviour,IPointerDownHandler,IPointerUpHandler,IPointerEnterHandler,IPointerExitHandler {
  public Color restingText=new Color32(27,28,31,255),restingPanel=Color.clear,hoverPanel=new Color(1,1,1,.25f);
  ApartmentGraphic panel;TMP_Text label;Vector2 original;bool held,hover;float flashUntil;
  void Awake(){panel=GetComponent<ApartmentGraphic>();label=GetComponentInChildren<TMP_Text>();original=label.rectTransform.anchoredPosition;GetComponent<Button>().transition=Selectable.Transition.None;}
  public void Pulse(){flashUntil=Time.unscaledTime+.14f;Paint();}
  public void OnPointerDown(PointerEventData e){if(!GetComponent<Button>().IsInteractable())return;held=true;Paint();}
  public void OnPointerUp(PointerEventData e){held=false;Pulse();}
  public void OnPointerEnter(PointerEventData e){hover=true;Paint();}
  public void OnPointerExit(PointerEventData e){hover=false;held=false;Paint();}
  void LateUpdate(){Paint();}
  void Paint(){if(!panel||!label)return;bool pressed=held||Time.unscaledTime<flashUntil;panel.color=pressed?new Color32(69,71,77,255):hover?hoverPanel:restingPanel;label.color=pressed?new Color32(233,234,236,255):restingText;label.rectTransform.anchoredPosition=original+new Vector2(0,pressed?-1:0);}
 }
}
