using System;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
namespace ThirdDay {
public partial class ApartmentGame {
 AudioClip recorded;bool recording,voiceShortcutHeld,voiceForFriend;string voiceMode,voiceId,voiceStatus="";float voiceStarted;
 void HandleVoiceShortcut(){
  var keyboard=UnityEngine.InputSystem.Keyboard.current;
  if(keyboard==null){if(voiceShortcutHeld)CancelVoice();return;}
  if(keyboard.spaceKey.wasPressedThisFrame&&!Typing&&!settingsOpen&&uiInput&&(Mode=="talk"||Mode=="dark"||PhoneFriendOpen)){StartVoice();voiceShortcutHeld=recording;}
  if(voiceShortcutHeld&&keyboard.spaceKey.wasReleasedThisFrame){voiceShortcutHeld=false;StopVoice();}
  if(recording&&Time.unscaledTime-voiceStarted>=28){voiceShortcutHeld=false;StopVoice();}
 }
 void StartVoice(){
  if(recording||busy)return;
  if(string.IsNullOrWhiteSpace(key)){voiceStatus=status="请先在设置中填写语音服务密钥。";return;}
  if(Microphone.devices.Length==0){voiceStatus=status="没有找到麦克风。";return;}
  try{voiceForFriend=PhoneFriendOpen;voiceMode=Mode;voiceId=TalkingTo;recorded=Microphone.Start(null,false,30,16000);recording=recorded!=null;voiceStarted=Time.unscaledTime;voiceStatus=recording?"正在录音，松开空格或麦克风发送。":"麦克风未能启动，请检查设备。";}
  catch(Exception){recording=false;voiceStatus=status="麦克风未能启动，请检查设备。";}
 }
 void CancelVoice(){if(recording)Microphone.End(null);recording=false;voiceShortcutHeld=false;voiceStatus="";if(recorded)Destroy(recorded);recorded=null;}
 void StopVoice(){if(!recording)return;int samples=Microphone.GetPosition(null);Microphone.End(null);recording=false;voiceShortcutHeld=false;if(samples>1600){voiceStatus="正在识别语音……";StartCoroutine(Transcribe(recorded,samples));}else{voiceStatus="录音太短，请按住空格或麦克风说话。";if(recorded)Destroy(recorded);}recorded=null;}
 IEnumerator Transcribe(AudioClip clip,int count){bool toFriend=voiceForFriend;var data=new float[count*clip.channels];clip.GetData(data,0);byte[] wav;using(var s=new MemoryStream())using(var w=new BinaryWriter(s)){w.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));w.Write(36+data.Length*2);w.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));w.Write(16);w.Write((short)1);w.Write((short)clip.channels);w.Write(clip.frequency);w.Write(clip.frequency*clip.channels*2);w.Write((short)(clip.channels*2));w.Write((short)16);w.Write(System.Text.Encoding.ASCII.GetBytes("data"));w.Write(data.Length*2);foreach(var f in data)w.Write((short)(Mathf.Clamp(f,-1,1)*32767));wav=s.ToArray();}Destroy(clip);var fields=new List<IMultipartFormSection>{new MultipartFormFileSection("file",wav,"speech.wav","audio/wav"),new MultipartFormDataSection("model","whisper-large-v3-turbo"),new MultipartFormDataSection("language","zh")};using(var req=UnityWebRequest.Post("https://api.groq.com/openai/v1/audio/transcriptions",fields)){req.SetRequestHeader("Authorization","Bearer "+key);req.timeout=30;yield return req.SendWebRequest();voiceStatus="";if(req.result==UnityWebRequest.Result.Success&&Mode==voiceMode&&TalkingTo==voiceId&&(!toFriend||PhoneFriendOpen)){var result=JsonUtility.FromJson<VoiceText>(req.downloadHandler.text);if(toFriend){input=result.text;Friend();}else SendText(result.text);}else{voiceStatus=status="语音未发送，请重试或打字。";if(Mode=="talk")Say(TalkingTo,status);}}}
 [Serializable]class VoiceText{public string text;}
 IEnumerator TestConnection(){if(string.IsNullOrWhiteSpace(key)){status="请先填写密钥。";uiSignature=null;yield break;}using(var req=UnityWebRequest.Get("https://api.groq.com/openai/v1/models")){req.SetRequestHeader("Authorization","Bearer "+key);req.timeout=15;yield return req.SendWebRequest();status=req.result==UnityWebRequest.Result.Success?"连接成功。":"连接失败，请核对密钥与网络。";uiSignature=null;}}
}}
