using UnityEngine;
using UnityEngine.UI;
namespace ThirdDay {
[RequireComponent(typeof(CanvasRenderer))] public sealed class ApartmentGraphic:MaskableGraphic {
 public enum Shape {Panel,Tab,Gradient,Phone,Microphone,LightPoint} public Shape shape;public Color edge=new Color(.106f,.11f,.122f,.28f);public float stroke=1;
 protected override void OnPopulateMesh(VertexHelper v){v.Clear();var r=rectTransform.rect;
 if(shape==Shape.LightPoint){Disc(v,r.center,r.width*.5f,new Color(color.r,color.g,color.b,color.a*.25f),true);Disc(v,r.center,r.width*.16f,color,false);return;}
 if(shape==Shape.Phone){Line(v,r.x+9,r.y+7,24,38,color);Box(v,r.x+17,r.y+11,8,1,color);return;}
 if(shape==Shape.Microphone){Line(v,r.center.x-3,r.center.y-2,6,11,color);Box(v,r.center.x-6,r.center.y-4,1,7,color);Box(v,r.center.x+5,r.center.y-4,1,7,color);Box(v,r.center.x-6,r.center.y-5,12,1,color);Box(v,r.center.x,r.center.y-9,1,4,color);return;}
 if(shape==Shape.Gradient){Quad(v,r,color,new Color(color.r,color.g,color.b,0));return;}
 if(shape==Shape.Tab){Box(v,r.x,r.y,r.width-12,r.height,color);int i=v.currentVertCount;v.AddVert(new Vector3(r.xMax-12,r.y),color,Vector2.zero);v.AddVert(new Vector3(r.xMax,r.y),color,Vector2.zero);v.AddVert(new Vector3(r.xMax-12,r.yMax),color,Vector2.zero);v.AddTriangle(i,i+1,i+2);return;}
 Box(v,r.x,r.y,r.width,r.height,color);Line(v,r.x,r.y,r.width,r.height,edge);}
 void Line(VertexHelper v,float x,float y,float w,float h,Color c){Box(v,x,y,w,stroke,c);Box(v,x,y+h-stroke,w,stroke,c);Box(v,x,y,stroke,h,c);Box(v,x+w-stroke,y,stroke,h,c);}
 void Disc(VertexHelper v,Vector2 centre,float radius,Color c,bool fade){int start=v.currentVertCount;v.AddVert(centre,c,Vector2.zero);for(int i=0;i<=24;i++){float a=i*Mathf.PI*2/24;var edgeColor=c;if(fade)edgeColor.a=0;v.AddVert(centre+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*radius,edgeColor,Vector2.zero);if(i>0)v.AddTriangle(start,start+i,start+i+1);}}
 void Box(VertexHelper v,float x,float y,float w,float h,Color c){Quad(v,new Rect(x,y,w,h),c,c);}
 void Quad(VertexHelper v,Rect r,Color a,Color b){int i=v.currentVertCount;v.AddVert(new Vector3(r.x,r.y),a,Vector2.zero);v.AddVert(new Vector3(r.x,r.yMax),a,Vector2.up);v.AddVert(new Vector3(r.xMax,r.yMax),b,Vector2.one);v.AddVert(new Vector3(r.xMax,r.y),b,Vector2.right);v.AddTriangle(i,i+1,i+2);v.AddTriangle(i,i+2,i+3);}
}}
