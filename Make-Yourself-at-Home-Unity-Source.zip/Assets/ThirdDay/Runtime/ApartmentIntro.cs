using System.Collections.Generic;
using TMPro;
using UnityEngine;
namespace ThirdDay {
public partial class ApartmentGame {
 sealed class IntroLine {public TextMeshProUGUI label;public int count,shown=-1;public float start,duration;}
 readonly List<IntroLine> introLines=new List<IntroLine>();
 int introRun,introMountedRun=-1;float introStarted,introNextLine;bool introSkip;TextMeshProUGUI introContinue;
 void ResetIntroPlayback(){introRun++;introSkip=false;introLines.Clear();}
 void HandleIntroClick(){if(Mode!="intro")return;if(!introSkip&&Time.unscaledTime-introStarted<introNextLine){introSkip=true;UpdateIntroPlayback();return;}AdvanceIntro();}
 void IntroTyped(TextMeshProUGUI label,float speed=.055f,float pause=.5f){label.ForceMeshUpdate();int count=label.textInfo.characterCount;introLines.Add(new IntroLine{label=label,count=count,start=introNextLine,duration=count*speed});label.maxVisibleCharacters=0;introNextLine+=count*speed+pause;}
 void Intro(){
  if(introMountedRun!=introRun){introMountedRun=introRun;introStarted=Time.unscaledTime;}
  introLines.Clear();introNextLine=.3f;
  Shade(new Color(.015f,.02f,.03f,.55f));Button(page,new Rect(0,0,Width,Height),"",HandleIntroClick,true);
  if(!coverHoverFrost){var shader=Resources.Load<Shader>("UI/CoverHoverFrost");if(shader)coverHoverFrost=new Material(shader);}
  var light=new Color32(225,230,237,255);var dim=new Color32(151,162,178,255);
  bool allocation=intro==1;float w=Mathf.Min(allocation?480:580,Width-48),h=allocation?370:300;var rect=Center(w,h);
  var background=Panel(page,rect,Color.white,"Arrival terminal");background.material=coverHoverFrost;background.edge=Color.clear;
  var p=background.rectTransform;Panel(p,new Rect(0,0,w,h),Color.clear,"Terminal outline").edge=new Color(1,1,1,.16f);
  var tab=Panel(p,new Rect(0,-24,allocation?225:195,24),new Color32(69,71,77,235),"Arrival tab",ApartmentGraphic.Shape.Tab);
  Panel(tab.transform,new Rect(8,9,5,5),light).edge=Color.clear;
  Text(tab.transform,new Rect(23,3,190,18),allocation?"HOUSING / C-2717":"RESIDENCY / 1907",10,light,mono);
  if(allocation){
   Text(p,new Rect(28,25,w-56,38),"住房分配通知",23,light,sans);
   Panel(p,new Rect(28,78,w-56,1),new Color(1,1,1,.2f)).edge=Color.clear;
   string[] keys={"住户","分配住址","适应期","前住户","入住时间"},values={ResidentName,"第 14 栋 1907","三天","已迁出","第一天 17:40"};
   for(int i=0;i<keys.Length;i++){
    float y=96+i*39;Text(p,new Rect(28,y,90,25),keys[i],12,dim,sans);
    var value=Text(p,new Rect(132,y-1,w-160,28),values[i],15,light,sans);IntroTyped(value,.045f,.22f);
    Panel(p,new Rect(132,y+29,w-160,1),new Color(1,1,1,.1f)).edge=Color.clear;
   }
   IntroTyped(Text(p,new Rect(28,324,w-150,20),"城市住房分配中心 / 请按时入住",10,dim,sans),.035f,0);
   var status=Panel(p,new Rect(w-102,315,74,29),new Color(1,1,1,.06f),"Allocation status");status.edge=new Color(1,1,1,.25f);
   Text(status.transform,new Rect(0,0,74,29),"已分配",12,light,sans).alignment=TextAlignmentOptions.Center;
  }else{
   Text(p,new Rect(28,25,w-56,20),intro==0?"入住之前 / PRE-ARRIVAL":"1907 / ENTRY",11,dim,mono);
   Panel(p,new Rect(28,61,w-56,1),new Color(1,1,1,.16f)).edge=Color.clear;
   float y=intro==0?87:119;
   foreach(string line in introText[intro].Split('\n')){
    var text=Text(p,new Rect(28,y,w-56,60),line,19,light,sans);
    float lineHeight=Mathf.Max(32,text.GetPreferredValues(line,w-56,1000).y+12);text.rectTransform.sizeDelta=new Vector2(w-56,lineHeight);IntroTyped(text);y+=lineHeight+15;
   }
  }
  introContinue=Text(page,new Rect(0,rect.yMax+24,Width,24),"点击显示完整文字",11,dim,mono);introContinue.alignment=TextAlignmentOptions.Center;
  UpdateIntroPlayback();
 }
 void UpdateIntroPlayback(){
  if(Mode!="intro")return;float elapsed=Time.unscaledTime-introStarted;
  foreach(var line in introLines){if(!line.label)continue;int visible=introSkip?line.count:Mathf.Clamp(Mathf.FloorToInt((elapsed-line.start)/Mathf.Max(.001f,line.duration)*line.count),0,line.count);if(visible!=line.shown){line.label.maxVisibleCharacters=visible;line.shown=visible;}}
  if(introContinue)introContinue.text=introSkip||elapsed>=introNextLine?"点击继续":"点击显示完整文字";
 }
}
}
