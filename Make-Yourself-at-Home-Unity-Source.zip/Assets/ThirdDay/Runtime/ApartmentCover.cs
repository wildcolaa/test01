using System;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
namespace ThirdDay {
public partial class ApartmentGame {
 Material coverAtmosphere,coverHoverFrost;
 TMP_FontAsset coverPixel;
 void Menu(){
  if(!coverPixel){coverPixel=FontAsset("UI/CoverPixel");coverPixel.atlasTexture.filterMode=FilterMode.Point;}
  if(!coverHoverFrost){var shader=Resources.Load<Shader>("UI/CoverHoverFrost");if(shader)coverHoverFrost=new Material(shader);}
  if(!coverAtmosphere){var shader=Resources.Load<Shader>("UI/CoverAtmosphere");if(shader)coverAtmosphere=new Material(shader);}
  var veil=Panel(page,new Rect(0,0,Width,Height),Color.white,"Cover atmosphere");veil.edge=Color.clear;if(coverAtmosphere)veil.material=coverAtmosphere;
  bool narrow=Width<850;float x=narrow?34:64,w=Mathf.Min(410,Width-2*x);
  var cold=new Color32(222,226,233,255);var muted=new Color32(137,145,155,255);
  var tag=Panel(page,new Rect(x,52,203,24),tab,"Residency tab",ApartmentGraphic.Shape.Tab);
  Panel(tag.transform,new Rect(8,9,5,5),cold).edge=Color.clear;
  Text(tag.transform,new Rect(23,3,171,20),"RESIDENCY / 1907",10,cold,mono).characterSpacing=1.3f;
  Text(page,new Rect(x,98,w,18),"居  住  关  系  已  建  立",11,muted);
  var title=Node(page,"Make Yourself at Home",new Rect(x,142,w,145));
  var first=Text(title,new Rect(0,0,w,52),"MAKE YOURSELF",narrow?30:36,cold,coverPixel);first.textWrappingMode=TextWrappingModes.NoWrap;first.characterSpacing=.5f;
  var second=Text(title,new Rect(-3,42,w,100),"AT HOME",narrow?64:78,cold,coverPixel);second.textWrappingMode=TextWrappingModes.NoWrap;second.characterSpacing=0;
  Panel(page,new Rect(x,290,w,1),new Color(.7f,.74f,.8f,.25f)).edge=Color.clear;
  Text(page,new Rect(x,306,w,20),"适应期：三天。系统将持续评估。",12,muted);
  float menuWidth=Mathf.Min(360,w);var menu=Node(page,"Cover actions",new Rect(x-12,363,menuWidth,212));
  string[] labels={"继续","新游戏","读取记录","设置"};string[] english={"CONTINUE","NEW RESIDENT","RECORDS","SETTINGS"};
  Action[] actions={()=>Load(0),()=>{saveKind=null;BeginGame();},()=>saveKind="load",()=>settingsOpen=true};
  for(int i=0;i<labels.Length;i++){
   bool available=i!=0||File.Exists(SavePath(0));float y=i*51;
   var b=Button(menu,new Rect(0,y,menuWidth,45),labels[i],actions[i],true,available,cold);
   var backdrop=Panel(b.transform,new Rect(0,0,menuWidth,45),new Color(1,1,1,0),"Hover frost");backdrop.edge=Color.clear;backdrop.material=coverHoverFrost;backdrop.transform.SetAsFirstSibling();
   var label=b.GetComponentInChildren<TextMeshProUGUI>();label.fontSize=15;label.alignment=TextAlignmentOptions.MidlineLeft;label.rectTransform.anchoredPosition=new Vector2(12,0);label.rectTransform.sizeDelta=new Vector2(100,43);
   var hint=Text(b.transform,new Rect(112,0,menuWidth-145,43),english[i],10,available?muted:new Color32(74,81,91,255),mono);hint.alignment=TextAlignmentOptions.MidlineLeft;hint.characterSpacing=.8f;
   var line=Panel(b.transform,new Rect(0,14,2,16),cold,"Selection line");line.edge=Color.clear;
   var fx=b.gameObject.AddComponent<ApartmentCoverChoice>();fx.label=label.rectTransform;fx.hint=hint.rectTransform;fx.indicator=line;fx.backdrop=backdrop;fx.available=available;
  }
  Text(page,new Rect(x,Height-51,w,20),"WASD 移动  /  E 交互  /  N 记录",10,muted,mono);
  Text(page,new Rect(Width-300,Height-51,248,20),"RESIDENT STATUS : ACTIVE",10,muted,mono).alignment=TextAlignmentOptions.MidlineRight;
  var fade=page.gameObject.GetComponent<ApartmentCoverFade>();if(!fade)fade=page.gameObject.AddComponent<ApartmentCoverFade>();fade.Begin();
 }

}
public sealed class ApartmentCoverChoice:MonoBehaviour,IPointerEnterHandler,IPointerExitHandler {
 public RectTransform label,hint;public ApartmentGraphic indicator,backdrop;public bool available;bool hovered;float blend;
 public void OnPointerEnter(PointerEventData e){hovered=true;}public void OnPointerExit(PointerEventData e){hovered=false;}

 void Update(){blend=Mathf.Lerp(blend,available&&hovered?1:0,1-Mathf.Exp(-Time.unscaledDeltaTime*12));if(label)label.anchoredPosition=new Vector2(12+blend*8,0);if(hint)hint.anchoredPosition=new Vector2(112+blend*8,0);if(backdrop)backdrop.color=new Color(1,1,1,blend);if(indicator){var c=indicator.color;c.a=blend;indicator.color=c;}}
}
public sealed class ApartmentCoverFade:MonoBehaviour {
 CanvasGroup group;float started;public void Begin(){if(!group)group=gameObject.AddComponent<CanvasGroup>();started=Time.unscaledTime;group.alpha=0;enabled=true;}
 void Update(){float t=Mathf.Clamp01((Time.unscaledTime-started)/.9f);group.alpha=t*t*(3-2*t);if(t>=1)enabled=false;}
 void OnDisable(){if(group)group.alpha=1;}
}
}
