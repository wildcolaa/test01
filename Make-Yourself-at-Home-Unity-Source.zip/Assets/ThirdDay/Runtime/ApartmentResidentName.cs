using System.Globalization;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
namespace ThirdDay {
 public partial class ApartmentGame {
  const float SpeechSeconds=1.8f;
  string residentNameDraft="",residentNameError="",afterNameMode="intro";
  public string ResidentName=>string.IsNullOrWhiteSpace(state.playerName)?"住户":state.playerName;
  public static string NormalizeResidentName(string value){var text=Regex.Replace(value??"",@"\s+"," ").Trim();text=Regex.Replace(text,@"[\p{Cc}\p{Cf}]","").Trim();var elements=new StringInfo(text);return elements.LengthInTextElements>12?elements.SubstringByTextElements(0,12):text;}
  public bool ConfirmResidentName(string value){
   var name=NormalizeResidentName(value);if(name.Length==0){residentNameError="先填写一个名字。";uiSignature=null;pendingFocus="ResidentName";return false;}
   state.playerName=name;residentNameDraft=name;residentNameError="";Mode=afterNameMode;
   if(afterNameMode=="intro"){intro=0;ResetIntroPlayback();if(state.friendMessages.Count>0)state.friendMessages[0].text=name+"，到了吗？新家怎么样。";}
   pendingFocus="";input="";uiSignature=null;Save(0);return true;
  }
  void StartResidentNaming(string next){afterNameMode=next;residentNameDraft="";residentNameError="";Mode="name";pendingFocus="ResidentName";}
  string ResidentAddress(string text){var value=(text??"").Replace("陈实",ResidentName);return value.StartsWith(ResidentName+"，")?value:ResidentName+"，"+value;}
  void ResidentNaming(){
   Shade(new Color(.015f,.02f,.03f,.62f));float w=Mathf.Min(440,Width-48),h=276;var rect=Center(w,h);
   if(!coverHoverFrost){var shader=Resources.Load<Shader>("UI/CoverHoverFrost");if(shader)coverHoverFrost=new Material(shader);}
   var glass=Panel(page,rect,Color.white,"Resident registration");glass.material=coverHoverFrost;glass.edge=new Color(1,1,1,.16f);var p=glass.rectTransform;var foreground=new Color32(225,230,237,255);var dim=new Color32(157,166,180,255);
   Tab(p,"RESIDENT / 1907",190);Text(p,new Rect(26,24,w-52,38),"该怎么称呼你？",23,foreground,sans);Text(p,new Rect(26,70,w-52,27),"这个名字会用于入住登记和家居对话。",12,dim,sans);
   uiInput=Field(p,new Rect(26,112,w-52,45),residentNameDraft,"输入你的名字",s=>residentNameDraft=s,false,true);uiInput.transition=UnityEngine.UI.Selectable.Transition.None;var fieldGlass=uiInput.GetComponent<ApartmentGraphic>();fieldGlass.color=new Color(.015f,.02f,.03f,.5f);fieldGlass.edge=new Color(1,1,1,.18f);uiInput.characterLimit=48;uiInput.caretColor=foreground;uiInput.textComponent.color=foreground;((TMP_Text)uiInput.placeholder).color=dim;uiInput.onSubmit.AddListener(_=>ConfirmResidentName(residentNameDraft));
   Text(p,new Rect(26,170,w-52,24),residentNameError.Length>0?residentNameError:"最多 12 个字",11,dim,sans);
   var button=Button(p,new Rect(w-166,212,140,40),"确认入住",()=>ConfirmResidentName(residentNameDraft),true,true,foreground);button.GetComponent<ApartmentGraphic>().color=new Color(1,1,1,.07f);
  }
 }
}
