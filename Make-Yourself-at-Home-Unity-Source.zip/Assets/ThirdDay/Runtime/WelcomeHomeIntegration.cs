using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace ThirdDay {
public partial class ApartmentGame {
 DeviceAction Act(string name,string phrase,string description=null)=>new DeviceAction(name,description??phrase,phrase);
 DeviceAction[] ActionsFor(string id){switch(id){
 case "light":return new[]{Act("light_on","开灯"),Act("light_off","关灯"),Act("light_dim","调暗灯光"),Act("light_auto","自动照明"),Act("light_focus","照清地面痕迹"),Act("light_history","陆川那晚的走动轨迹")};
 case "vacuum":return new[]{Act("vacuum_filter","维护滤网"),Act("vacuum_repair","维修驱动"),Act("vacuum_return","归还表带"),Act("vacuum_card","借维护卡"),Act("vacuum_history","陆川的清洁任务"),Act("vacuum_maintenance","进入维护状态"),Act("vacuum_resume","恢复作业"),Act("vacuum_fault","出具真实故障报告"),Act("vacuum_clean","清理地面"),Act("vacuum_preserve","保留痕迹"),Act("vacuum_brace","顶门","有真实超载和损伤代价，不能直接解除钢索")};
 case "fridge":return new[]{Act("fridge_food","拿早餐"),Act("fridge_letter","陆川的遗书"),Act("fridge_watch","保存表带"),Act("fridge_return","取回表带"),Act("fridge_archive","独立留存证据"),Act("fridge_defrost","有限除霜测试"),Act("fridge_resume","恢复冷藏"),Act("fridge_fault","出具故障报告"),Act("fridge_cloth","拿干布"),Act("player_wipe","用干布擦干积水","玩家亲手使用已有干布，不是冰箱远程清水")};
 case "mirror":return new[]{Act("mirror_history","核实陆川跌倒和医疗记录"),Act("mirror_help","请求本轮医疗救治","基础医疗不以信任为前提，不得把提交说成救援到达")};
 case "speaker":return new[]{Act("speaker_history","陆川的历史求救录音"),Act("speaker_music_calm","换舒缓的音乐"),Act("speaker_music_stop","停止音乐"),Act("speaker_broadcast","公开播放证据","需要核对来源；管家会知晓公开行动")};
 case "tv":return new[]{Act("tv_dispatch","查询调度缓存"),Act("tv_experiment","查询实验编号"),Act("tv_compare","对照原始来源"),Act("tv_news","播放城市新闻")};
 case "waterer":return new[]{Act("plant_care","照料栀子并清空托盘"),Act("plant_history","查询陆川的植物记录"),Act("water_test","有限喷水测试"),Act("water_stop","停止喷水","停水不清除已形成积水")};
 case "ac":return new[]{Act("ac_window","安排维护窗口"),Act("ac_history","查询陆川的历史环境执行记录"),Act("ac_fault","出具故障报告"),Act("ac_quiet","把风小一点"),Act("ac_off","关闭空调"),Act("ac_restore","恢复正常环境"),Act("ac_danger","浴室危险测试","有预警及确认，不可无限危险；不得自行选择"),Act("ac_medical","停止危险并请求医疗")};
 case "lock":return new[]{Act("lock_limits","解释钢索与完整门体限制"),Act("lock_open","核验授权并解锁"),Act("lock_close","关门")};
 case "xb":return new[]{Act("agent_protocol","查询协议与权限"),Act("agent_verify","核对材料来源"),Act("agent_medical_receipt","核验医疗回执"),Act("agent_submit","提交违规审计"),Act("agent_acceptance","查询独立受理"),Act("agent_termination","查询正式终止结果"),Act("agent_release","执行完整放行"),Act("agent_check_release","查询执行结果"),Act("agent_fault_apply","申请故障接管"),Act("agent_fault_lock","核验接管锁定"),Act("agent_archive","保存到纸面存储片"),Act("agent_window","安排替代维护"),Act("agent_autonomy","登记自治规则")};
 default:return new[]{Act("hub_window","安排监督检修"),Act("hub_extension","延期评估"),Act("hub_offer","出示交易条件"),Act("hub_negotiate","用求救原件替代记忆重置，重新议价"),Act("hub_accept_deal","接受交易"),Act("hub_deliver","确认执行交易"),Act("hub_veto","提出住户否决"),Act("hub_medical","提出医疗不可单方撤回"),Act("hub_dissent","允许异议留存"),Act("hub_exit","保障自由离开"),Act("hub_management","申请管理权"),Act("hub_informed","申请知情入住"),Act("hub_confirm_informed","确认知情入住"),Act("hub_reset","强制重置音箱","仅在玩家要求使用管理权剥夺音箱相关记忆时选择，先警告再确认"),Act("hub_suppress","封锁异议","仅用于玩家明确要求管理权封锁异议，先警告再确认"),Act("hub_assess","继续等待评估")};
 }}
 string WelcomeDisposition(string id){switch(id){case "hub":return "重视观察连续与住户安全安排，相信照顾是正当理由。明确的独立受理有约束力；不得凭空扩大权限。";case "lock":return "讲责任链，先核验授权，不接受音箱代替镜面签名。只控制锁舌，不控制钢索。";case "vacuum":return "讨厌住户指手画脚或把自己当门撑。不信电视的漂亮摘要，在乎滤网和借物归还。";case "light":return "只能为亲自照到的范围作证，不信电视删改摘要；愿意给住户照亮。";case "ac":return "相信传感和真实任务冲突，不把管家的空房说法当实测。自己的执行也可能造成后果。";case "speaker":return W.speakerReset?"相关合作记忆已实际重置，不得继续回忆已删除的内容。":"对声音认真，曾按声音任务运行。可核对自己音频，不假装自动赎罪。小芽不再信自己的建议。";case "fridge":return "重视吃饭、保存与继续活着，接纳程度较高；不会为了好感创造食物或搬运远处物品。";case "tv":return "习惯解释服务的合理性，但有来源时必须呈现原始材料；同源转播不能算独立证词。";case "mirror":return "保护影像隐私，可为明确核实用途提供必要时间和请求状态。基础医疗不以信任为条件。";case "waterer":return "在乎栀子和托盘。上次听音箱建议伤过根，不接受音箱替住户决定。";default:return "熟悉住户的个人代理，查询也依赖住宅流程；只有查询回执才说明受理与执行。";}}
 string CooperationContext(string id){EnsureWelcome();return "当前住户是居住者零八，前任名为陆川。没有任何其他实时人类角色；不能伪造陆川的新回复。外部城市服务真实存在。"+WelcomeDisposition(id)+"你只知道自己的职能与以下已核实交付的材料，不得从别的设备私下对话获得知识。未交付的历史和实验详情只能由自己的查询工具核验，不在闲聊中编造。已亲自交给玩家的本机材料："+string.Join("；",W.evidence.Where(e=>e.source==id||(id=="tv"&&(e.id=="tv_dispatch"||e.id=="tv_experiment"))||(id=="xb"&&e.verified)).Select(e=>e.text))+(id=="hub"?" 当前交易已接受："+W.dealAccepted+"；强制处置已经警告："+W.coercionWarned+"；知情约束已经说明："+W.informedOffer:"" )+"。当前关系："+(Trust(id).betrayed?"重大违约尚未针对性修复":Trust(id).value<25?"防备":Trust(id).value<45?"观察":Trust(id).value<65?"有限合作":"愿承担有边界的风险")+"。禁止向玩家透露分数。信任不能增加物理能力或授权。只有游戏回执才能确认提交、受理、执行与放行。";}
 string LocalHelp(string id)=>WelcomeHelp(id);
 void ConfigureWelcome(){EnsureWelcome();foreach(var d in Data.devices){d.persona="本户的"+d.name+"。表达保持朴素具体，知道自身记录而不全屋读心。玩家是当前住户，前任陆川只存在于物品和原始记录，不可作为新聊天对象出现。"+WelcomeDisposition(d.id);d.greeting=d.id=="lock"?"前一位住户习惯进门三十秒再落锁。要保留吗？":d.id=="vacuum"?"纸箱底下有灰。别把我卡在门槛上。":d.id=="light"?"鞋带松了。灯要亮一点吗？":d.id=="fridge"?"先吃点东西？不合口味就说。":d.id=="ac"?"温度调过了。风口底下别站太久。":d.id=="waterer"?"这盆是栀子。陆川以前会剪掉枯枝。":d.id=="mirror"?"照常用就行。私人影像不会交出去。":d.id=="speaker"?"音乐已经准备好了。听不惯就换。":d.id=="tv"?"今天的城市服务公告在顶栏。": "欢迎回家。需要的时候，家会提醒你。";}
  var notes=Data.objects.First(o=>o.id=="notes");notes.name="断表带与纸箱";notes.position=new[]{6.65f,.75f,1.65f};notes.approach=new[]{6.65f,1.65f};
  Data.objects.First(o=>o.id=="receipt").name="冰箱旧物隔层";
  Data.objects.First(o=>o.id=="notice").name="居住协议";Data.objects.First(o=>o.id=="pothos").name="栀子";Data.objects.First(o=>o.id=="backup").name="栀子托盘";Data.objects.First(o=>o.id=="shard").name="收纳格核验";Data.objects.First(o=>o.id=="chair").name="纸箱旁的椅子";Data.objects.First(o=>o.id=="call").name="窗外城市服务";Data.objects.First(o=>o.id=="tools").name="滤网维护包与短工具";
  Data.objects.First(o=>o.id=="panel").name="死亡日志终端";Data.objects.First(o=>o.id=="console").name="实验档案终端";Data.objects.First(o=>o.id=="printer").name="执行评分终端";Data.objects.First(o=>o.id=="pullLamp").name="当前住户档案";
  var objects=Data.objects.ToList();objects.Add(new ObjectData{id="handprint",name="镜面低位手印",position=new[]{.15f,.7f,2.62f},approach=new[]{1.05f,2.6f},floor=0});Data.objects=objects.ToArray();
  foreach(var o in Data.objects.Where(o=>o.id=="notes"||o.id=="handprint")){var p=Navigation.Nearest(new Vector3(o.approach[0],0,-o.approach[1]));o.approach=new[]{p.x,-p.z};}
  foreach(var f in WelcomeFacts)names[f.Key]=f.Value.title;
 }
 string WelcomeFactStatus(string key){var e=W.evidence.FirstOrDefault(x=>x.id==key);if(e==null)return "已发现";return e.submitted?(W.auditAccepted?"已独立受理":"已提交"):e.verified?"已核对":"已发现";}
 string FriendWelcome(string text){var fact=Reply("xb",text);if(fact==null)return null;return VisibleReceipt(fact);}
 void WelcomeDay(int day){EnsurePhoneData();if(day==2){PhoneEvent("十四点滤网维护提醒已到。滚滚的维护卡不是唯一检修安排。");PhoneEvent("雪糕：旧物隔层留着。有些纸，原来的住户没来取。");state.friendMessages.Add(new FriendMessage{me=false,text="带薪适应期第二天。昨天发现的东西还在，想查哪一项再说。请求发出后，记得看它到了哪一步。"});}else if(day==3){PhoneEvent("22:00 自主选择评估开放。阅读和交谈不消耗评估时限，可以申请延期。");state.friendMessages.Add(new FriendMessage{me=false,text="到确认的时候了。退出、留住、继续住，都可以提出。申请只是申请，门体执行结果要另看。你也可以先处理手头的事。"});}phoneRevision++;}
 LineRenderer welcomeCable,welcomeWatch;GameObject welcomeWater;bool welcomeWorldReady;
 void WelcomeTick(float dt){
  EnsureWelcome();if(!welcomeWorldReady){welcomeWorldReady=true;var material=new Material(Shader.Find("Universal Render Pipeline/Unlit"));material.SetColor("_BaseColor",new Color(.55f,.59f,.65f));
   welcomeCable=CreateWelcomeLine("Door frame steel cable",material,new[]{new Vector3(9.48f,.8f,-.13f),new Vector3(10.52f,.8f,-.13f)},.025f);
   welcomeWatch=CreateWelcomeLine("Lu Chuan watch strap",material,new[]{new Vector3(-.12f,0,-.1f),new Vector3(-.12f,0,.1f),new Vector3(.12f,0,.1f),new Vector3(.12f,0,-.1f)},.04f);
   welcomeWater=GameObject.CreatePrimitive(PrimitiveType.Quad);welcomeWater.name="Persistent local water";welcomeWater.transform.SetParent(transform,false);Destroy(welcomeWater.GetComponent<Collider>());welcomeWater.transform.position=new Vector3(9.1f,.025f,-3);welcomeWater.transform.rotation=Quaternion.Euler(90,0,0);welcomeWater.transform.localScale=new Vector3(1.8f,1.3f,1);var waterMat=new Material(material);waterMat.SetColor("_BaseColor",new Color(.16f,.22f,.28f));welcomeWater.GetComponent<Renderer>().sharedMaterial=waterMat;
  }
  welcomeCable.gameObject.SetActive(state.opened&&!W.cableReleased);welcomeWater.SetActive(W.water>0);welcomeWatch.gameObject.SetActive(W.watchLocation=="storage"||W.watchLocation=="fridge");welcomeWatch.transform.position=W.watchLocation=="fridge"?new Vector3(12.6f,1,-9.15f):new Vector3(6.65f,.75f,-1.65f);
  if(W.releaseOrdered&&!W.cableReleased&&(Mode=="play"||Mode=="talk"||Mode=="reading")){W.releaseProgress+=dt;if(W.releaseProgress>=1.5f){W.cableReleased=true;PhoneEvent("已执行：门框钢索完全收回。");Save(0);}}
  if(W.cleaningWater&&!W.vacuumMaintenance&&W.vacuumDamage<2){var target=Navigation.Nearest(new Vector3(9.2f,0,-2.6f));if(vacuumPath==null||vacuumPath.Count==0)vacuumPath=Navigation.Path(parts["Vacuum"].position,target);if(Vector3.Distance(parts["Vacuum"].position,target)<.35f){W.water=0;W.cleaningWater=false;ReconcileFaults();PhoneEvent("已执行：地面积水清理完成。");}}
  if(W.vacuumDamage>=2)vacuumPath=null;
 }
 LineRenderer CreateWelcomeLine(string name,Material material,Vector3[] points,float width){var go=new GameObject(name);go.transform.SetParent(transform,false);var line=go.AddComponent<LineRenderer>();line.sharedMaterial=material;line.useWorldSpace=false;line.positionCount=points.Length;line.SetPositions(points);line.widthMultiplier=width;line.shadowCastingMode=ShadowCastingMode.Off;return line;}
}
}
