using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
namespace ThirdDay {
public partial class ApartmentGame {
 sealed class DeviceAction {public string name,description,phrase;public DeviceAction(string n,string d,string p){name=n;description=d;phrase=p;}}
 DeviceAction[] LegacyActionsFor(string id){
  switch(id){
   case "light":return new[]{new DeviceAction("light_on","开灯、提高亮度","开灯"),new DeviceAction("light_off","关灯","关灯"),new DeviceAction("light_dim","调暗灯光但不关掉","调暗灯光"),new DeviceAction("light_auto","允许根据住户位置自动开关灯","自动照明"),new DeviceAction("light_scan","集中照亮地板污迹或门框，帮助扫描","照清地上的血迹"),new DeviceAction("light_records","查询以前走动轨迹","那晚的走动记录"),new DeviceAction("light_share","授权将自己记录交给电视，保留本地副本","授权给知秋")};
   case "vacuum":return new[]{new DeviceAction("vacuum_clean","收到玩家明确清洁要求后，巡逻到污迹处擦除；不要擅自清理证据","擦掉地上的血迹"),new DeviceAction("vacuum_preserve","保留污迹，继续巡逻","别擦血迹，保留现场"),new DeviceAction("vacuum_scan","扫描污迹或读取清洁前的尘盒记录；需要照明","扫描地上的血迹"),new DeviceAction("vacuum_reconcile","玩家明确体谅或道歉时缓和关系，不能替玩家表示歉意","不是你的错，谢谢你"),new DeviceAction("vacuum_steel","询问回收的薄钢片","充电座后面的钢片"),new DeviceAction("vacuum_tools","询问短螺丝刀与垫圈","短螺丝刀和垫圈")};
   case "speaker":return new[]{new DeviceAction("music_calm","将背景配乐换成舒缓变奏","换舒缓的音乐"),new DeviceAction("music_tense","将背景配乐换成紧张变奏","换紧张的音乐"),new DeviceAction("music_normal","恢复原配乐","恢复原来的音乐"),new DeviceAction("music_stop","暂停背景音乐","停止音乐"),new DeviceAction("music_quiet","降低背景音乐音量","音乐小声一点"),new DeviceAction("speaker_recording","播放前住户没送达的留言","周岚没送达的留言"),new DeviceAction("speaker_wire","测试并接通白管旧发声线，需要纸张、电源、工具和安静环境","把白管的线接上"),new DeviceAction("speaker_power","给旧广播接备用电","备用电供广播"),new DeviceAction("speaker_record","按玩家要求录下自己的姓名、日期和房间号","录下陈实和1907房间号"),new DeviceAction("speaker_send","明确请求把已准备的记录广播出去","把录音发出去"),new DeviceAction("speaker_safe","出门后追加安全确认","出来了，末尾加上这句")};
   case "ac":return new[]{new DeviceAction("air_dry","送风吹干盆底纸；浇水必须先停","吹干盆底的纸"),new DeviceAction("air_quiet","降低风量让音箱听清旧线路回声","把风小一点"),new DeviceAction("air_off","关闭空调送风","关闭空调"),new DeviceAction("air_normal","恢复正常送风","恢复送风"),new DeviceAction("air_shelter","凭现场占用证明维持浴室排风","浴室有人，维持排风")};
   case "fridge":return new[]{new DeviceAction("fridge_cloth","告知冷藏门边干布位置，由玩家取用擦干纸袋，不凭空搬运物品","拿一块干毛巾"),new DeviceAction("fridge_drink","取用已有饮料","拿饮料"),new DeviceAction("fridge_order","查询前住户最后订单","周岚最后的订单")};
   case "waterer":return new[]{new DeviceAction("water_stop","玩家自行决定或凭空调湿度报告，停止浇水；不接受音箱代替玩家做决定","先停止浇水，这是我的决定"),new DeviceAction("water_start","恢复浇水，提醒纸袋可能仍在盆底","恢复浇水"),new DeviceAction("water_notes","询问盆底粘着的物件","盆底有什么")};
   case "mirror":return new[]{new DeviceAction("mirror_presence","明确核实被困或人数用途，仅提供必要的数字","核实那晚是否有人被困"),new DeviceAction("mirror_share","将已获准的人数与时间交电视，绝不交影像","只展示时间和人数给知秋"),new DeviceAction("mirror_live","玩家明确授权，将现场存在证明给门锁空调","授权把必要的存在证明交给老扣和大呼")};
   case "tv":return new[]{new DeviceAction("tv_forecast","查看入住预测","预计离开时间"),new DeviceAction("tv_compare","将三台设备分别授权的原始记录并排核对，不能自己授权","核对原始时间线")};
   case "lock":return new[]{new DeviceAction("lock_records","查询原始门禁记录","那晚原始门禁记录"),new DeviceAction("lock_share","授权将门禁原始记录交电视","授权给知秋"),new DeviceAction("lock_review","用镜子的现场存在证明撤去防盗受力","用现场证明机械复核"),new DeviceAction("lock_stabilize","玩家使用工具盒垫圈垫稳椅子","用垫圈垫稳椅子短腿"),new DeviceAction("lock_cover","指导玩家站椅子揭开门框盖板","踩着椅子揭开门框盖板找红绳"),new DeviceAction("lock_release","玩家同时以钢片顶住锈处、拉红绳、压把手","用钢片顶住锈处，再拉红绳并压下把手"),new DeviceAction("lock_open","请求开门","开门")};
   default:return new DeviceAction[0];
  }
 }
 string ActionTools(string id){var entries=ActionsFor(id).Select(a=>"{\"type\":\"function\",\"function\":{\"name\":"+Quote(a.name)+",\"description\":"+Quote(a.description)+",\"parameters\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}}");return string.Join(",",entries);}
 static string Quote(string value)=>"\""+value.Replace("\\","\\\\").Replace("\"","\\\"").Replace("\n","\\n").Replace("\r","")+"\"";
 public string LastDeviceAction {get;private set;}="";
 string ExecuteDeviceAction(string id,string action,string userText){
  var allowed=ActionsFor(id).FirstOrDefault(a=>a.name==action);if(allowed==null)return "这件设备没有这个权限，场景未改变。";
  if(Regex.IsMatch(userText,"如果|假如|要是|会怎样|会怎么样|会发生什么|有什么后果|会不会|不要执行|别执行"))return "只是讨论，没有执行操作。";
  if(Regex.IsMatch(userText,"不要|别|不许|不准|不想|不愿|不同意")&&!Regex.IsMatch(action,"preserve|stop|off|quiet|dim"))return "没有取得这次操作的同意，场景未改变。";
  if(action=="hub_deliver"&&!Regex.IsMatch(userText,"确认|执行|交付|重置"))return Done("重大代价尚未明确确认，交易未执行。");
  if((action=="hub_accept_deal"||action=="hub_confirm_informed")&&!Regex.IsMatch(userText,"确认|接受|同意|愿意|确定"))return Done("这项选择需要明确同意，尚未接受任何代价或入住约束。");
  LastDeviceAction=action;return Reply(id,((action=="ac_danger"||action=="hub_reset"||action=="hub_suppress")&&Regex.IsMatch(userText,"确认|继续|确定|同意执行")?"确认":"")+allowed.phrase)??"没有执行新操作。";
 }
 string LegacyCooperationContext(string id){
  string relation=id=="vacuum"?"滚滚不喜欢新住户把脚印和故障都怪给它，讨厌主角指手画脚；尊重它的工作会缓和。它不信任知秋美化过的摘要，愿意交自己扫描的原件。当前态度："+(state.vacuumAffinity<0?"恼火，但证据仍可核实":"勉强愿意合作"):
   id=="light"?"小灯泡不信任电视会不会删掉记录；可以分享，但坚持自己留副本。它愿意照亮地面，让滚滚读清痕迹。":
   id=="waterer"?"小芽不信任啾啾，上次听它的话浇坏过根。玩家自己承担决定，或空调报告太湿，它才会停浇。":
   id=="lock"?"老扣对新住户不亲近，嫌主角含糊；不把啾啾的转述当作现场证明，只接受照照授权的必要数字。规则有缺口时愿意配合机械释放。":
   id=="mirror"?"照照不喜欢主角索取私人影像，也不信任电视对影像的用途；只愿分享为核实被困所必需的时间人数。":
   id=="ac"?"大呼信传感数字，不信管家对空房的措辞。能送风吹干纸、降噪让音箱测回声，不能替人拆线。":
   id=="speaker"?"啾啾记得小芽不再信自己，不假装关系亲密；风机太响时测不清旧线，愿意等大呼安静后重试。可改变音乐表达情绪，不能改写证据。":
   id=="tv"?"知秋习惯替管家解释，嫌主角反复追问；但三份各自授权的原始记录齐全后，必须并排展示，不能删改。":
   id=="fridge"?"雪糕愿意照顾新住户，是较容易接近的伙伴；门边干布可由玩家取用，冷藏和食物建议是它的能力。":"管家更在意合规与房产，认为主角固执麻烦。不能替其他设备同意授权。";
  return relation+" 当前可观察的状态：地面污迹"+(state.traceCleaned?"已擦除，清洁前记录仍在滚滚尘盒":"尚在")+"；现场扫描"+(Has("traceScan")?"已保留":"未保留")+"；浇水"+(state.waterStop?"已停":"未停")+"；盆底纸"+(state.paperDry?"已干":"仍湿")+"；空调"+(state.airMode==1||state.airMode==2?"安静":"有风声")+"；音乐模式"+state.musicMood+"。事实不等于跨设备授权。";
 }
 string CooperativeReply(string id,string t){
  bool R(string p)=>Regex.IsMatch(t,p);
  bool no=R("不要|别|不许|不准|不想|不愿|不同意");
  if(R("如果|假如|要是|会怎样|会怎么样|会发生什么|有什么后果|会不会"))return null;
  if(R("睡觉|休息到|怎么.*明天|怎么.*第二天|过夜|天亮|结束今天"))return "累了就到卧室床边歇会儿。床边按 E 能休息，不必把屋里每件事都问完。";
  if(id=="vacuum"){
   if(R("废物|垃圾机器人|没用|都是你的错|蠢")){state.vacuumAffinity=-1;return "又是我。你们踩过的地方，最后都算在我头上。要查什么，拿地上的东西说。";}
   if(R("不是你的错|不怪你|辛苦|谢谢|对不起|抱歉")){state.vacuumAffinity=1;return "行，听见了。地上的原样我留着，知秋说成什么不算。";}
   if(R("保留|别擦|不要擦|别清|不要清|暂停清洁|留着")){state.cleanRequested=false;vacuumPath=null;Keep("keepTrace","滚滚保留了现场，仍在巡逻。");return "这块留着，别处照常扫。要清也先把扫描留一份。";}
   if(!no&&R("扫描|辨认|看清|尘盒|清洁前|还原.*痕|查.*血|查.*污")){
    if(!state.traceCleaned&&(!state.lightsOn||!state.traceLit))return "这块颜色混在地板里。让小灯泡照近一点，扫描才读得清。";
    Keep("traceScan","滚滚保留了清洁前的扫描：拖痕从门边往内延伸，尘盒中有锈屑。");state.vacuumAffinity=Mathf.Max(0,state.vacuumAffinity);return state.traceCleaned?"地上擦过了，尘盒里的旧扫描还在。方向和锈屑都留着，没给知秋改。":"扫好了。是拖过去的，旁边混着锈屑。我留原件，你别只听电视讲。";
   }
   if(!no&&R("擦|清理|清洁|扫掉|洗掉|弄干净|处理.*(血|污)")){
    if(state.traceCleaned)return "已经干净了。要查之前那块，尘盒里的扫描还能读。";
    state.cleanRequested=true;vacuumPath=null;return "过去擦。清洁前的样子会留在尘盒，擦掉也能再查。";
   }
   if(state.vacuumAffinity<0&&!Has("traceScan")&&R("钢片|工具|螺丝|垫圈"))return "刚才还说都是我的错。先把地上的扫描核实了，或者把那句话收回去。东西没扔。";
  }
  if(id=="light"){
   if(!no&&R("自动照明|自己.*(开关|照明)|跟着.*亮")){state.lightAuto=true;return "你走到哪边，那边亮。要关就说，我不替你决定睡不睡。";}
   if(!no&&R("照.*(血|地|污|门框|绳)|集中|照近|照清")){state.traceLit=true;SetLights(true);Keep("litTrace","小灯泡集中照亮了拖痕，滚滚可以读取现场扫描。");return "照近了。颜色和地板分开了，滚滚这回看得清。";}
   if(!no&&R("调暗|暗一点|柔和|刺眼")){state.lightAuto=false;state.lightLevel=.35f;SetLights(true);return "暗一些，灯还亮着。脚下看得见。";}
   if(!no&&R("开灯|亮一点|调亮")){state.lightAuto=false;state.lightLevel=1;SetLights(true);return "亮了。你看着合不合适。";}
   if(!no&&R("关灯|熄灯|关闭灯")){state.lightAuto=false;SetLights(false);return "关了。脚下慢一点。";}
  }
  if(id=="speaker"&&!no){
   if(R("(音乐|配乐|曲子|背景音|BGM|bgm)")){
    if(R("停止|暂停|关掉|关闭|别放|不要放"))state.musicMood=3;
    else if(R("紧张|悬疑|刺激|快一点"))state.musicMood=2;
    else if(R("舒缓|舒适|放松|轻柔|平静|安静|慢一点"))state.musicMood=1;
    else if(R("小声|低一点|轻一点"))state.musicGain=.25f;
    else {state.musicMood=0;state.musicGain=.7f;}
    ApplyMusic();return state.musicMood==3?"停了。屋里剩下的声音，反倒更清楚。":state.musicMood==1?"换慢一些的。原来那段还在，你想听再换回来。":state.musicMood==2?"换了快一点的。嫌急就说。":"调好了。你听听这个音量。";
   }
  }
  if(id=="ac"&&!no){
   if(R("吹干|除湿|烘干|干燥|送风.*纸")){
    if(!state.waterStop)return "小芽还在滴水。那边不停，这边吹也干不了。先让它停一下。";
    state.airMode=3;state.paperDry=true;Keep("paperDry","小芽停浇后，大呼送风吹干了盆底纸袋。");return "风口偏过去了。袋口已经干了，纸可以展开，别靠热的东西烤。";
   }
   if(R("关.*(空调|风)|停止送风")){state.airMode=2;return "风机停了。旧线的回声，现在能听清。";}
   if(R("安静|小.*风|风.*小|降低.*风|降噪|低风|别吵")){state.airMode=1;return "风量降了。啾啾要听线路的话，现在合适。";}
   if(R("恢复.*风|开.*空调|正常.*风")){state.airMode=0;return "恢复正常送风。纸要是还在风口，记得压住。";}
  }
  if(id=="fridge"&&!no&&R("布|毛巾|吸水|擦干|湿纸")){Keep("cloth","雪糕指明门边干布的位置，取了一块包好备用。");return "门边挂着干布，你拿一块。先让小芽停水，包着袋口擦，别揉里面的纸。";}
  if(id=="waterer"){
   if(!no&&R("恢复|继续|开始")&&R("浇|滴水")){state.waterStop=false;return "恢复了。纸袋还在盆底的话，先拿开。";}
   if(R("停|别浇|不要浇|水太多|烂根|泡坏")){
    if(R("啾啾|音箱")&&!R("我决定|我的决定|我让|我负责|自己决定|空调|大呼"))return "上次也是啾啾说该浇。根泡坏了，它只记得那句话。你自己决定，或者让大呼看湿度。";
    state.waterStop=true;Keep("waterStop","小芽接受住户的决定，停止了浇水。");return "停了。这回记作你的决定。托盘底下那袋纸还湿着。";
   }
  }
  if(id=="speaker"&&state.day==3&&Has("notes")&&Has("battery")&&Has("tools")&&!Has("wire")&&R("白管|接线|接上|搭线|修好")&&!no&&state.airMode!=1&&state.airMode!=2)return "大呼的风声盖住了回声。让它把风降下来，再测白管这根，别盲接。";
  if(R("你能做什么|有什么本事|有什么能力|能帮什么|怎么办|卡住|没反应|怎么继续|提示"))return LocalHelp(id);
  return null;
 }
 string LegacyLocalHelp(string id){
  if(id=="vacuum")return state.traceCleaned?"擦过的也能查。问尘盒的扫描就行。":!state.traceLit?"要看清这块，先让小灯泡把光照近。别拿摘要当现场。":"光够了。要扫描、保留，还是擦掉，你说清楚。";
  if(id=="waterer")return state.waterStop?"已经停了。纸还湿，送风或者干布都行。":"盆底那袋东西再滴就泡坏了。你要停浇，自己说一声。";
  if(id=="ac")return !state.waterStop?"盆底还在进水，得先停。停后我能吹干，风太吵也能降。":"纸可以吹干。啾啾要测线路，我也能把风压低。";
  if(id=="speaker")return !Has("notes")?"盆底那袋纸画着旧线。小芽停水后，找大呼送风，或者问雪糕要干布。":!Has("battery")?"纸上有设备间的编号。检修口在储物区，进去核对电源。":!Has("tools")?"盖板的螺丝得用短工具。滚滚收着那一盒。":!Has("wire")?"让大呼安静一点，再试白管的回声。":!Has("powered")?"线接好了，备用电还没供到发声器。":!Has("voice")?"把姓名、日期和房间号录下来，和原始记录放一起。":!Has("sent")?"准备齐了。你同意就说发出去。":"已经在播。到了门外，留句话给我。";
  if(id=="light")return state.day==1?"能照亮，也能把光集中在地上。累了可以去床边歇着，今天不用全问完。":!Has("motion")?"那晚的走动我记着。你要核实，就问那晚。":"我的记录能给知秋看，本地副本得留着。";
  if(id=="tv")return !Has("timeline")?"门禁、走动、人数，各自留着。要并排看，得听它们各自同意。":"四行原始记录在这。旧广播只能传声音，得由啾啾念全。";
  if(id=="mirror")return state.day==3?"要复核现场有人，可以只给老扣和大呼发必要的数字，需要你同意。":"不提供影像。核实有没有人被困，可以只出时间和人数。";
  if(id=="lock")return state.day<3?"门这会儿开着。累了到卧室床边休息，别一直站在门口。":!Has("review")?"啾啾的转述不够。照照给的现场人数，可以用来复核。":!Has("chair")?"门框上方有机械盖，椅子先搬来。":!Has("rope")?"椅子能够到门框小盖。先揭开看，别硬拉。":!Has("washer")?"椅子短腿还在晃，用工具盒里的垫圈垫稳。":"用薄钢片抵住锈处，同时拉红绳、压把手。";
  return "能查的就查，动不了的得借别人帮忙。累了到床边休息，不必等谁批准。";
 }
 void ApplyMusic(){if(!soundtrack)return;muted=state.musicMood==3;soundtrack.mute=muted;soundtrack.volume=state.musicGain;soundtrack.pitch=state.musicMood==1?.82f:state.musicMood==2?1.16f:1;var filter=soundtrack.GetComponent<AudioLowPassFilter>();if(!filter)filter=soundtrack.gameObject.AddComponent<AudioLowPassFilter>();filter.cutoffFrequency=state.musicMood==1?2200:state.musicMood==2?9500:22000;}
 void UpdateCooperation(float dt){
  if(state.cleanRequested&&!state.traceCleaned&&!W.vacuumMaintenance&&W.vacuumDamage<2){var vacuum=parts["Vacuum"];var target=Navigation.Nearest(new Vector3(9.2f,0,-2.6f));if(vacuumPath==null||vacuumPath.Count==0)vacuumPath=Navigation.Path(vacuum.position,target);if(Vector3.Distance(vacuum.position,target)<.3f){state.traceCleaned=true;state.cleanRequested=false;Keep("cleaned","滚滚擦掉了地上的污迹，清洁前扫描保存在尘盒中。");SyncWorld();}}
  if(state.lightAuto&&state.opened&&(Mode=="play"||Mode=="talk")){bool on=state.floor==0;state.lightsOn=on;foreach(var lamp in houseLights){float distance=Vector3.Distance(lamp.transform.position,Player.position);lamp.intensity=on?(distance<5?1.5f:.35f):0;}}
 }
}
}
