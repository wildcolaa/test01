using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;

namespace ThirdDay {
 public partial class ApartmentGame {
  bool utopiaReady;Transform utopiaRoot;Material utopiaVehicleMaterial;
  readonly List<Mesh> utopiaMeshes=new List<Mesh>();readonly List<Material> utopiaMaterials=new List<Material>();
  readonly List<Transform> utopiaCouriers=new List<Transform>();Transform utopiaTram,utopiaCleaner;
  public int DressingTriangleCount {get;private set;}
  public int DressingStaticBatches {get;private set;}
  public int DressingVehicles=>utopiaCouriers.Count+(utopiaTram?1:0)+(utopiaCleaner?1:0);
  static readonly string[] CityScreenLines={"无人接驳照常运行\n通勤交给城市","今日配餐已经备好\n回家以后慢慢吃","社区诊疗全天值守\n需要时告诉个人代理","街区养护正在进行\n绿化与清扫已安排"};
  string UtopiaCityNews()=>"城市 AI 服务\n"+CityScreenLines[Mathf.FloorToInt(Time.time/15)%CityScreenLines.Length];
  sealed class PropBatch {
   public readonly List<Vector3> vertices=new List<Vector3>(),normals=new List<Vector3>();public readonly List<int> indices=new List<int>();public readonly List<Color> colors=new List<Color>();
   public void Quad(Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 n,Color color){int k=vertices.Count;vertices.AddRange(new[]{a,b,c,d});for(int i=0;i<4;i++){normals.Add(n);colors.Add(color);}indices.AddRange(new[]{k,k+1,k+2,k,k+2,k+3});}
   public void Box(Vector3 p,Vector3 s,Color color,Quaternion rotation){var h=s*.5f;Vector3 V(float x,float y,float z)=>p+rotation*new Vector3(x*h.x,y*h.y,z*h.z);Vector3 N(Vector3 n)=>rotation*n;
    Quad(V(-1,-1,1),V(1,-1,1),V(1,1,1),V(-1,1,1),N(Vector3.forward),color);Quad(V(1,-1,-1),V(-1,-1,-1),V(-1,1,-1),V(1,1,-1),N(Vector3.back),color);
    Quad(V(1,-1,1),V(1,-1,-1),V(1,1,-1),V(1,1,1),N(Vector3.right),color);Quad(V(-1,-1,-1),V(-1,-1,1),V(-1,1,1),V(-1,1,-1),N(Vector3.left),color);
    Quad(V(-1,1,1),V(1,1,1),V(1,1,-1),V(-1,1,-1),N(Vector3.up),color);Quad(V(-1,-1,-1),V(1,-1,-1),V(1,-1,1),V(-1,-1,1),N(Vector3.down),color);
   }
   public void Cylinder(Vector3 p,float radius,float height,Color color,Quaternion rotation,int sides=10){for(int i=0;i<sides;i++){float a=i*Mathf.PI*2/sides,b=(i+1)*Mathf.PI*2/sides;var u=new Vector3(Mathf.Cos(a)*radius,0,Mathf.Sin(a)*radius);var v=new Vector3(Mathf.Cos(b)*radius,0,Mathf.Sin(b)*radius);var up=Vector3.up*height*.5f;
     Quad(p+rotation*(u-up),p+rotation*(u+up),p+rotation*(v+up),p+rotation*(v-up),rotation*(u+v).normalized,color);
     Quad(p+rotation*up,p+rotation*(v+up),p+rotation*(u+up),p+rotation*up,rotation*Vector3.up,color);
     Quad(p-rotation*up,p+rotation*(u-up),p+rotation*(v-up),p-rotation*up,rotation*Vector3.down,color);
   }}
   public Mesh Mesh(string name,bool shade=false){var m=new Mesh{name=name,hideFlags=HideFlags.DontSave};m.SetVertices(vertices);m.SetNormals(normals);if(shade){var light=new Vector3(-.3f,.85f,-.4f).normalized;for(int i=0;i<colors.Count;i++)colors[i]*=.63f+.37f*Mathf.Max(0,Vector3.Dot(normals[i],light));}m.SetColors(colors);m.SetTriangles(indices,0);m.RecalculateBounds();return m;}
  }
  readonly Color[] utopiaPalette={new Color(.66f,.68f,.68f),new Color(.16f,.18f,.20f),new Color(.48f,.43f,.36f),new Color(.29f,.39f,.33f),new Color(.48f,.69f,.65f),new Color(.79f,.76f,.68f),new Color(.69f,.84f,.81f),new Color(.19f,.18f,.15f)};
  // Ceramic, graphite, wood, foliage, service trim, linen, display and potting soil.
  static readonly float[] PropSmoothness={.52f,.34f,.24f,.18f,.38f,.09f,0,.06f};
  PropBatch[] propBatches;
  void P(int material,float x,float y,float z,float w,float h,float d,float yaw=0)=>propBatches[material].Box(new Vector3(x,y,-z),new Vector3(w,h,d),Color.white,Quaternion.Euler(0,yaw,0));
  void C(int material,float x,float y,float z,float radius,float height,Quaternion? rotation=null)=>propBatches[material].Cylinder(new Vector3(x,y,-z),radius,height,Color.white,rotation??Quaternion.identity);
  void Book(float x,float y,float z,float w=.32f,float d=.22f){P(2,x,y+.025f,z,w,.05f,d);P(5,x,y+.03f,z+.009f,w-.018f,.034f,d-.012f);
    P(2,x,y+.05f,z,w,.009f,d);
    P(3,x+w*.21f,y+.024f,z+d*.5f,.024f,.008f,.036f);}
  void Mug(float x,float y,float z){C(0,x,y+.075f,z,.075f,.15f);C(1,x,y+.151f,z,.059f,.006f);// Leave a real opening between the handle and the cup.
    P(0,x+.091f,y+.12f,z,.058f,.017f,.024f);
    P(0,x+.113f,y+.083f,z,.016f,.082f,.024f);
    P(0,x+.091f,y+.046f,z,.058f,.017f,.024f);
    C(0,x,y+.008f,z,.061f,.016f);}
  void Parcel(float x,float y,float z,float w,float h,float d){P(5,x,y+h*.5f,z,w,h,d);P(4,x,y+h+.002f,z,w*.15f,.008f,d+.008f);P(0,x+w*.2f,y+h+.009f,z,w*.26f,.01f,d*.45f);for(int i=0;i<4;i++)P(1,x+w*.15f+i*.025f,y+h+.016f,z,.012f,.004f,d*.22f);}
  void Plant(float x,float y,float z,float radius=.12f){C(0,x,y+.09f,z,radius,.18f);C(7,x,y+.185f,z,radius*.9f,.008f);for(int i=0;i<6;i++){float a=i*Mathf.PI/3;propBatches[3].Box(new Vector3(x+Mathf.Cos(a)*radius*.65f,y+.28f+Mathf.Sin(i*2)*.04f,-z+Mathf.Sin(a)*radius*.65f),new Vector3(radius*1.7f,.025f,radius*.6f),Color.white,Quaternion.Euler(i%2*28,60*i,25));}}
  void CreateUtopiaDressing(){
   utopiaReady=true;utopiaRoot=new GameObject("Utopia · household and civic services").transform;utopiaRoot.SetParent(transform,false);utopiaRoot.gameObject.hideFlags=HideFlags.DontSave;
   propBatches=Enumerable.Range(0,utopiaPalette.Length).Select(_=>new PropBatch()).ToArray();
   // Everything is on existing furniture, in existing blocked footprints, or flat on the floor.
   P(3,10,.018f,1.25f,1.25f,.018f,.68f);P(4,10,.03f,1.48f,.9f,.005f,.025f);
   Parcel(8.3f,1.1f,.95f,.34f,.18f,.52f);P(0,8.3f,1.12f,2.25f,.3f,.025f,.35f);P(1,8.3f,1.137f,2.25f,.21f,.006f,.26f);
   for(int i=0;i<2;i++){P(5,8.27f,.15f,1.75f+i*.24f,.34f,.08f,.15f);P(1,8.26f,.194f,1.75f+i*.24f,.21f,.012f,.1f);}
   P(2,2.78f,.418f,7.72f,1.05f,.025f,.65f);Mug(2.42f,.435f,7.54f);Book(3.12f,.435f,7.88f);Book(3.11f,.49f,7.87f,.27f,.2f);P(1,3.15f,.56f,7.52f,.34f,.023f,.2f,12);P(6,3.15f,.574f,7.52f,.29f,.003f,.16f,12);
   P(2,5.05f,.51f,10.25f,.22f,.025f,.22f);C(0,5.05f,.55f,10.25f,.09f,.05f);
   Plant(.7f,.33f,4.83f,.095f);Book(3.34f,.33f,4.82f,.35f,.22f);Book(3.34f,.39f,4.81f,.3f,.21f);P(5,2.7f,.59f,10.02f,.55f,.055f,.44f);P(3,2.7f,.623f,10.02f,.55f,.012f,.08f);
   P(3,10.15f,.775f,5.9f,.85f,.012f,.8f);C(0,10.15f,.792f,5.9f,.24f,.025f);C(5,10.15f,.821f,5.9f,.16f,.03f);P(2,10.13f,.85f,5.92f,.25f,.07f,.12f,-15);Mug(9.18f,.765f,5.75f);P(0,10.5f,.79f,5.95f,.025f,.012f,.35f);
   Parcel(17.25f,.925f,8.42f,.78f,.32f,.45f);C(0,16.4f,1.105f,8.42f,.16f,.34f);P(1,16.61f,1.14f,8.42f,.09f,.2f,.05f);P(0,16.22f,1.17f,8.42f,.17f,.05f,.08f);C(1,16.4f,1.28f,8.42f,.11f,.018f);
   P(2,14.2f,.945f,8.45f,.65f,.035f,.38f);for(int i=0;i<3;i++)C(i%2==0?2:3,14.04f+i*.15f,1.02f,8.44f,.075f,.11f);
   for(int i=0;i<4;i++)C(0,13.5f,1.09f,8.28f+i*.075f,.15f,.022f,Quaternion.Euler(90,0,0));
   Plant(14.95f,.958f,10.9f);P(2,16.02f,.975f,10.8f,.65f,.03f,.4f);Parcel(16.02f,.995f,10.8f,.36f,.11f,.24f);Mug(15.95f,.958f,11.16f);
   for(int i=0;i<3;i++)P(i==1?3:5,15.12f,.485f+i*.07f,2.42f,.46f,.065f,.7f);
   P(1,12.76f,.516f,3.73f,.12f,.025f,.21f);P(6,12.76f,.533f,3.73f,.07f,.004f,.14f);Book(15.1f,.46f,1.7f,.41f,.3f);
   P(1,12.19f,1.9f,2.35f,.045f,.7f,1.3f);P(5,12.216f,1.9f,2.35f,.012f,.63f,1.23f);for(int i=0;i<5;i++){float h=.12f+(i%3)*.065f;P(i==2?4:0,12.226f,1.68f+h*.5f,1.91f+i*.21f,.01f,h,.14f);}P(3,12.228f,1.66f,2.35f,.01f,.015f,1.1f);
   P(4,.36f,.9f,2.75f,.23f,.04f,.29f);C(0,.4f,.97f,3.08f,.065f,.17f);for(int i=0;i<3;i++)P(i==0?4:0,.37f+i*.035f,1.11f,3.08f,.018f,.18f,.018f);
   C(1,.3f,.98f,2.17f,.025f,.22f);P(1,.37f,1.08f,2.17f,.17f,.035f,.04f);Parcel(.38f,.89f,2.37f,.19f,.18f,.16f);
   P(1,4.1f,1.5f,.16f,.72f,.035f,.04f);P(5,4.1f,1.28f,.19f,.46f,.43f,.035f);P(3,4.1f,1.08f,.214f,.46f,.025f,.008f);
   for(int i=0;i<3;i++){Parcel(5.31f,1.53f,2.16f+i*.38f,.28f,.18f,.27f);C(0,7.5f,2.025f,.4f+i*.3f,.075f,.23f);P(4,7.5f,2.04f,.4f+i*.3f,.155f,.04f,.155f);}
   Parcel(7.52f,1.91f,1.25f,.45f,.22f,.44f);
   for(int i=0;i<3;i++){P(0,-2.65f,1.05f,7.1f+i*.48f,.32f,.24f,.4f);Plant(-2.65f,1.18f,7.1f+i*.48f,.11f);}P(5,-.78f,.49f,6.6f,.33f,.065f,.32f);P(5,-.78f,.55f,6.6f,.29f,.05f,.28f);
   for(int i=0;i<4;i++){P(1,22.35f,-2.35f,5.1f+i*.18f,.08f,.08f,1.6f);P(4,22.35f,-2.32f,5.1f+i*.18f,.09f,.02f,1.4f);}
   C(1,23.75f,-3.37f,2.4f,.13f,.2f);C(4,23.75f,-3.26f,2.4f,.15f,.025f);P(0,25.05f,-3.45f,2.42f,.4f,.035f,.32f);P(1,25.05f,-3.426f,2.42f,.31f,.01f,.23f);Parcel(26.2f,-3.6f,2.4f,.4f,.11f,.3f);
   ModelApartmentFurniture();
   BuildCivicInfrastructure();
   for(int i=0;i<propBatches.Length;i++){if(propBatches[i].indices.Count==0)continue;var mat=new Material(Shader.Find(i==6?"Universal Render Pipeline/Unlit":"Universal Render Pipeline/Lit")){name="Utopia shared "+i,hideFlags=HideFlags.DontSave,enableInstancing=true};mat.SetColor("_BaseColor",utopiaPalette[i]);if(mat.HasProperty("_Smoothness"))mat.SetFloat("_Smoothness",PropSmoothness[i]);utopiaMaterials.Add(mat);var mesh=propBatches[i].Mesh("Utopia static batch "+i);MakeDressingMesh("Household and civic props "+i,mesh,mat,utopiaRoot);DressingStaticBatches++;}
   propBatches=null;CreateServiceVehicles();for(int i=0;i<4;i++)if(parts.TryGetValue("Aircraft"+i,out var craft))LEDGlow(craft,new Color(.22f,.26f,.29f),1);
   var kitLabel=CivicText("Welcome kit label",new Vector3(8.3f,1.292f,-.95f),"入住用品",.32f,.2f,.43f);kitLabel.transform.rotation=Quaternion.Euler(90,0,0);kitLabel.color=new Color(.18f,.23f,.22f);
   AddUtopiaObservations();
  }
  MeshRenderer MakeDressingMesh(string name,Mesh mesh,Material material,Transform parent){utopiaMeshes.Add(mesh);DressingTriangleCount+=mesh.triangles.Length/3;var go=new GameObject(name);go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=material;r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=true;r.lightProbeUsage=LightProbeUsage.Off;r.reflectionProbeUsage=ReflectionProbeUsage.Off;r.motionVectorGenerationMode=MotionVectorGenerationMode.ForceNoMotion;return r;}
  TextMeshPro CivicText(string name,Vector3 position,string text,float width,float height,float size){var go=new GameObject(name);go.transform.SetParent(utopiaRoot,false);go.transform.position=position;go.transform.rotation=View.transform.rotation;var label=go.AddComponent<TextMeshPro>();label.font=sans;label.fontSize=size;label.text=text;label.color=new Color(.82f,.9f,.88f);label.alignment=TextAlignmentOptions.Center;label.textWrappingMode=TextWrappingModes.Normal;label.richText=false;label.rectTransform.sizeDelta=new Vector2(width,height);var renderer=go.GetComponent<MeshRenderer>();renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;return label;}
  void BuildCivicInfrastructure(){
   // Only a small service corridor around the apartment: no new city blocks or roads.
   P(1,0,-3.6f,-8.5f,43,.14f,1.2f);P(1,0,-3.51f,-8.05f,43,.025f,.04f);P(1,0,-3.51f,-8.95f,43,.025f,.04f);
   for(int i=0;i<7;i++){P(1,-18+i*6,-6.1f,-8.5f,.28f,5,1.1f);P(1,-18+i*6,-3.5f,-8.5f,1.3f,.12f,1.5f);}
   P(1,-8,-3.25f,-8.5f,5.3f,.28f,2.5f);P(1,-8,-1.3f,-9.3f,5.3f,.16f,1.1f);for(int i=0;i<3;i++)P(1,-9.8f+i*1.8f,-2.2f,-9.3f,.07f,2,.1f);
   for(int i=0;i<4;i++){Parcel(-10+i*.9f,-3.1f,-9,.55f,.55f,.6f);P(6,-10+i*.9f,-2.78f,-8.69f,.25f,.045f,.018f);}
   Plant(-5.9f,-3.1f,-7.8f,.2f);Plant(-6.5f,-3.1f,-7.8f,.2f);
   
  }
  void CreateServiceVehicles(){
   utopiaVehicleMaterial=new Material(Shader.Find("ThirdDay/CityGradient")){name="Utopia vehicles · vertex palette",hideFlags=HideFlags.DontSave};utopiaVehicleMaterial.SetColor("_BaseColor",new Color(.28f,.32f,.35f));utopiaMaterials.Add(utopiaVehicleMaterial);
   var drone=new PropBatch();drone.Box(Vector3.zero,new Vector3(.42f,.16f,.3f),utopiaPalette[0],Quaternion.identity);drone.Box(new Vector3(0,-.12f,0),new Vector3(.23f,.14f,.22f),utopiaPalette[2],Quaternion.identity);drone.Box(Vector3.zero,new Vector3(.74f,.035f,.08f),utopiaPalette[1],Quaternion.identity);foreach(float x in new[]{-.29f,.29f})drone.Cylinder(new Vector3(x,.03f,0),.17f,.025f,utopiaPalette[1],Quaternion.identity,8);drone.Box(new Vector3(0,.095f,0),new Vector3(.19f,.015f,.08f),utopiaPalette[6],Quaternion.identity);var droneMesh=drone.Mesh("Shared delivery craft",true);utopiaMeshes.Add(droneMesh);DressingTriangleCount+=droneMesh.triangles.Length/3;
   for(int i=0;i<5;i++){var go=new GameObject("Scheduled courier "+i);go.transform.SetParent(utopiaRoot,false);go.AddComponent<MeshFilter>().sharedMesh=droneMesh;var r=go.AddComponent<MeshRenderer>();r.sharedMaterial=utopiaVehicleMaterial;r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;utopiaCouriers.Add(go.transform);}
   var tram=new PropBatch();for(int i=0;i<3;i++){tram.Box(new Vector3(i*1.15f,0,0),new Vector3(1.06f,.62f,.65f),utopiaPalette[0],Quaternion.identity);tram.Box(new Vector3(i*1.15f,.07f,-.33f),new Vector3(.86f,.26f,.012f),utopiaPalette[1],Quaternion.identity);tram.Box(new Vector3(i*1.15f,-.18f,-.34f),new Vector3(1.04f,.045f,.016f),utopiaPalette[4],Quaternion.identity);if(i<2)tram.Box(new Vector3(i*1.15f+.57f,0,0),new Vector3(.1f,.4f,.5f),utopiaPalette[1],Quaternion.identity);}utopiaTram=MakeDressingMesh("Unmanned civic shuttle",tram.Mesh("Three-car shuttle",true),utopiaVehicleMaterial,utopiaRoot).transform;
   var cleaner=new PropBatch();cleaner.Box(Vector3.zero,new Vector3(.7f,.24f,.38f),utopiaPalette[0],Quaternion.identity);cleaner.Box(new Vector3(0,-.15f,0),new Vector3(.58f,.04f,.28f),utopiaPalette[4],Quaternion.identity);utopiaCleaner=MakeDressingMesh("Exterior glass maintenance",cleaner.Mesh("Glass maintenance unit",true),utopiaVehicleMaterial,utopiaRoot).transform;
  }
  void UpdateUtopiaDressing(){if(!utopiaReady){if(sans)CreateUtopiaDressing();else return;}float t=Time.time;
   for(int i=0;i<utopiaCouriers.Count;i++){float phase=Mathf.Repeat(t*(.022f+i*.0012f)+i*.19f,1);var courier=utopiaCouriers[i];if(i%2==0){courier.position=new Vector3(Mathf.Lerp(-18,23,phase),3.3f+i*.48f,4.7f+i*.9f);courier.rotation=Quaternion.Euler(0,90,0);}else{courier.position=new Vector3(-5.5f-i*.65f,2.4f+i*.3f,Mathf.Lerp(-15,11,phase));courier.rotation=Quaternion.identity;}}
   utopiaTram.position=new Vector3(Mathf.Lerp(-22,23,Mathf.Repeat(t/55,1)),-3.12f,8.5f);utopiaCleaner.position=new Vector3(-3.05f,1.35f,-(7.9f+Mathf.Sin(t*.13f)*1.7f));
  }
  void AddUtopiaObservations(){var list=Data.objects.ToList();void Add(string id,string name,float x,float y,float z,float ax,float az,float floor=0){var p=Navigation.Nearest(new Vector3(ax,floor,-az));list.Add(new ObjectData{id=id,name=name,position=new[]{x,y,z},approach=new[]{p.x,-p.z},floor=floor});}
   Add("utopia_welcome","城市配给的入住用品",8.3f,1.35f,.95f,8.95f,1.4f);Add("utopia_tea","茶几上的杯子与阅读屏",2.8f,.65f,7.7f,4.1f,7.4f);Add("utopia_breakfast","一人份配餐",10.15f,.95f,5.9f,11.2f,6.1f);Add("utopia_bedside","叠好的换洗衣物",15.12f,.73f,2.42f,15.95f,2.3f);Add("utopia_wash","洗漱与养护用品",.4f,1.12f,3.0f,1.05f,3.0f);Add("utopia_returns","统一补给与回收盒",7.5f,2.2f,1.25f,6.6f,1.3f);Add("utopia_balcony","阳台的城市苗圃",-2.65f,1.5f,7.5f,-1.6f,7.6f);Add("utopia_city","窗外的无人接驳与配送",-2.7f,1.4f,8.4f,-1.9f,8.4f);Add("utopia_network","设备间的城市服务接口",25.05f,-3.2f,2.42f,25.2f,3.4f,-4.5f);Data.objects=list.ToArray();
  }
  string UtopiaObservation(string id){switch(id){case "utopia_welcome":return "毛巾、拖鞋和洗漱用品，都按一人份装好了。标签写着：缺什么，告诉小饱。";case "utopia_tea":return "阅读屏上留着今天的社区消息。杯子也摆好了，像是知道你会坐在这里。";case "utopia_breakfast":return "食物装在可回收的餐盒里。明天的份量也已经安排好了。";case "utopia_bedside":return "换洗衣物叠得很齐。旁边是一张通勤卡，路线已经排好。";case "utopia_wash":return "日用品都没有拆封。小标签写着：用完放回，养护系统会补齐。";case "utopia_returns":return "补给盒和回收盒用不同颜色标着。连什么时候收走，都不用你记。";case "utopia_balcony":return "每盆苗都标着合适的水量和光照。城市苗圃会送来下一批。";case "utopia_city":return "无人接驳从楼间滑过去，配送机沿着固定航线飞行。它们各走各的路，很少需要停下来等。";default:return "住房、通勤、配餐和诊疗接在同一张服务网上。设备间里只听得见平稳的风声。";}}
  void DisposeUtopiaDressing(){foreach(var mesh in utopiaMeshes)if(mesh)Destroy(mesh);foreach(var material in utopiaMaterials)if(material)Destroy(material);}
 }
}
