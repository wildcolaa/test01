using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ThirdDay
{
    public partial class ApartmentGame
    {
        sealed class WallFade { public Renderer renderer;public Material material;public float visibility=1;public ShadowCastingMode shadows; }
        readonly List<WallFade> fadingWalls=new List<WallFade>();
        bool occlusionReady;
        void UpdateOcclusion(float dt)
        {
            if(!occlusionReady)
            {
                occlusionReady=true;var shader=Resources.Load<Shader>("Occlusion/ApartmentOccluder");
                if(!shader){Debug.LogError("[ThirdDay] Occlusion shader missing");return;}
                foreach(var root in Data.roots)if(root.name.StartsWith("Occluder"))
                {
                    Transform wall;if(!parts.TryGetValue(root.name,out wall))continue;
                    foreach(var renderer in wall.GetComponentsInChildren<MeshRenderer>())
                    {
                        var material=new Material(renderer.sharedMaterial){name=renderer.sharedMaterial.name+" · dither"};material.shader=shader;
                        material.SetFloat("_ThirdDayVisibility",1);renderer.sharedMaterial=material;
                        fadingWalls.Add(new WallFade{renderer=renderer,material=material,shadows=renderer.shadowCastingMode});
                    }
                }
            }
            var origin=Player.position+Vector3.up;
            var toCamera=View.transform.position-origin;var ray=new Ray(origin,toCamera.normalized);
            bool active=Mode=="play"||Mode=="talk"||Mode=="reading";
            foreach(var wall in fadingWalls)
            {
                float distance;bool blocked=active&&wall.renderer.bounds.IntersectRay(ray,out distance)&&distance<toCamera.magnitude;
                float target=blocked?.16f:1;
                wall.visibility=Mathf.Lerp(wall.visibility,target,1-Mathf.Exp(-dt*10));
                if(Mathf.Abs(wall.visibility-target)<.002f)wall.visibility=target;
                wall.material.SetFloat("_ThirdDayVisibility",wall.visibility);
                wall.renderer.shadowCastingMode=wall.visibility>.6f?wall.shadows:ShadowCastingMode.Off;
            }
        }
        void OnDestroy(){DisposeUtopiaDressing();foreach(var wall in fadingWalls)if(wall.material)Destroy(wall.material);}
    }
}
