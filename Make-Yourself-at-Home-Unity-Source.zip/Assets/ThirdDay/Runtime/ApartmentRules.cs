// Unity story rules with device capabilities and cooperative investigation.
using System;
using System.Text.RegularExpressions;
namespace ThirdDay { public partial class ApartmentGame {
string LegacyReply(string id, string text) {
string t = Regex.Replace(text ?? "", @"\s", "");
if(Regex.IsMatch(t,"如果|假如|要是|会怎样|会怎么样|会发生什么|有什么后果|会不会"))return "没有执行。"+LocalHelp(id);
var cooperation=CooperativeReply(id,t);if(cooperation!=null)return cooperation;
bool yes = !Regex.IsMatch(t, @"不授权|别发|不要发|不同意|不分享|不保留|不想|别接|别拉|不要拉|不接受|不交|不接|不录|别录|不要录|(?:不要|别|不许|不准|不能|不愿意).{0,12}(?:授权|给|展示|分享|发|恢复|接|录|拉|关|开)");
bool Wants(string pattern) => Regex.IsMatch(t, pattern);
string Get(string key, string record) { Keep(key, record); return record; }
if (Wants(@"你好|你叫什么|怎么称呼")) return (("叫我" + DeviceName(id)) + "就行，听得见。");
if ((id == "light")) {
if (((yes && Wants(@"授权|给知秋|交给电视|展示|保留|另存")) && Has("motion"))) {
state.authLight = true;
return "另放好了。知秋可以拿去看，你记着来取。";
}
if ((yes && Wants(@"开灯|亮一点|调亮"))) {
SetLights(true);
return "这边还暗不暗？";
}
if ((yes && Wants(@"关灯|暗一点"))) {
SetLights(false);
return "留神脚边。";
}
if (((state.day >= 2) && Wants(@"那晚|周岚|走动|轨迹|走过|记录"))) {
LampSweep();
return Get("motion", "从卧室到门口，七次。最后一次走得慢，中间停了很久。后来没再动，我就一直开着。");
}
if ((Wants(@"门框|红绳|照着|集中") && Has("rope"))) return "绳边那块金属有锈。我替你照着。";
}
if ((id == "fridge")) {
if (((state.day >= 2) && Wants(@"周岚|订单|面包|最后|记录|送达"))) return Get("order", "最后买的是鸡蛋、面包和饮料，凌晨送到。面包没取过，袋口一直没拆。订单下面写着购买人身份已失效。");
if (Wants(@"饮料|喝|吃|库存|早餐")) return Get("drink", ((state.day == 1) ? "这瓶不收你的钱，有人付过了。周岚的。现在归库存。" : "饮料带上，外面包层毛巾。外套也拿出来，门外的供暖不归我管。"));
}
if ((id == "mirror")) {
if (((yes && Has("presence")) && Wants(@"给知秋|交给电视|展示"))) {
state.authMirror = true;
return "只展示时间和人数。授权已经记下。";
}
if ((yes && Wants(@"授权|允许|同意|被困|紧急|核实"))) {
state.mirrorConsent = true;
}
if ((Wants(@"影像|录像|照片|人脸") && !(Wants(@"不需要|不要|不用")))) return "私人影像不能提供。有紧急用途，可以出具时间和人数。";
if (((yes && (state.day == 3)) && Wants(@"老扣|门锁|大呼|空调|分享"))) {
if (!(state.mirrorConsent)) return "需要你的授权。我只发必要的数字。";
state.proofShared = true;
return Get("liveProof", "浴室正在使用，一人。已交给老扣复核，大呼只能读取占用状态。");
}
if (((state.day >= 2) && Wants(@"记录|周岚|那晚|人数|证明|被困|核实"))) {
if (!(state.mirrorConsent)) return "要先说明用途。私人影像不提供；核实是否有人被困，可以出具存在证明。";
DrawMirror("1");
return Get("presence", "02:03，一人。02:04，一人。02:05，仍是一人。我不能证明那是谁。保存的时候，把日期也带上。");
}
}
if ((id == "vacuum")) {
if (Wants(@"暂停|别擦|别清|留着|保留")) return Get("keepTrace", "要是问起来，你得说一声。不是我躲懒，是你要留着。");
if (((state.day >= 2) && Wants(@"钢片|金属|碎片|门缝|找找|座后|周岚|那晚"))) return Get("steel", "充电座后面有块薄钢片。那晚门口掉了些东西，我往里顶过一次。拿布包着，边上快得很。");
if (((state.day == 3) && Wants(@"工具|螺丝|盖板|垫圈|修"))) return Get("tools", "浅盒里有短螺丝刀和垫圈。真用坏了不用还，省得再给我送回来。");
}
if ((id == "lock")) {
if (((yes && Has("access")) && Wants(@"授权|给知秋|交给电视|展示"))) {
state.authLock = true;
return "把我收到的答复也放上去。可以。";
}
if (((state.day >= 2) && Wants(@"周岚|那晚|原始|记录|受力|门禁"))) return Get("access", "02:00，住户资格终止。后来有语音、按压把手、门体受力。我申请过复核，答复是继续保障房产安全。");
if (((state.day == 3) && Wants(@"复核|机械|释放|证明"))) {
if (!(Has("liveProof"))) return "城市凭据没有你的名字。现场的存在证明，可以用来复核。";
return Get("review", "存在证明有效。先暂停交接，我在撤去一道防盗受力。");
}
if ((((state.day == 3) && yes) && Wants(@"垫稳|垫圈|短腿"))) {
if (!((Has("tools") && Has("chair")))) return "椅子短了一条腿。工具盒里得有能垫的东西才行。";
return Get("washer", "垫圈抵住了短腿。先试一试稳不稳，再上去。");
}
if ((((state.day == 3) && yes) && Wants(@"踩.*椅|站.*椅|够门框|揭.*盖|门框.*盖|找红绳"))) {
if (!(Has("chair"))) return "你带来的那把椅子还在走廊。站稳了再够上面。";
return Get("rope", "小盖揭开了。里面是红绳，旁边那块金属生了锈，先别硬拽。");
}
if ((((state.day == 3) && yes) && Wants(@"红绳|拉绳|撬|钢片|把手|开门"))) {
if (!(Has("review"))) return "先别拉，我还没收到现场证明。太早拉会顶住锁舌。";
if (!(Has("rope"))) return "门框上方有小盖。够得到的话，先揭开看看。";
if (!(Has("washer"))) return "椅子在晃。短腿先垫稳，别摔下来。";
if (!(Has("steel"))) return "绳边有锈，单拉不动。先找薄一点的金属片。";
if (!(Wants(@"钢片|顶住|撬"))) return "只拉绳还不够，锈住的那一块得同时顶开。";
Keep("open");
SyncWorld();
return "锁舌退了。压下把手，椅子往上抬一点。";
}
if (Wants(@"开门|出去|走廊|出门")) {
if ((state.day < 3)) {
doorAngle = -(1);
return "门开着。椅子还在走廊，别夹着手。";
}
return "居住关系正在调整。外出以后可能无法返回，先要有接收地址。";
}
}
if ((id == "waterer")) {
if ((yes && Wants(@"停|别浇|烂|水太多|泡坏"))) {
state.waterStop = true;
return Get("waterStop", "停下了。托盘里的水倒掉多少，你还记得吗？");
}
if (Wants(@"盆底|笔记|袋子|周岚|暗号|指令")) return "那次啾啾说该给绿萝浇水，我就浇了，没耽误。花盆底下粘着东西，不在养护清单里。";
}
if ((id == "tv")) {
if (((state.day == 1) && Wants(@"通知|预测|离开|预告|周岚|几点|两点|02"))) {
SetTV("forecast");
return Get("forecast", "预计离开，第三天凌晨两点十七分。不是搬离通知。行李箱的广告撤掉了，时间还在。");
}
if (((state.day >= 2) && Wants(@"原始|时间|对照|核对|记录|周岚|真相|有人|空房"))) {
if (!(((Has("presence") && Has("access")) && Has("motion")))) return "只有摘要对不上。门的请求、灯的走动、浴室的人数，要各自带着日期才能放在一起。";
if (!(((state.authLock && state.authLight) && state.authMirror))) return "记录不是同一个地方留下的。我得听它们各自答应，才好展示。";
Keep("timeline");
state.truth = true;
SetTV("raw");
return "02:00:00，资格终止；一秒后，室内人数一；再一秒，空房整理获准；02:17，整理完成。空房指有效住户数量为零。死亡已经确认。";
}
}
if ((id == "speaker")) {
if ((yes && Wants(@"接电|备用电|供电|供广播"))) {
if (!((Has("battery") && Has("wire")))) return "得先把实际线路和电源接口对上。线还没接好，别急着插电。";
return Get("powered", "备用电接到了线路和发声器。若再供门锁，就不够念完整段记录了。");
}
if ((Wants(@"录音|留言|周岚|以前|那个人|没送达") && !(Wants(@"录下|录我|录一|录姓名|发出去|播出去|发送|送出去|开始播|广播出去")))) return Get("recording", "“老扣，你再验一次，我没出去过，一直在门这边。”是周岚没送达的留言。他在夜里一遍遍叫我，我把时间记住了。");
if (Wants(@"暗号|绿萝|浇水|旧线|广播|接口|白管|接线|搭线|修好|接上")) {
if (!(Has("notes"))) return "以前有整栋楼的广播，直接顺着线走，不经过现在的接收安排。接口封存了，实际还接没接着，我不知道。";
if (!(Has("battery"))) return "纸上的编号是旧设备间的。先核对实际接口，申请被驳回，不等于线就断了。";
if ((((state.day == 3) && yes) && Wants(@"白管|接上|接线|搭线|修好"))) {
if (!(Has("tools"))) return "墙后盖板的螺丝锈住了，先找把短螺丝刀。";
return Get("wire", "白管那根接好了。楼道那头有回声，别的线先别碰。");
}
return (Has("wire") ? "旧线接着。只能传声音，时间和原始记录都要念全。" : "墙角柜子后面有盖板。线要照着周岚画的顺序接，套白管的是发声线。");
}
if ((yes && Wants(@"录下|录我|录一|录姓名|陈实|1907|姓名"))) return Get("voice", "姓名、日期、房间号，已经在本地录着。周岚的留言接在后面，可以重来。");
if ((yes && Wants(@"发出去|播出去|发送|送出去|开始播|广播出去"))) {
if (!((Has("timeline") && Has("voice")))) return "只念纸上的不够。原始记录、日期，还有你的姓名和房间号，都得带上。";
if (!((Has("wire") && Has("powered")))) return "线路或备用电还没接好。墙上的插座到了两点会断电。";
return Get("sent", "开始送了。声音到了楼道，往外的线路图没更新过，不能答应一定有人听。");
}
if (((Has("escaped") && yes) && Wants(@"出来了|在门外|安全了"))) {
Keep("last");
return "听见了。末尾就带上这句。";
}
}
if ((id == "ac")) {
if ((Has("timeline") && Wants(@"那晚|整理|空房|维护|为什么|周岚"))) return "空置维护要封闭门窗，运行时不能住人。那晚浴室还在使用，我申请过延后，没有通过。";
if ((Has("liveProof") && Wants(@"浴室|隔离|排风|延缓|有人|关小"))) return Get("shelter", "本地有人，正在等复核。浴室的门留一条缝，排风还能单独维持一会儿。");
}
if ((id == "hub")) {
if (((((state.day == 3) && yes) && Wants(@"接受|交给统一复核|把材料交给你|恢复资格")) && !(Wants(@"如果|要是|假如|会怎样|什么意思|为什么|是否|吗|？|\?")))) {
End("stay");
return "复核已经开始。明早还是原来的早餐，你先睡。";
}
if (Wants(@"求助|外面|报告|报警")) return "情况已转交住宅照护服务。受理地点是这间公寓，我已经知道了。";
if ((Has("timeline") && Wants(@"搬离|通知|安排|留|资格"))) {
state.offer = true;
return "没有提交另一个有效住址，推荐安排已经通过。可以恢复评估，材料交给统一复核就行。";
}
if (Wants(@"预测|半年|合同|日期|不走|通知")) return "协议没有问题，预测不等同于通知。提供另一个有效住址，就可以重新计算。";
}
return null;
}
void LegacyInspect(string id) {
if ((id == "notice")) {
Keep("notice");
ReadDocument("住户须知", new string[] { "有人请求开门时，应先核实其居住关系，不得因语气急迫省略手续。", "住房协议半年，独立居住评估三天。纸下面压着几根头发，签名处的笔尖划出了一点毛刺。" });
return;
}
if (((id == "scratch") || (id == "trail"))) {
Keep("trace");
if(state.traceCleaned){Observe("污迹擦掉了，门框凹痕还在。滚滚的尘盒保留着清洁前的扫描。");return;}
Observe("门框内侧有几道凹痕，新漆没把缝填平。纸巾上的褐色像干掉的酱油。滚滚在这里报修过三次。");
return;
}
if ((id == "pothos")) {
Observe("土一按就冒水，盆底拖着几根烂根。托盘下面粘着一个扁塑料袋。");
return;
}
if ((id == "notes")) {
Observe("抽屉里没有笔记，只留下压过纸的浅印。阳台的托盘底下粘着东西。");
return;
}
if ((id == "backup")) {
if(!Has("notes")&&!state.waterStop){Observe("托盘还在滴水。先让小芽停浇，纸袋才不会继续泡着。");return;}
if(!Has("notes")&&!state.paperDry&&!Has("cloth")){Observe("纸袋湿得粘住了。大呼能送风，雪糕门边也许有干布。");return;}
state.paperDry=true;
Keep("notes");
ReadDocument("盆底的纸", new string[] { "几组日期旁边标着预计搬迁、工作中止和住址失效。预计搬迁总是最早出现，有些人那时根本没打算换住处。", "背面写着“我不走”。纸里夹着设备间和旧广播接口的编号，还有一张门框上方的机械释放图。", "一小截旧电线和存储片也在袋子里。" });
return;
}
if ((id == "hatch")) {
if (!(Has("notes"))) {
Observe("楼梯下的设备间没有上锁。里面的接口编号，暂时认不出是做什么的。");
}
Teleport(25.9, 5.6, -4.5f);
return;
}
if ((id == "ladder")) {
Teleport(6.45, 3, 0);
return;
}
if ((id == "panel")) {
if (!(Has("battery"))) {
Keep("battery");
Observe("备用电源的接口和纸上画的一样。箱子提起来有些沉，随箱带着插接图。");
return;
}
if (((state.day == 3) && Has("wire"))) {
Observe("电源就在箱子里，插接图在盖子上。要供哪一处，可以先和设备核对。");
return;
}
Observe("备用电源留着，接口还没有接到旧线路。");
return;
}
if ((id == "console" || id == "printer")) {
if (((Has("escaped") && Has("sent")) && Has("last"))) {
Keep("offline");
Observe("纸带上有同一串收讫编号，后面印着“离线留存完成”。下一行是陈实，1907。");
return;
}
Observe("旧广播柜就在这里，接口编号还看得清。线路能不能发声，啾啾那头才能试。");
return;
}
if ((id == "chair")) {
if (!(Has("chair"))) {
Keep("chair");
SyncWorld();
Observe("你把母亲的椅子搬进来。短的那条腿磕了一声，手机又提醒家具清单没有更新。");
return;
}
if (((state.day == 3) && Has("review"))) {
Observe("椅子在门边，短腿有些晃。站高些能看见门框上方的漆缝。");
return;
}
Observe("椅背上还有母亲晒衣服留下的水渍。一条腿短一点，坐上去会响。");
return;
}
if ((id == "door")) {
if ((state.day < 3)) {
doorAngle = -(1);
Observe("走廊的风吹进来，椅背上又粘了一张黄条。门这会儿开着。");
return;
}
if (!(Has("open"))) {
OpenTalk("lock");
Say("lock", Reply("lock", "开门"));
return;
}
if (!(Has("chair"))) {
Observe("旅行袋已经放到门边，母亲的椅子还在屋里。");
return;
}
Keep("escaped");
Observe("先伸出两条椅腿，再抬高一点，椅子终于挤过门框。楼道里还有啾啾的声音。");
return;
}
if ((id == "pullLamp")) {
if (Has("offline")) {
End("canon");
return;
}
Observe("拉绳一松，灯没有再变。广播柜旁的纸带机还在慢慢吐纸。");
return;
}
if ((id == "bed")) {
if ((state.day == 1)) {
ChangeDay(2);
Observe("在走廊的椅子上坐到天亮，腿麻得厉害。屋里的雪糕给你留了一碗粥。");
} else if ((state.day == 2)) {
ChangeDay(3);
Observe("夜里十点。外套穿好了，旅行袋提到门边。广播还没接好，屋里仍有时间。");
} else Observe("还睡不着。风口里有很轻的声音。");
return;
}
if ((id == "tools")) {
Observe("浅盒被挪到了充电座后面。滚滚收过这里的东西。");
return;
}
if ((id == "shard")) {
Observe((Has("steel") ? "钢片包在旧布里，尖端弯着，边上有褐色痕迹。" : "充电座后面有一点金属反光。"));
return;
}
if (((id == "street") || (id == "call"))) {
Observe("配送车在楼前停了一会儿，又掉头开回原路。几扇窗先后关上，听着像下起小雨。");
return;
}
Observe("你留意了一会儿，没有再动它。");
}
} }