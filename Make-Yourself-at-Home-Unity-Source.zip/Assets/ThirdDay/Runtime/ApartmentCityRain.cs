using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ThirdDay
{
    // A single, sparse mesh: the GPU moves the drops without particle simulation,
    // physics, lights, textures, or a full-screen post-processing pass.
    public sealed class ApartmentCityRain : MonoBehaviour
    {
        public const int DropCount = 560;
        Mesh rainMesh;
        Material rainMaterial;
        GameObject rainObject;
        public Renderer RainRenderer { get; private set; }

        public void Initialize(Camera view)
        {
            if (rainObject || !view) return;
            var shader = Resources.Load<Shader>("CityRain");
            if (!shader) { Debug.LogError("[ThirdDay] City rain shader missing."); return; }
            rainMaterial = new Material(shader) { name = "City rain · silver grey", hideFlags = HideFlags.DontSave };
            rainObject = new GameObject("City rain · GPU drops");
            rainObject.transform.SetParent(view.transform, false);
            rainMesh = BuildMesh();
            rainObject.AddComponent<MeshFilter>().sharedMesh = rainMesh;
            var renderer = rainObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = rainMaterial;
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            renderer.lightProbeUsage = LightProbeUsage.Off;
            renderer.reflectionProbeUsage = ReflectionProbeUsage.Off;
            renderer.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
            renderer.allowOcclusionWhenDynamic = false;
            RainRenderer = renderer;
        }

        static Mesh BuildMesh()
        {
            var random = new System.Random(1907);
            var positions = new Vector3[DropCount * 4];
            var corners = new Vector2[positions.Length];
            var seeds = new List<Vector2>(positions.Length);
            var profiles = new List<Vector4>(positions.Length);
            var triangles = new int[DropCount * 6];
            for (int drop = 0; drop < DropCount; drop++)
            {
                bool near = drop >= 400;
                var seed = new Vector2((float)random.NextDouble(), (float)random.NextDouble());
                float variation = (float)random.NextDouble();
                // Width and length are fractions of viewport height, independent
                // of output resolution. The two scales give a restrained depth cue.
                var profile = new Vector4(near ? .00085f : .00055f,
                    (near ? .018f : .009f) * (.7f + variation * .6f),
                    (near ? .64f : .40f) * (.85f + variation * .3f),
                    (near ? .30f : .16f) * (.75f + variation * .4f));
                int v = drop * 4;
                corners[v] = new Vector2(-.5f, -.5f);
                corners[v + 1] = new Vector2(-.5f, .5f);
                corners[v + 2] = new Vector2(.5f, .5f);
                corners[v + 3] = new Vector2(.5f, -.5f);
                for (int k = 0; k < 4; k++) { seeds.Add(seed); profiles.Add(profile); }
                int t = drop * 6;
                triangles[t] = v; triangles[t + 1] = v + 1; triangles[t + 2] = v + 2;
                triangles[t + 3] = v; triangles[t + 4] = v + 2; triangles[t + 5] = v + 3;
            }
            var mesh = new Mesh { name = "City rain · 560 GPU streaks", hideFlags = HideFlags.DontSave };
            mesh.vertices = positions;
            mesh.uv = corners;
            mesh.SetUVs(1, seeds);
            mesh.SetUVs(2, profiles);
            mesh.triangles = triangles;
            // Vertices are placed in view space by the shader. Keep the small
            // source mesh from being culled when the camera pans or zooms.
            mesh.bounds = new Bounds(Vector3.zero, Vector3.one * 1000);
            mesh.UploadMeshData(true);
            return mesh;
        }

        void OnDestroy()
        {
            if (rainObject) Destroy(rainObject);
            if (rainMesh) Destroy(rainMesh);
            if (rainMaterial) Destroy(rainMaterial);
        }
    }
}
