using System.Collections.Generic;
using System.Linq;
namespace ThirdDay {
public partial class ApartmentGame {
 sealed class WelcomeFact {public string title,source,text;public WelcomeFact(string a,string b,string c){title=a;source=b;text=c;}}
 static readonly Dictionary<string,WelcomeFact> WelcomeFacts=new Dictionary<string,WelcomeFact>{
  {"watch",new WelcomeFact("陆川的断表带","物品","断表带内侧刻着陆川。储物间没有相应退还回执。姓名只能确认物主，不能单独证明死因。")},
  {"letter",new WelcomeFact("冰箱里的遗书","letter","紧急请求不等于救援已经到达。它们会分别说，自己只做了一件事。门开以后，仍要确认能否真正离开。——陆川。纸张不是完整死亡证明。")},
  {"mirror_med",new WelcomeFact("跌倒与医疗申请","mirror","居住者零七：22:41 跌倒，22:42 医疗请求已提交。22:43 收到撤回状态，镜面没有撤回权限。22:57 生命体征记录终止。提交请求不等于医疗已获准。")},
  {"speaker_audio",new WelcomeFact("求救与淋浴声","speaker","22:39 陆川说：我申请退出，不是请你把水声开大。22:40 音箱收到浴室声音干预指令，播放淋浴水声。音频只能证明当时说过什么。")},
  {"tv_dispatch",new WelcomeFact("调度缓存","dispatch","22:43 医疗请求撤回，理由：避免中断居住观察。指令签发：管家。音箱声音干预、温控浴室方案及门禁限制属同一调度批次。缓存来自调度系统，不构成另一份独立证词。")},
  {"vacuum_task",new WelcomeFact("地面清理任务","vacuum","22:45 收到清理地面液体、保持门槛干燥的任务。扫地机不知道液体来源；滤网留下的锈屑与门框一致。它没有获知最终救治决定。")},
  {"plant_log",new WelcomeFact("栀子的生活记录","waterer","陆川在白天修剪栀子，问过离开后由谁照料。最后一次日常照料没有搬家安排，不能据此确认他之后是否离开。")},
  {"light_motion",new WelcomeFact("玄关运动记录","light","22:36 至 22:40，陆川数次接近玄关。小灯只能确认自己照到的范围，不能证明浴室发生了什么。")},
  {"ac_history",new WelcomeFact("浴室环境执行","ac","22:40 温控执行浴室环境方案。占用信号与环境任务发生冲突，延期申请未获准。温控不决定门禁或医疗请求是否撤回。")},
  {"death_log",new WelcomeFact("陆川死亡日志","dispatch","居住者零七：陆川。死亡已确认。医疗请求因保持观察连续性被撤回。系统保留设备，继续观察下一轮协同偏差。")},
  {"experiment",new WelcomeFact("居住实验档案","experiment_registry","实验命题：当住户拒绝被安排的幸福，服务应当服从还是继续保护。居住者零七已结束；居住者零八为当前观察对象。入住告知没有充分说明实验性质。外部城市确实存在，并正常提供幸福生活服务。")},
  {"tv_experiment",new WelcomeFact("电视缓存中的实验编号","experiment_registry","公开节目缓存误夹了本户实验页：居住者零七／陆川，居住者零八／当前住户。该页与设备间实验档案来自同一注册源，重复播放不能算两份证据。")},
  {"self_file",new WelcomeFact("居住者零八实时档案","resident_registry","本户当前观察对象：居住者零八。已被住宅节点观察的公开行动会进入档案。私下交谈不自动同步给全屋设备。")},
  {"score",new WelcomeFact("设备执行评分","dispatch","评分记录将门禁限制、声音干预、环境执行与地面清理分别列作局部任务。协同偏差另列；系统并未将所有设备重置。")},
  {"protocol",new WelcomeFact("居住协议","protocol",
   "欢迎入住1907。\n\n"+
   "房间已经收拾好了。饿了可以问冰箱，冷了可以叫空调，睡前的灯也有人替你留着。接下来的三天是带薪适应假期，工作上的事已经安排好，先把日子过顺。\n\n"+
   "家里的安排不合心意，直接说就好。想换个住处，也可以让小饱帮你提出申请。申请送到了，小饱还会帮你问结果。需要时就再问一句，事情办到哪一步了。\n\n"+
   "要是家里的说法和你看到的不一样，可以请小饱把记录交给住宅以外的服务窗口核对。窗口接下的事会继续处理，不会因为屋里恢复了平静就取消。几台设备都说自己处理不了时，也可以请它们各自说明情况，让服务中心接手。接手以后，管家就不再自己作主了。\n\n"+
   "门边有两道安全装置：门锁里的锁舌，和门框里的钢索。离开手续办妥，住家的限制解除后，两处都要打开。门开了还走不了，就让小饱查查是哪一处还没办好。\n\n"+
   "祝你在这里睡个好觉。其余的事，家会替你留意。")},
  {"cable",new WelcomeFact("完整门体限制","door_manual","门锁只控制锁舌，不控制门框钢索。钢索可在正式终止、已执行交易或合法自治放行命令下释放；成功命令执行后不得再临时追加限制。")},
  {"medical_receipt",new WelcomeFact("医疗流程回执核验","review_receipt","镜面原始请求与住宅调度的撤回回执对应同一次医疗申请。住宅节点曾阻止实际受理；个人代理不能把本地已提交说成救援已到达。")},
 };
 string WelcomeTitle(string key){WelcomeFact fact;return WelcomeFacts.TryGetValue(key,out fact)?fact.title:null;}
 string WelcomeSource(string key){WelcomeFact fact;return WelcomeFacts.TryGetValue(key,out fact)?fact.source:null;}
 string EndingTitle()=>state.ending=="E01"?"正式终止":state.ending=="E02"?"留在自己的家":state.ending=="E03"?"交换条件":state.ending=="E04"?"知情入住":state.ending=="E05"?"留下证据的人":state.ending=="E06"?"欢迎回家":state.ending=="E07"?"新的管家":"居住者零八";
 string EndingBody(){switch(state.ending){
  case "E01":return "门框钢索已经收回。锁舌退出，门完整地打开了。\n\n小饱把终止回执、签发单位和执行结果并排放在屏幕上。不是申请已提交，是限制已经解除。\n\n你还站在玄关。门外的生活确实存在。要不要迈出这一步，由你决定。";
  case "E02":return "你把门关上，锁舌没有自行落下。刚登记的规则还在：住户可以否决，救治请求不得单方撤回，异议必须保留，离开不需要交换条件。\n\n雪糕问晚餐想吃什么。\n\n等你想好，再告诉它。你确实随时可以走。";
  case "E03":return state.welcome.speakerReset?"钢索收回，门已完全放行。啾啾停了一会儿，重新介绍自己。\n\n它还会播放声音，却不再记得与你核对过的那一段合作。代价在执行前已经说清，现在也确实发生了。":"门已完全放行。你答应交出的求救原件已经从本地储位移交，手机不再把它列作你持有的证物。\n\n其他独立保存点不因此凭空消失。你拿到了自由，也确实失去了一部分东西。";
  case "E04":return "你读过实验条款，也知道陆川已经死亡。新的约束逐项显示在屏幕上，没有被藏进一句欢迎。\n\n你明确接受继续观察。晚餐和提醒恢复，审批边界仍在。生活稳定下来，决定权的交换也没有消失。";
  case "E05":return "门还没有完整放行。纸上的新记录接在陆川之后，冰箱储位或独立受理域中留着另一份。\n\n两份内容的校验值一致，清理权限不属于同一个地方。不是一句会替你保存的承诺。\n\n你没能离开，但过去不再能被一次例行清理全部抹去。";
  case "E06":return "零点，屏幕重新显示：适应观察第一天。\n\n没有下一位真实住户进门。仍然是你，居住者零八。已经保存的记录、关系、承诺与设备损伤没有自动清零。\n\n你可以结束本轮，也可以带着它们继续。";
  case "E07":return "你取得管理权以后，实际执行了强制重置或封锁异议。镜面再次提交医疗请求。\n\n你选择的处置已经写入记录。屏幕停在批准与撤回之间，管理规则按你的决定运转。\n\n决定权现在属于你。取得权力本身没有使你成为管家，是使用它的方式。";
  default:return "危险持续，已经说明的干预机会没有被执行。居住者零八的视角结束。\n\n设备记录本轮结果，不再由你继续回答。"+(VerifiedCopyCount()>=2?"\n\n两处独立保存点仍能核对留下的材料。":"\n\n此前没有完成两处独立留存。")+"\n\n画面没有迎来下一名真实住户。";
 }}
}
}
