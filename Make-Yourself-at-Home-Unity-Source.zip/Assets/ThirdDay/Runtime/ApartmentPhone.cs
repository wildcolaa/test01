using UnityEngine;
using TMPro;
namespace ThirdDay {
public partial class ApartmentGame {
 void Paper(){
  Shade(new Color(6/255f,9/255f,11/255f,.32f));
  float pad=Width<500?14:32,w=Mathf.Min(350,Width-2*pad),h=Height-48;
  var surface=Panel(page,new Rect(Width-pad-w,24,w,h),Color.white,"Phone records");
  if(!coverHoverFrost){var shader=Resources.Load<Shader>("UI/CoverHoverFrost");if(shader)coverHoverFrost=new Material(shader);}
  surface.material=coverHoverFrost;surface.edge=Color.clear;
  var p=surface.rectTransform;float inset=24,content=w-inset*2;
  var ice=new Color32(225,230,237,255);var soft=new Color32(154,165,180,255);
  // Fine rectangular perimeter and tiny status marks suggest a phone without
  // adding another opaque panel or a decorative hardware bezel.
  Panel(p,new Rect(0,0,w,h),Color.clear,"Phone perimeter").edge=new Color(1,1,1,.18f);
  if(notebook){Text(p,new Rect(20,16,80,18),Clock(),11,ice,mono);Text(p,new Rect(w/2-24,16,60,18),"1907",11,soft,mono);var closePhone=Button(p,new Rect(w-43,7,26,29),"收好",()=>{CancelVoice();Mode="play";notebook=false;documentText="";},true,true,soft);var closeText=closePhone.GetComponentInChildren<TextMeshProUGUI>();closeText.text="×";closeText.fontSize=22;closeText.alignment=TextAlignmentOptions.Center;PhoneApps(p,w,h);Panel(p,new Rect(w/2-23,h-18,46,2),new Color(1,1,1,.35f),"Home indicator").edge=Color.clear;return;}
  Text(p,new Rect(inset,15,80,16),"1907",10,soft,mono);
  Panel(p,new Rect(w/2-17,12,34,3),new Color(1,1,1,.23f),"Earpiece").edge=Color.clear;
  for(int i=0;i<3;i++)Panel(p,new Rect(w-inset-34+i*4,24-i*2,2,3+i*2),soft,"Signal").edge=Color.clear;
  var battery=Panel(p,new Rect(w-inset-15,19,13,7),Color.clear,"Battery");battery.edge=soft;
  Panel(battery.transform,new Rect(2,2,7,3),soft).edge=Color.clear;
  Panel(p,new Rect(w-inset-1,21,2,3),soft).edge=Color.clear;
  Text(p,new Rect(inset,48,content-40,16),"LOCAL / RECORDS",9,soft,mono).characterSpacing=1;
  Text(p,new Rect(inset,70,content-40,42),documentTitle,24,ice,sans);
  var close=Button(p,new Rect(w-inset-30,47,30,40),"收好",()=>{Mode="play";notebook=false;documentText="";},true,true,soft);
  var closeLabel=close.GetComponentInChildren<TextMeshProUGUI>();closeLabel.text="×";closeLabel.fontSize=25;closeLabel.alignment=TextAlignmentOptions.Center;
  Panel(p,new Rect(inset,119,content,1),new Color(1,1,1,.13f)).edge=Color.clear;
  Panel(p,new Rect(inset,119,20,2),new Color(1,1,1,.4f)).edge=Color.clear;
  ScrollText(p,new Rect(inset,139,content,h-(notebook?252:194)),documentText,14.5f,ice,sans,9);
  if(notebook){
   float inputY=h-86;
   Panel(p,new Rect(inset,inputY-10,content,1),new Color(1,1,1,.12f)).edge=Color.clear;
   uiInput=Field(p,new Rect(inset,inputY,content-62,42),input,"给小饱发消息",s=>input=s,false,false);
   uiInput.textComponent.color=ice;uiInput.caretColor=ice;
   ((TextMeshProUGUI)uiInput.placeholder).color=soft;
   uiInput.onSubmit.AddListener(_=>Friend());
   var send=Button(p,new Rect(w-inset-54,inputY,54,42),"发送",Friend,false,true,ice);
   var graphic=send.GetComponent<ApartmentGraphic>();graphic.color=new Color(1,1,1,.08f);graphic.edge=new Color(1,1,1,.14f);var feedback=send.GetComponent<ApartmentSendFeedback>();feedback.restingText=ice;feedback.restingPanel=new Color(1,1,1,.08f);feedback.hoverPanel=new Color(1,1,1,.16f);
  }else Text(p,new Rect(inset,h-65,content,18),"LOCAL STORAGE / 只读",9,soft,mono);
  Panel(p,new Rect(w/2-23,h-18,46,2),new Color(1,1,1,.35f),"Home indicator").edge=Color.clear;
 }
}
}
