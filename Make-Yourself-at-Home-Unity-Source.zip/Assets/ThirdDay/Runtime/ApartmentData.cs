using System;
using System.Collections.Generic;
using UnityEngine;

namespace ThirdDay
{
    [Serializable] public class ApartmentData
    {
        public RootData[] roots; public SurfaceData[] materials; public MeshData[] meshes;
        public DeviceData[] devices; public ObjectData[] objects; public GridData grid;
        public NameData[] bagNames; public string[] ending; public LampData[] lamps;
    }
    [Serializable] public class RootData { public string name,parent; public float[] position,rotation,scale; public bool visible; }
    [Serializable] public class SurfaceData { public string name,texture; public float[] color,emission; public float emissionStrength,metal,roughness; public bool unlit,transparent,doubleSided,vertexColors; }
    [Serializable] public class MeshData { public string name,root,material; public float[] p,n,uv,c; public int[] indices; }
    [Serializable] public class DeviceData { public string id,name,persona,greeting; public float[] position,approach; }
    [Serializable] public class ObjectData { public string id,name; public float[] position,approach; public float floor; }
    [Serializable] public class GridData { public float x0,z0,cs; public int nx,nz; public int[] cells; }
    [Serializable] public class NameData { public string key,value; }
    [Serializable] public class LampData { public string id; public float[] position; }
    [Serializable] public class JournalEntry { public string title,time,key,detail,source;public int day; }
    [Serializable] public class FriendMessage {public bool me;public string text;}
    [Serializable] public class PhoneEvent {public string time,text;public int day;}
    [Serializable] public class DialogueEntry { public string id,question,reply; }
    [Serializable] public class GameState
    {
        public int version=2,day=1; public float clock=1060,x=10,z=1.4f,floor;
        public WelcomeState welcome=new WelcomeState();
        public bool lightsOn,opened,authLight,authLock,authMirror,mirrorConsent,offer,proofShared,truth,waterStop;
        public string ending="",playerName="";
        public bool traceCleaned,cleanRequested,traceLit,paperDry,lightAuto;
        public int vacuumAffinity,musicMood,airMode;
        public float lightLevel=1,musicGain=.7f;
        public List<string> bag=new List<string>(),met=new List<string>();
        public List<JournalEntry> journal=new List<JournalEntry>();
        public List<DialogueEntry> conversations=new List<DialogueEntry>();
        public List<FriendMessage> friendMessages=new List<FriendMessage>{new FriendMessage{me=false,text="到了吗？新家怎么样。"},new FriendMessage{me=false,text="三天带薪适应假期已安排。住宅照片外发要经过本户流程，有需要先看回执。"}};
        public List<PhoneEvent> phoneEvents=new List<PhoneEvent>();
    }
    public static class ApartmentCoordinates
    {
        public static Vector3 World(float[] p) => new Vector3(p[0],p.Length>2?p[1]:0,-p[p.Length>2?2:1]);
    }
}
