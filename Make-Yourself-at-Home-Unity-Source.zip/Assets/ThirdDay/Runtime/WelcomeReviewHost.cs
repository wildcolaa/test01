#if UNITY_EDITOR
using UnityEngine;
namespace ThirdDay { public sealed class WelcomeReviewHost:MonoBehaviour {} }
#endif
