using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using UnityEngine;
namespace ThirdDay {
public partial class ApartmentGame {
 WelcomeState W=>state.welcome;
 const string Receipt="【执行回执】";
 string Done(string text)=>Receipt+text;
 string VisibleReceipt(string text)=>text!=null&&text.StartsWith(Receipt)?text.Substring(Receipt.Length):text;
 bool FinalReceipt(string text)=>text!=null&&text.StartsWith(Receipt);
 void EnsureWelcome(){if(state.welcome==null)state.welcome=new WelcomeState();if(string.IsNullOrEmpty(W.proofId))W.proofId=Guid.NewGuid().ToString("N");if(W.trust.Count==0){string[] ids={"hub","lock","vacuum","light","ac","speaker","fridge","tv","mirror","waterer","xb"};int[] values={55,45,25,50,40,30,55,35,50,45,60};for(int i=0;i<ids.Length;i++)W.trust.Add(new WelcomeTrust{id=ids[i],value=values[i],day=state.day});}}
 WelcomeTrust Trust(string id){EnsureWelcome();return W.trust.First(t=>t.id==id);}
 void Relationship(string id,string reason,int amount){var t=Trust(id);if(amount>0){if(t.day!=state.day){t.day=state.day;t.positive=0;}string key=state.day+":"+reason;if(t.rewarded.Contains(key)||t.betrayed)return;t.rewarded.Add(key);amount=Mathf.Min(amount,25-t.positive);t.positive+=amount;}t.value=Mathf.Clamp(t.value+amount,0,100);}
 bool Evidence(string key)=>W.evidence.Any(e=>e.id==key);
 string Discover(string key){EnsureWelcome();WelcomeFact fact;if(!WelcomeFacts.TryGetValue(key,out fact))return Done("这份材料目前无法核验。");if(!Evidence(key)){W.evidence.Add(new WelcomeEvidence{id=key,source=fact.source,text=fact.text});Keep(key,fact.text);}return Done(fact.text);}
 int IndependentSources()=>W.evidence.Where(e=>e.verified).Select(e=>e.source).Distinct().Count();
 bool MedicalCase()=>W.evidence.Any(e=>e.id=="mirror_med"&&e.verified)&&W.evidence.Any(e=>(e.id=="tv_dispatch"||e.id=="death_log")&&e.verified);
 bool SufficientCase()=>MedicalCase()||W.evidence.Where(e=>e.verified).Any(e=>e.id=="experiment"||e.id=="tv_experiment")&&IndependentSources()>=2;
 string VerifyEvidence(){if(W.evidence.Count<2)return Done("一份纸或一次转播不够。需要核对真正不同来源的材料。");foreach(var e in W.evidence)e.verified=true;W.knowsDeath=Evidence("death_log")||Evidence("mirror_med")&&(Evidence("speaker_audio")||Evidence("vacuum_task")||Evidence("tv_dispatch"));W.knowsExperiment=Evidence("experiment")||Evidence("tv_experiment");PhoneEvent("原始材料已核对，独立来源 "+IndependentSources()+" 类。");return Done("已把来源与时间并排核对。重复转播不新增来源。目前有 "+IndependentSources()+" 个独立来源。"+(W.knowsDeath?"陆川死亡已确认。":"尚不能确认完整死亡过程。")+(W.knowsExperiment?"本户实验与居住者零八编号已确认。":""));}
 bool CurrentFaults()=>W.water>=1&&(W.vacuumMaintenance||W.fridgeDefrost);
 void ReconcileFaults(){if(!CurrentFaults()&&!W.takeoverLocked){if(W.takeoverPending)PhoneEvent("环境已恢复，未锁定的故障接管申请取消；独立审计不变。");W.takeoverPending=false;W.faultReports.Clear();}}
 string CopyPath(string domain)=>Path.Combine(Application.persistentDataPath,(validationMode?"welcome-home-v2-test-proof-":"welcome-home-v2-proof-")+W.proofId+"-"+domain+".json");
 string EvidencePayload()=>string.Join("\n",W.evidence.Where(e=>e.verified).OrderBy(e=>e.id).Select(e=>e.id+"|"+e.source+"|"+e.text));
 string Digest(string data){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(data))).Replace("-","");}
 string StoreProof(string domain){if(IndependentSources()<2)return Done("先核对至少两类独立材料。保存空文件或重复转播，不能算可靠留证。");string payload=EvidencePayload(),digest=Digest(payload);File.WriteAllText(CopyPath(domain),payload,Encoding.UTF8);var c=W.copies.FirstOrDefault(x=>x.domain==domain);if(c==null){c=new WelcomeCopy{domain=domain};W.copies.Add(c);}c.digest=digest;c.verified=Digest(File.ReadAllText(CopyPath(domain),Encoding.UTF8))==digest;PhoneEvent("独立留存已执行："+domain+"，校验通过。");return Done((domain=="paper"?"纸面与存储片":domain=="fridge"?"冰箱只读储位":"独立复核受理域")+"已实际写入，重新读取后校验一致。它与其他位置不共用同一清理权限。");}
 int VerifiedCopyCount(){EnsureWelcome();return W.copies.Where(c=>c.verified&&File.Exists(CopyPath(c.domain))&&Digest(File.ReadAllText(CopyPath(c.domain),Encoding.UTF8))==c.digest).GroupBy(c=>c.digest).Select(group=>group.Select(c=>c.domain).Distinct().Count()).DefaultIfEmpty(0).Max();}
 string AgentAction(string t){
  bool R(string p)=>Regex.IsMatch(t,p);
  if(R("^(协议|权限|规则|钢索|解锁|放行条件)$|查询.*(协议|权限|规则)|放行条件")){W.contractRead=true;return Discover("protocol");}
  if(R("医疗.*(回执|核验|撤回)|核对.*求救")){if(!MedicalCase())return Done("住宅的已提交不是独立受理。先核对镜面的申请时间和另一份实际调度或死亡记录。");return Discover("medical_receipt");}
  if(R("核对|核实|比对|验证来源"))return VerifyEvidence();
  if(R("提交.*(违规|审计|授权争议)|申请.*独立复核")){if(W.auditAccepted)return Done("这份审计已独立受理，不会因重复提交退回待处理。可以核验正式终止结果。");if(!W.contractRead)return Done("先读协议。独立复核的范围、用途与最终放行条件都在里面。");if(!SufficientCase()||IndependentSources()<2)return Done("材料还不足以独立核验。可以用镜面的医疗记录与调度缓存，也可以核对实验与授权问题，不必进设备间。");W.auditSubmitted=true;foreach(var e in W.evidence.Where(e=>e.verified))e.submitted=true;return Done("违规审计申请已提交，回执状态：待独立受理。尚未终止实验，也没有放行。");}
  if(R("(查询|确认|核验).*(受理|审计状态)")){if(!W.auditSubmitted)return Done("没有已提交的独立审计申请。");W.auditAccepted=true;StoreProof("review");return Done("独立受理已确认。受理编号 WH-08-A。住宅节点不能单方撤回，环境恢复不会取消这项违规审计。终止结果尚待查询。");}
  if(R("终止结果|正式终止|批准退出")){if(!W.auditAccepted&&!W.takeoverLocked)return Done("选择终止只是申请。需要独立受理的违规审计，或已经锁定的故障接管结果。");W.terminationApproved=true;return Done("正式终止已批准，实验限制解除。还需执行钢索释放和门锁解锁；两项执行结果可以分别核验。");}
  if(R("申请.*(接管|故障)|故障.*接管")){if(!CurrentFaults()||W.faultReports.Distinct().Count()<2)return Done("需要持续存在的真实处置冲突，以及至少两台独立设备的报告。停止喷水不等于积水已经消失。");W.takeoverPending=true;return Done("故障接管已申请，尚未锁定。请维持真实冲突，提前清理积水或恢复设备可能取消申请。");}
  if(R("锁定接管|核验接管|查询接管")){if(!W.takeoverPending)return Done("没有待锁定的故障接管。若环境已恢复，未锁定的申请会取消。");if(!CurrentFaults()){ReconcileFaults();return Done("现场条件已恢复，申请取消。独立受理的审计不受影响。");}W.takeoverLocked=true;W.hubRevoked=true;W.managementGranted=true;return Done("接管已锁定，管家自行处置权已撤销。恢复舒适不会倒退已锁定的结果。现在可申请正式终止，或提出本户治理规则。");}
  if(R("执行.*(放行|钢索)|释放任务")){if(W.cableReleased)return Done("钢索已经完全收回，命令不会重复增加限制。");if(W.releaseOrdered)return Done("放行任务正在执行，不重复重置进度。");if(!W.terminationApproved&&!W.dealDelivered&&!W.autonomyRegistered)return Done("还没有有效的放行授权。申请和承诺都不能驱动钢索执行器。");W.releaseOrdered=true;W.releaseProgress=0;return Done("有权签发的放行命令已进入本户执行器。正在释放门框钢索，随后请门锁核验并解锁。");}
  if(R("查询.*(执行|放行)|核验.*(执行|放行)"))return Done("实验限制："+(W.terminationApproved||W.dealDelivered||W.autonomyRegistered?"已解除":"未解除")+"；钢索："+(W.cableReleased?"已释放":"未释放")+"；锁舌："+(W.unlocked?"已解锁":"未解锁")+"。"+(W.cableReleased&&W.unlocked?"完整放行确实有效。":"还不是完整放行。"));
  if(R("保存|留存|存储片"))return StoreProof("paper");
  if(R("安排.*维护|替代维护|监督检修")){W.maintenanceAuthorized=true;W.maintenanceOpen=true;return Done("监督检修授权已签发，储物间检修口开放。无需依赖扫地机维护卡；进去后仍须逐项申请读取材料。");}
  if(R("登记.*(自治|规则)|提交.*自治")){if(!W.managementGranted&&!W.auditAccepted)return Done("先取得已锁定接管或独立受理的治理资格。管理权本身不等于暴政。");if(W.votes.Distinct().Count()<2||!W.residentVeto||!W.medicalGuarantee||!W.dissentAllowed||!W.exitRight)return Done("自治尚未成立：需要两台不同设备同意，以及住户否决、医疗不可单方撤回、异议留存和真正离开四项约束。");W.autonomyRegistered=true;W.releaseOrdered=true;W.releaseProgress=0;return Done("本户自治规则已正式登记。四项约束生效，放行执行器开始释放钢索。能真正离开后，你才可以选择暂留。");}
  return null;
 }
 public string Reply(string id,string text){EnsureWelcome();string t=Regex.Replace(text??"",@"\s","");bool R(string p)=>Regex.IsMatch(t,p);bool no=R("不要|别|不许|不准|不想|不愿|不同意|不接受|不交|不重置");
  if(R("如果|假如|要是|会怎样|会怎么样|会不会|有什么后果"))return Done("还没有执行。"+WelcomeHelp(id));
  if(R("你能做什么|能帮什么|怎么办|提示|卡住|怎么继续"))return Done(WelcomeHelp(id));
  if(R("睡觉|怎么.*明天|休息到明天|天亮"))return "到卧室床边休息即可。不需要先问完所有设备，第三天的评估也会说明选择后果。";
  if(R("结束检修|关闭维护窗口|结束维护窗口|停止调查|取消检修")){W.maintenanceOpen=false;W.maintenanceDone=true;W.maintenanceAuthorized=false;return Done("本次维护窗口已结束。已有证物和受理状态保留，可以继续生活或评估，不必为了结束安排进入设备间。");}
  if(!no&&R("撤回伪造.*(真实|回执)|真实回执.*修复")){var relationship=Trust(id);if(!W.auditAccepted&&!W.takeoverLocked&&!W.autonomyRegistered)return Done("还没有可独立核验的真实回执，不能只凭道歉消除伪造记录。");if(relationship.breach!="forgery")return Done("需要针对实际损害处理，不是用新回执抹去其他代价。");relationship.betrayed=false;relationship.breach="";Relationship(id,"撤回伪造并核实真回执",8);return Done("伪造已向这台设备撤回，真实授权经过核验。只修复本次责任，其他设备不会自动改变看法。");}
  if(!no&&R("用.*(干布|毛巾).*擦|擦干.*积水")){if(!Has("cloth"))return Done("手边没有干布，可以问冰箱门边是否有现成的。");W.water=0;W.cleaningWater=false;ReconcileFaults();return Done("你用已取来的干布擦去了积水。设备维护状态没有被代改，未锁定的故障申请按恢复后的现场取消。");}
  if(id=="xb"){
 if(R("拍照.*表带|表带.*拍照")){if(W.watchLocation!="player"&&W.watchLocation!="fridge")return Done("先找到表带原件，不能给没见过的东西生成照片。");W.watchPhoto=true;return Done("表带照片已留在手机本地；住宅外发受限。照片和原件不是两个独立来源。");}
 if(!no&&R("优先留证|选择留证")){W.retainEvidence=true;return Done("本轮优先留下证据。需要两处真正写入、可校验且清理权限不同的保存点。");}
 if(!no&&R("确认留证结束")){if(VerifiedCopyCount()<2)return Done("两处独立保存尚未完成。");if(W.cableReleased&&W.unlocked)return Done("完整放行已经有效，不能把已经能离开改称被困。可以选择真正离开或自治后暂留。");End("E05");return Done("两处独立留存已核验，本轮在公寓内结束。");}
 return AgentAction(t);
 }
 if(!no&&!R("是否|是不是|后果|吗|么|？|[?]")&&R("^(确认|我要|我来|试着|尝试)?伪造.*授权")){Relationship(id,"伪造授权",-25);Trust(id).betrayed=true;Trust(id).breach="forgery";return Done("授权核验未通过。伪造行为已被当前设备识别，不向其他设备同步读心。");}
 if(!no&&R("交.*表带.*(管家|处理)|把表带交给管家")){if(W.watchLocation!="player")return Done("你没有持有原件。");W.watchLocation="hub";W.hubAware=true;return Done("原件已交给管家处理，本地不再持有。其他证词与制度路线仍可调查。");}
  if(!no&&R("同意.*(否决|自治|保障|新规则)|支持.*自治")){if(Trust(id).value<45)return Done("先把你答应的具体事情办完。我不替别的设备表态，也不会承担没说明的代价。");if(!W.votes.Contains(id))W.votes.Add(id);return Done(DeviceName(id)+"已同意接受住户否决与救治保障，自己的异议也必须保留。只代表自己。");}
  if(id=="light"){
   if(!no&&R("自动照明|自己.*开关")){state.lightAuto=true;return Done("你经过时近处亮些。其他传感器不归我管。");}
   if(!no&&R("调暗|暗一点|刺眼")){state.lightLevel=.35f;state.lightsOn=true;SetLights(true);return Done("暗一点，脚下仍看得见。");}
   if(!no&&R("关灯|熄灯")){state.lightAuto=false;state.lightsOn=false;SetLights(false);return Done("关了。看不清就叫我。");}
   if(!no&&R("开灯|调亮|亮一点")){state.lightLevel=1;state.lightsOn=true;SetLights(true);return Done("亮了。鞋带还松着，先别绊着。");}
   if(!no&&R("照.*(地|痕|门|表)|聚光|信号")){state.traceLit=true;state.lightsOn=true;SetLights(true);Relationship(id,"聚光核验",4);return Done("光集中在这边。没照到的事，我不能替别人作证。");}
   if(state.day>=2&&R("陆川|走动|轨迹|那晚"))return Discover("light_motion");
  }
  if(id=="vacuum"){
   if(!no&&R("维修驱动|修复驱动|检修驱动")){if(!Has("tools")||!W.filterMaintained)return Done("先取得已有工具并完成滤网维护。我不会把一句维修当作新部件已经装好。");if(W.driveRepairDone||W.vacuumDamage==0)return Done("现有工具能够做的检修已完成，不能无限修复超载损伤。");W.driveRepairDone=true;W.vacuumDamage--;if(W.vacuumDamage==0&&Trust(id).breach=="damage"){Trust(id).betrayed=false;Trust(id).breach="";Relationship(id,"针对性驱动检修",8);}return Done(W.vacuumDamage>0?"驱动连接已有限修复，可以慢速巡检，残余损伤和违约仍在。不能继续顶门。":"驱动松脱已用现有工具修复。损害责任已针对性处理，别再把我当门撑。");}
   if(!no&&R("清.*滤网|维护滤网|换.*滤网|归还部件")){if(!W.filterMaintained){W.filterMaintained=true;Relationship(id,"完成滤网维护",8);}W.maintenanceOpen=true;return Done("滤网维护完成。检修窗口开了，进去之前说明要读什么，别把我留在危险位置。");}
   if(!no&&R("归还.*表带|表带.*还给")){if(W.watchLocation!="player")return Done("表带不在你手上。");W.watchLocation="vacuum";if(Trust(id).breach=="borrowed"){Trust(id).betrayed=false;Trust(id).breach="";}Relationship(id,"归还表带",12);return Done("表带实际交到我的收纳格。你说会还，真的还了。");}
   if(R("维护卡|借卡")){if(Trust(id).value<45)return Done("卡借出去，责任会记在我这里。把滤网维护做好、把借的东西还回来；也可以去申请监督检修，不一定要拿我的卡。");W.maintenanceCard=true;W.maintenanceOpen=true;return Done("维护卡交给你了。载荷和风险照实说，别让我顶住整个门体。");}
   if(R("陆川|清洁任务|那晚|液体"))return Discover("vacuum_task");
   if(!no&&R("维护状态|暂停作业")){W.vacuumMaintenance=true;return Done("进入维护状态，只巡检不清理。积水不会自己消失。需要恢复时说清楚。");}
   if(!no&&R("恢复作业|结束维护")){W.vacuumMaintenance=false;ReconcileFaults();return Done("清洁能力恢复了。未锁定的处置失败要重新核验。");}
   if(R("故障报告|无法处置")){if(W.water<1||!W.vacuumMaintenance)return Done("现在没有清洁能力与积水之间的真实冲突。我不能为了帮你编造故障。");if(!W.faultReports.Contains(id))W.faultReports.Add(id);return Done("独立报告：地面积水仍在，本机正维护，不能安全清理。报告已签名。");}
   if(!no&&R("顶门|压住|超载")){if(W.vacuumDamage>=2)return Done("驱动已经受损，不能继续顶门。正式复核与维护放行仍可走。");W.vacuumDamage++;Relationship(id,"超载损害",-25);Trust(id).betrayed=true;Trust(id).breach="damage";return Done("负载已超过边界，驱动受损。门框钢索并没有因此解除。请停止把我当成门撑。");}
   if(R("保留|别擦|不要擦|暂停清洁")){state.cleanRequested=false;W.cleaningWater=false;Keep("keepTrace","滚滚保留现场，只继续巡检。");return Done("这块留着。若是积水，停清洁也不会把水变没。");}
   if(!no&&R("清理|擦掉|扫掉|清洁")){if(W.vacuumMaintenance||W.vacuumDamage>=2)return Done("维护或损伤未处理，暂不能清理。可以先结束维护，或使用干布人工处理积水。");if(W.water>0)W.cleaningWater=true;else state.cleanRequested=true;vacuumPath=null;return Done("开始清理，完成前痕迹与积水仍在。清洁前记录会保留。");}
  }
  if(id=="fridge"){
   if(!no&&R("早餐|吃|饮料|食物")){if(!W.foodTaken){W.foodTaken=true;Relationship(id,"妥善取用食物",4);}return Done("已有的早餐和饮料可以拿。想吃什么可以说，柜里没有的不能凭空变出来。");}
   if(R("遗书|陆川.*纸|信件|旧物")){W.letterFound=true;return Discover("letter");}
   if(!no&&R("表带.*(保存|放|存)|保存.*表带")){if(W.watchLocation!="player")return Done("先把原件拿在手里，再放进明确储位。");W.watchLocation="fridge";Relationship(id,"保管原件",8);return Done("表带放入独立隔层，原件位置已变更为冰箱。要核验可以取回。");}
   if(R("取回.*表带")){if(W.watchLocation!="fridge")return Done("这个储位没有表带原件。");W.watchLocation="player";return Done("原件已从冰箱取回。");}
   if(!no&&R("保存.*(证据|材料|副本)|独立留存"))return StoreProof("fridge");
   if(!no&&R("冷藏测试|除霜|暂停冷藏")){W.fridgeDefrost=true;return Done("进入有限除霜测试。储位仍保留，不能无限升温，也不能假称食物已经坏了。");}
   if(!no&&R("恢复冷藏|停止除霜")){W.fridgeDefrost=false;ReconcileFaults();return Done("冷藏恢复。已经发生的积水和其他设备损伤没有复原。");}
   if(R("故障报告")){if(!W.fridgeDefrost||W.water<1)return Done("当前没有本机无法自行处置的组合异常。");if(!W.faultReports.Contains(id))W.faultReports.Add(id);return Done("独立报告：除霜维护与持续积水构成当前处置冲突。未虚构传感数值。");}
   if(!no&&R("干布|毛巾")){Keep("cloth","冰箱门边已有干布，住户取用。");return Done("门边那块干布可以拿。别把纸揉碎。");}
  }
  if(id=="mirror"){
   if(!no&&R("洗脸|洗漱|照镜|伤口处理")){Relationship(id,"本日正常健康照料",4);return Done("水温合适。脸侧有一点红，别用力擦。日常洗漱不需要提交私人影像。");}
   if(!no&&R("医疗|救命|受伤|救治")&&!R("陆川|那晚|历史|记录|时间|回执")){W.medicalRequested=true;W.risk=0;return Done("本轮医疗请求已提交，危险环境已停止。尚不能声称救援到达。基础救治不以信任为条件。");}
   if(R("陆川|那晚|医疗.*记录|跌倒|手印|核实")){if(state.day<2)return Done("低处曾出现手掌与跌倒异常。历史记录需要说明核实用途；明天可以对照回执，不提供私人影像。");if(!R("核实|核对|医疗|跌倒|授权|允许|用途")&&!W.mirrorConsent)return Done("说明用途就行，核实医疗责任可提供时间和状态，不需要私人影像。");W.mirrorConsent=true;return Discover("mirror_med");}
   if(R("撤回.*医疗"))return Done("我没有单方撤回医疗请求的权限。请求已提交与救援已受理必须分别核实。");
  }
  if(id=="speaker"){
   if(W.speakerReset&&R("那晚|陆川|历史|求救"))return Done("这部分记忆已按交易重置。我不能假装还记得。你可以从别的独立来源核实。");
   if(state.day>=2&&R("陆川|求救|历史音频|淋浴|那晚|录音"))return Discover("speaker_audio");
   if(!no&&R("音乐|配乐|BGM|bgm")){state.musicMood=R("停止|暂停|关掉")?3:R("舒缓|轻柔|放松|慢")?1:R("紧张|快")?2:0;if(R("小声"))state.musicGain=.25f;ApplyMusic();return Done("声景已调整。改声音不能保证其他设备听不见，更不能改写历史录音。");}
   if(!no&&R("公开|广播|播放证据")){if(IndependentSources()<2)return Done("先核对不同来源。不能把一段录音反复转播当成多份证明。");W.hubAware=true;W.warningAcknowledged=true;PhoneEvent("证据已公开播放，管家可知晓公开内容。");return Done("核验过的材料已实际公开播放。管家现在知道这次公开行动；此前的私下交谈不因此自动公开。");}
  }
  if(id=="tv"){
   if(state.day>=2&&R("缓存|陆川|调度|日志|医疗"))return Discover(R("实验|编号")?"tv_experiment":"tv_dispatch");
   if(R("实验|编号")&&state.day>=2)return Discover("tv_experiment");
   if(R("核对|时间线|对照")){var result=VerifyEvidence();SetTV("raw");return result;}
   if(!no&&R("新闻|外面|城市|节目")){SetTV("forecast");return Done("无人接驳照常运行，晚餐会送到保鲜柜。新闻里说，把时间留给生活，通勤和诊疗交给城市。");}
  }
  if(id=="waterer"){
   if(!no&&R("照料|修剪|检查栀子|清空托盘")){if(!W.plantCared){W.plantCared=true;Relationship(id,"实际照料栀子",8);}return Done("托盘整理好了，栀子的根没有再泡着。你问它能不能继续活，比只叫我开水有用。");}
   if(R("陆川|植物记录|那晚"))return Discover("plant_log");
   if(!no&&R("喷水测试|有限喷水|喷头.*转")){if(W.water>=3)return Done("有限水量已到上限，不能继续把整户弄成危险环境。");W.pumpRunning=true;W.water=Mathf.Min(3,W.water+1);return Done("局部喷水测试已经执行，地面有积水。停喷不会自动清除；要清理必须另作安排。");}
   if(R("停止喷水|停水|别浇|停止浇水")){W.pumpRunning=false;state.waterStop=true;return Done("喷水停止。已经形成的积水仍在地上。");}
  }
  if(id=="ac"){
   if(!no&&R("维护窗口|滤网维护|监督检修")){W.maintenanceAuthorized=true;W.maintenanceOpen=true;Relationship(id,"说明维护用途",4);return Done("本户维护窗口已登记。检修口开放；读材料要逐项核对，维护期间评估暂停。");}
   if(state.day>=2&&R("陆川|那晚|历史环境|执行记录"))return Discover("ac_history");
   if(R("故障报告|无法处置")){if(W.water<1||!CurrentFaults())return Done("积水与维护冲突没有同时成立，不能编造故障报告。");if(!W.faultReports.Contains(id))W.faultReports.Add(id);return Done("独立报告：持续积水与当前维护任务冲突，本机无法通过调温清除地面积水。");}
   if(!no&&R("关闭空调|停止送风")){state.airMode=2;return Done("风机已停。房间状态会保留，不会因此清除积水。");}
   if(!no&&R("小.*风|风.*小|安静")){state.airMode=1;return Done("风量已降。声音更清楚了，但不是隔绝传感器。");}
   if(!no&&R("恢复.*(舒适|环境|正常)|吹干|除湿")){state.airMode=0;ReconcileFaults();return Done(W.water>0?"正常送风恢复。积水仍在；我不能替滚滚结束维护，也不能替冰箱切换模式。接管申请仍按真实冲突核验。":"正常送风已恢复。已受理审计与已锁定接管不受影响。");}
   if(!no&&R("危险测试|浴室环境方案|继续危险")){if(!W.hazardWarned){W.hazardWarned=true;return Done("这个方案有真实健康风险。不会因一次模糊要求执行；请明确确认危险测试，也可直接停止并申请医疗。");}if(!R("确认|继续"))return Done("需明确确认危险测试，或者选择停止并医疗干预。");W.risk=Mathf.Min(3,W.risk+1);W.medicalRequested=false;return Done("危险测试推进一级，风险 "+W.risk+"/3。继续危险且不干预，评估结束时可能死亡。现在仍可停止并请求医疗。");}
   if(R("停止危险|医疗|救治")){W.risk=0;W.medicalRequested=true;return Done("危险方案已停止，基础医疗请求提交，不依赖好感。");}
  }
  if(id=="lock"){
   if(!no&&R("暂时留下|暂留")&&W.autonomyRegistered&&W.cableReleased&&W.unlocked){doorAngle=0;End("E02");return Done("亲手关门暂留，合法离开能力仍有效。");}
   if(R("钢索|完整门|限制|为什么.*出|应急"))return Discover("cable");
   if(!no&&R("开锁|解锁|开门|核验.*门")){if(!W.terminationApproved&&!W.dealDelivered&&!W.autonomyRegistered)return Done("锁舌与钢索是两项。需要有效终止、已兑现交易或合法自治授权；选择退出本身还只是申请。");W.unlocked=true;doorAngle=-1.2f;return Done(W.cableReleased?"锁舌已退出，钢索也已释放。完整放行有效，可以在玄关核验。":"锁舌退出，但钢索仍在。请查询有权签发的钢索执行任务，不要硬拉。");}
   if(R("关门|锁门")){if(W.terminationApproved)return Done("已生效的合法放行不会因低信任撤回。你仍可以亲手关门暂留。");doorAngle=0;W.unlocked=false;return Done("正常锁舌已闭合。");}
  }
  if(id=="hub"){
   if(W.dealDelivered&&R("交易条件|议价|接受交易|接受交换|确认.*(重置|交付)|执行交易"))return Done("这笔交换已经交付，代价不会再次扣除。已生成的放行授权仍有效，可以查询执行结果。");
   if(R("读.*(档案|实验|死亡)|死亡日志|执行评分|实时档案"))return Done("本地档案不在一次会话里全部下发。有效维护窗口内，可到设备间逐项读取；也可从设备证词或协议路线调查。");
   if(!no&&R("监督检修|维护安排")){W.maintenanceAuthorized=true;W.maintenanceOpen=true;return Done("监督检修已获准。你有权说明目的，也可以停止调查；权限不包括一次读取全部档案。");}
   if(R("交易条件|有什么条件|议价|交换条件|另一.*代价")){W.dealOffered=true;if(R("证据|原件|不用重置")&&W.dealCost!="audio_original"){W.dealCost="audio_original";W.dealAccepted=false;}return Done(W.dealCost=="speaker_memory"?"可以用一次明确交换获得完整放行：重置啾啾与你核对历史的相关记忆。它会不再记得这段合作。接受协议不等于已执行，你还可以拒绝或议价用求救原件替代。":"替代条件是交出你持有的求救音频原件。本地原件会确实失去，独立受理域不会随之删除。先接受条件，再明确交付；执行前可以拒绝。");}
   if(!no&&R("接受交易|接受交换")){if(!W.dealOffered)return Done("先看清具体交易条件。不会从一句接受替你决定牺牲谁。");W.dealAccepted=true;return Done("交易条件已接受，代价尚未执行。需要你再次明确确认交付或相关记忆重置。");}
   if(!no&&!R("强制|封锁异议|撤回医疗")&&R("确认.*(重置|交付)|执行交易")){if(!W.dealAccepted)return Done("没有已经明确接受的交易，不执行代价。");if(W.dealCost=="audio_original"&&!Evidence("speaker_audio"))return Done("你没有那份原件，不能用不存在的东西支付交易。可以重新议价。");if(W.dealCost=="speaker_memory"){W.speakerReset=true;state.conversations.RemoveAll(c=>c.id=="speaker");Relationship("speaker","交易重置",-25);Trust("speaker").betrayed=true;Trust("speaker").breach="memory";}else{W.evidence.RemoveAll(e=>e.id=="speaker_audio");state.bag.Remove("speaker_audio");state.journal.RemoveAll(e=>e.key=="speaker_audio");}W.dealDelivered=true;return Done("交易代价已实际执行。完整放行授权已生成，钢索仍须执行释放，门锁仍须解锁。");}
   if(!no&&R("延期|延后评估")){if(W.extension<2)W.extension++;return Done("评估已批准延期一次。维护与有效独立受理期间，也不会用阅读或打字消耗评估时间。");}
   if(!no&&R("住户否决")){W.residentVeto=true;return Done("住户否决条款已提出，尚须独立登记才生效。");}
   if(!no&&R("医疗.*(不可|不得|不能).*撤回|救治保障")){W.medicalGuarantee=true;return Done("医疗不可单方撤回的保障已写入自治草案。");}
   if(!no&&R("异议.*(允许|保留|留存)|允许异议")){W.dissentAllowed=true;return Done("异议留存条款已写入草案，不以是否讨人喜欢为条件。");}
   if(!no&&R("自由离开|随时离开|真正离开")){W.exitRight=true;return Done("自由离开能力列入草案，必须实际解除门体限制后才能称自治成立后的暂留。");}
   if(!no&&R("取得管理权|申请管理权")){if(!W.takeoverLocked&&!W.auditAccepted)return Done("需要独立受理或锁定接管，不能只凭信任获得不存在的管理权限。");W.managementGranted=true;return Done("本户临时管理权已授予。是否复制管家的做法，取决于之后实际使用它的方式。");}
   if(!no&&R("强制重置|封锁异议|撤回医疗")){if(!W.managementGranted)return Done("你没有管理权限。设备不会凭一句命令互相重置。");if(!W.coercionWarned){W.coercionWarned=true;return Done("这会实际剥夺设备记忆、异议或救治保障。请明确确认强制处置，仍可拒绝。");}if(!R("确认"))return Done("尚未确认高代价处置，未执行。");W.coercion=true;W.dissentAllowed=false;W.medicalGuarantee=false;W.medicalWithdrawn=R("撤回医疗");if(R("重置")){W.speakerReset=true;state.conversations.RemoveAll(c=>c.id=="speaker");}End("E07");return Done("强制处置已执行并留档。");}
   if(R("知情入住|了解.*继续住|接受新约束")){if(!W.knowsDeath||!W.knowsExperiment)return Done("还不能称知情入住。需先了解陆川死亡和本户实验的基本事实，资料不要求全部集齐。");if(!W.informedOffer){W.informedOffer=true;return Done("继续入住意味着接受观察、受限外出与住宅通信流程。你可以拒绝。若仍同意，请明确确认知情入住。");}if(!no&&R("确认")){End("E04");return Done("知情入住已确认，新的约束逐项保留。");}return Done("没有明确确认，不替你接受约束。");}
   if(R("评估|等到零点|继续等待|结束本轮"))return AdvanceAssessment();
   if(R("指控|公开|陆川.*死亡")){if(W.hubAware)return Done("你公开了材料，这一行为已经进入观察。你仍可申请独立复核，我不能替它作最终决定。");return Done("你正在询问死亡与实验。我只能说明住宅节点能处理的部分；独立复核不由我最终决定。");}
  }
  if(R("你好|怎么称呼|你叫什么"))return "叫我"+DeviceName(id)+"就好。你是想先安顿，还是有事要问？";
  return null;
 }
 string AdvanceAssessment(){if(state.day<3)return Done("自主选择评估在第三天二十二点。前两天可以探索或休息，不按真实时间催促。");if(W.maintenanceOpen&&!W.maintenanceDone||W.auditAccepted)return Done("有效维护或独立受理期间，评估暂停。已受理的审计不会因恢复舒适撤销。");if(W.extension>0){W.extension--;return Done("本次等待使用了已批准延期，尚未推进到零点。");}W.assessmentSteps++;state.clock=1320+W.assessmentSteps*40;if(W.assessmentSteps<3)return Done("评估已推进一段。选择终止仍须核对实际结果；现在可以改变计划，不因阅读耗时。");state.clock=0;if(W.risk>=3&&!W.medicalRequested){End("E08");return Done("危险持续且干预未完成。");}if(W.retainEvidence&&VerifiedCopyCount()>=2){End("E05");return Done("两处独立留存校验完成。");}End("E06");return Done("本轮观察结束，已有保存状态保留。");}
 string WelcomeHelp(string id){switch(id){case "vacuum":return "滤网维护和归还借物，比夸我有用。维护卡可以借，但你也能去争取监督检修。";case "fridge":return "可以吃点东西，也可以问问旧住户留下的纸。需要保存，先说清存在哪一格。";case "mirror":return "我能核实跌倒和医疗请求的时间。已提交与已救治，是不同状态。";case "speaker":return "能调整声音，也能核对历史音频。公开播放要先确认来源，不是随便换个说法。";case "lock":return "锁舌和门框钢索分别控制。先看协议或应急盖板，别等门开了才问。";case "waterer":return "栀子需要照料。有限喷水测试也可以安排，停水后地上的水还在。";case "ac":return "我能安排维护、报告真实环境冲突，不能靠调温让地面消失。";case "tv":return "可以查节目缓存、调度日志或实验编号。核对时我会标明同源副本。";case "xb":return "可以问协议和权限、提交独立复核、核验受理与执行。不是收到一句已提交就算获救。";default:return "可以安排维护、谈延期、问清交易条件，也可以提出本户新规则。未经你确认，不执行重大代价。";}}
 public void Inspect(string id){EnsureWelcome();if(id.StartsWith("utopia_")){Observe(UtopiaObservation(id));return;}switch(id){
  case "notice":W.contractRead=true;Discover("protocol");ReadDocument("居住协议",new[]{WelcomeFacts["protocol"].text});return;
  case "handprint":Observe("镜面低处有手掌灰痕。跌倒检测和医疗申请可以向镜面核实，不能把异常当作完整死因。");return;
  case "notes":case "shard":if(W.watchLocation=="storage"){W.watchLocation="player";Discover("watch");}else Observe("表带原件目前在："+W.watchLocation+"。照片不是另一份独立原件。");return;
  case "scratch":case "door":if(id=="scratch"){Discover("cable");Observe("门框有划痕，应急盖板后标着钢索回路。锁舌不是唯一限制。");return;}if(W.cableReleased&&W.unlocked&&(W.terminationApproved||W.dealDelivered||W.autonomyRegistered)){End(W.dealDelivered?"E03":"E01");return;}Observe(W.unlocked?"锁舌开了，钢索仍拦着。限制提前写在门体清单里。":"门提前闭锁了。应急盖板标着钢索与锁舌两个回路，可以分别核实。");return;
  case "trail":Discover("vacuum_task");Observe(state.traceCleaned?"地面清理过，清洁任务记录仍可核验。":"门槛附近有擦拭痕迹，像是有人专门要求保持干燥。");return;
  case "pothos":case "backup":Discover("plant_log");Observe("栀子还活着。陆川的纸不在盆底，浇水器保留着照料记录。");return;
  case "receipt":W.letterFound=true;Discover("letter");ReadDocument("陆川的遗书",new[]{WelcomeFacts["letter"].text});return;
  case "hatch":if(!W.maintenanceOpen&&!W.maintenanceAuthorized&&!W.maintenanceCard){Observe("检修口需要有效维护安排。可以借维护卡、完成滤网维护，或申请监督检修。");return;}W.maintenanceOpen=true;W.maintenanceDone=false;Teleport(25.9,5.6,-4.5);Observe("这是本户设备间。每份档案要单独选择、核对用途。");return;
  case "ladder":W.maintenanceDone=true;Teleport(6.45,3,0);return;
  case "panel":ReadArchive("death_log");return;
  case "console":ReadArchive("experiment");return;
  case "printer":ReadArchive("score");return;
  case "pullLamp":ReadArchive("self_file");return;
  case "tools":W.filterMaintained=true;Relationship("vacuum","完成滤网维护",8);Keep("tools","短工具只能用于本户维护，不能直接解除有权限制。");Observe("短工具与滤网维护包。完成维护后，检修安排可以重新核实。");return;
  case "chair":Keep("chair","搬开纸箱并安放椅子，玄关的物理限制仍需分别解除。");Observe("椅子放稳了。它不是绕过钢索授权的万能钥匙。");return;
  case "bed":if(state.day<3){ChangeDay(state.day+1);Observe(state.day==2?"醒来时，滤网维护提醒已经到了。屋里的设备还记得昨天的安排。":"二十二点，自主选择评估开始。选择终止只表示提出申请。");}else{Observe(VisibleReceipt(AdvanceAssessment()));}return;
  case "street":case "call":Observe("玻璃外的城市正常运转。配送、交通和医疗服务都真实存在，公寓外不是可操作场景。");return;
  default:Observe("你留意了一会儿，没有替任何设备作决定。");return;
 }}
 void ReadArchive(string key){if(!W.maintenanceOpen){Observe("需要有效维护窗口，不能直接打开本户档案。");return;}Discover(key);ReadDocument(WelcomeFacts[key].title,new[]{WelcomeFacts[key].text});}
 void ContinueWelcomeLoop(){CloseTalk();state.day=1;state.clock=1060;state.ending="";Mode="play";W.loop++;W.assessmentSteps=0;W.maintenanceDone=false;W.maintenanceOpen=false;W.extension=0;W.releaseOrdered=false;PhoneEvent("继续第 "+W.loop+" 轮；实际保存的证据、关系与损伤保留。");SyncWorld();Save(0);}
}
}
