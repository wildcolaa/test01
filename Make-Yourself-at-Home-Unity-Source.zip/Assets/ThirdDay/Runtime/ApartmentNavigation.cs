using System.Collections.Generic;
using UnityEngine;

namespace ThirdDay
{
    // Same 25 cm walk grid as the HTML, including furniture clearance and diagonal corner checks.
    public sealed class ApartmentNavigation
    {
        readonly GridData g;
        public ApartmentNavigation(GridData data) { g=data; }
        int Index(Vector3 p) { int x=Mathf.FloorToInt((p.x-g.x0)/g.cs),z=Mathf.FloorToInt((-p.z-g.z0)/g.cs);return x<0||z<0||x>=g.nx||z>=g.nz?-1:z*g.nx+x; }
        Vector3 Cell(int n,float y) => new Vector3(g.x0+(n%g.nx+.5f)*g.cs,y,-(g.z0+(n/g.nx+.5f)*g.cs));
        public bool Walkable(Vector3 p) { int n=Index(p);return n>=0&&g.cells[n]==1; }
        public Vector3 Nearest(Vector3 p)
        {
            if(Walkable(p)) return p;
            for(float r=.25f;r<3;r+=.25f) for(int a=0;a<16;a++) { var q=p+new Vector3(Mathf.Cos(a*Mathf.PI/8)*r,0,Mathf.Sin(a*Mathf.PI/8)*r);if(Walkable(q))return q; }
            return p;
        }
        public bool Clear(Vector3 a,Vector3 b)
        {
            int count=Mathf.CeilToInt(Vector3.Distance(a,b)/.1f);
            for(int i=1;i<=count;i++)if(!Walkable(Vector3.Lerp(a,b,(float)i/count)))return false;return true;
        }
        struct Node { public int i; public float f; public Node(int index,float cost){i=index;f=cost;} }
        readonly List<Node> heap=new List<Node>();
        void Push(int i,float f) {heap.Add(new Node(i,f));int n=heap.Count-1;while(n>0){int p=(n-1)/2;if(heap[p].f<=heap[n].f)break;var t=heap[p];heap[p]=heap[n];heap[n]=t;n=p;}}
        int Pop() {int result=heap[0].i;var last=heap[heap.Count-1];heap.RemoveAt(heap.Count-1);if(heap.Count==0)return result;heap[0]=last;int n=0;while(true){int l=n*2+1,r=l+1,m=n;if(l<heap.Count&&heap[l].f<heap[m].f)m=l;if(r<heap.Count&&heap[r].f<heap[m].f)m=r;if(m==n)break;var t=heap[m];heap[m]=heap[n];heap[n]=t;n=m;}return result;}
        public List<Vector3> Path(Vector3 from,Vector3 to)
        {
            from=Nearest(from);to=Nearest(to);int start=Index(from),goal=Index(to);if(start<0||goal<0||!Walkable(to))return null;
            var cost=new float[g.cells.Length];var prev=new int[cost.Length];var closed=new bool[cost.Length];for(int i=0;i<cost.Length;i++){cost[i]=float.MaxValue;prev[i]=-1;}
            heap.Clear();cost[start]=0;Push(start,0);int iterations=0;
            while(heap.Count>0&&iterations++<40000)
            {
                int n=Pop();if(n==goal)break;if(closed[n])continue;closed[n]=true;int x=n%g.nx,z=n/g.nx;
                for(int dz=-1;dz<=1;dz++)for(int dx=-1;dx<=1;dx++)
                {
                    if(dx==0&&dz==0)continue;int xx=x+dx,zz=z+dz;if(xx<0||zz<0||xx>=g.nx||zz>=g.nz)continue;int m=zz*g.nx+xx;
                    if(g.cells[m]==0||closed[m]||(dx!=0&&dz!=0&&(g.cells[z*g.nx+xx]==0||g.cells[zz*g.nx+x]==0)))continue;
                    float c=cost[n]+(dx!=0&&dz!=0?1.414f:1);if(c>=cost[m])continue;cost[m]=c;prev[m]=n;
                    int ax=Mathf.Abs(xx-goal%g.nx),az=Mathf.Abs(zz-goal/g.nx);Push(m,c+ax+az-.586f*Mathf.Min(ax,az));
                }
            }
            if(goal!=start&&prev[goal]<0)return null;var raw=new List<Vector3>();for(int n=goal;n!=start&&n>=0;n=prev[n])raw.Add(Cell(n,from.y));raw.Reverse();raw.Add(to);
            var result=new List<Vector3>();var anchor=from;for(int i=0;i<raw.Count;){int far=i;for(int j=raw.Count-1;j>i;j--)if(Clear(anchor,raw[j])){far=j;break;}result.Add(raw[far]);anchor=raw[far];i=far+1;}return result;
        }
    }
}
