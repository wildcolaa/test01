using UnityEngine;

namespace ThirdDay {
 public partial class ApartmentGame {
  // Five rounded cross sections give the upholstery a compressed edge and a crowned face.
  void Upholstery(int material, Vector3 center, Vector3 size, Quaternion rotation) {
   var batch=propBatches[material];
   int start=batch.vertices.Count;
   const int perimeter=20;
   float radius=Mathf.Min(size.x,size.z)*.21f;
   for(int ring=0;ring<5;ring++){
    float level=ring*.25f;
    float crown=Mathf.Sin(level*Mathf.PI);
    float inset=(1-crown)*radius*.57f;
    for(int corner=0;corner<4;corner++){
     float cx=(corner==0||corner==3?1:-1)*(size.x*.5f-radius);
     float cz=(corner<2?1:-1)*(size.z*.5f-radius);
     for(int step=0;step<5;step++){
      float angle=(corner+step*.25f)*Mathf.PI*.5f;
      Vector3 outward=new Vector3(Mathf.Cos(angle),0,Mathf.Sin(angle));
      Vector3 point=new Vector3(cx,(level-.5f)*size.y,cz)+outward*(radius-inset);
      batch.vertices.Add(center+rotation*point);
      batch.normals.Add(rotation*(outward*(.16f+crown)+Vector3.up*(level-.5f)*2).normalized);
      batch.colors.Add(Color.white);
     }
    }
   }
   for(int ring=0;ring<4;ring++){
    for(int i=0;i<perimeter;i++){
     int a=start+ring*perimeter+i,b=start+ring*perimeter+(i+1)%perimeter;
     batch.indices.AddRange(new[]{a,a+perimeter,b+perimeter,a,b+perimeter,b});
    }
   }
   int tip=batch.vertices.Count;
   batch.vertices.Add(center+rotation*Vector3.up*(size.y*.54f));
   batch.normals.Add(rotation*Vector3.up);
   batch.colors.Add(Color.white);
   int top=start+4*perimeter;
   for(int i=0;i<perimeter;i++)batch.indices.AddRange(new[]{tip,top+(i+1)%perimeter,top+i});
  }

  void ModelDuvet(){
   // Quilt hangs around the foot and both long edges of the mattress.
   var batch=propBatches[0];
   int start=batch.vertices.Count;
   const int rows=18,cols=24;
   Vector3 Surface(float u,float v){
    float x=13.10f+1.62f*u;
    float z=1.02f+2.55f*v;
    float drop=.19f*Mathf.SmoothStep(0,1,Mathf.InverseLerp(.925f,1,u))+.15f*Mathf.SmoothStep(0,1,Mathf.InverseLerp(.89f,1,Mathf.Abs(v*2-1)));
    float fold=Mathf.Sin(v*29+u*4+1.16f*Mathf.Sin(u*6+v*5))*(.013f+.014f*u);
    return new Vector3(x,.755f-drop+fold+.034f*Mathf.Exp(-Mathf.Pow((u-.12f)*15,2)),-z);
   }
   for(int i=0;i<=rows;i++)for(int j=0;j<=cols;j++){
    float u=i/(float)rows,v=j/(float)cols;
    batch.vertices.Add(Surface(u,v));
    batch.normals.Add(Vector3.Cross(Surface(u+.001f,v)-Surface(u-.001f,v),Surface(u,v+.001f)-Surface(u,v-.001f)).normalized);
    batch.colors.Add(Color.white);
    if(i==rows||j==cols)continue;
    int a=start+i*(cols+1)+j,b=a+cols+1;
    batch.indices.AddRange(new[]{a,b,b+1,a,b+1,a+1});
   }
  }

  void ModelApartmentFurniture(){
   for(int i=0;i<3;i++){
    float x=1.477f+1.1f*i;
    Upholstery(0,new Vector3(x,.54f,-10.01f),new Vector3(1.085f,.18f,.62f),Quaternion.identity);
    Upholstery(0,new Vector3(x,.76f,-10.30f),new Vector3(1.085f,.235f,.49f),Quaternion.Euler(-76,0,0));
   }
   Upholstery(0,new Vector3(3.99f,.48f,-8.86f),new Vector3(.84f,.16f,1.64f),Quaternion.identity);
   for(int i=0;i<2;i++)
    Upholstery(5,new Vector3(12.67f,.765f,-1.775f-i),new Vector3(.70f,.22f,.96f),Quaternion.Euler(0,i==0?-4:3,-9));
   ModelDuvet();

   // Inset fronts, pulls on stand-offs, and a bent metal spout at the sink.
   for(int i=0;i<4;i++){
    float x=13.79f+i*1.14f;
    P(1,x,.48f,8.733f,1.10f,.70f,.035f);
    P(0,x-.15f,.71f,8.775f,.028f,.028f,.075f);
    P(0,x+.15f,.71f,8.775f,.028f,.028f,.075f);
    P(0,x,.71f,8.814f,.33f,.032f,.033f);
   }
   C(0,15.5f,.95f,8.16f,.061f,.05f);
   Vector3 pivot=new Vector3(15.5f,1.18f,-8.16f);
   C(0,pivot.x,1.055f,8.16f,.025f,.26f);
   Vector3 last=pivot;
   for(int i=1;i<=8;i++){
    float angle=Mathf.PI*i/8;
    Vector3 end=pivot+new Vector3(0,.13f*Mathf.Sin(angle),-.13f*(1-Mathf.Cos(angle)));
    Vector3 span=end-last,mid=(end+last)*.5f;
    C(0,mid.x,mid.y,-mid.z,.025f,span.magnitude+.005f,Quaternion.FromToRotation(Vector3.up,span));
    last=end;
   }
  }
 }
}
