using System.Collections.Generic;
using UnityEngine;
namespace ThirdDay {
public partial class ApartmentGame {
 readonly System.Random ambientRandom=new System.Random();
 readonly Dictionary<string,bool> ambientInside=new Dictionary<string,bool>();
 readonly Dictionary<string,float> ambientCooldown=new Dictionary<string,float>();
 readonly Dictionary<string,string> ambientRemarks=new Dictionary<string,string>();
 GameState ambientState;int ambientDay;float ambientCheckAt,ambientNextAt;Vector3 ambientPlayer;
 void ResetAmbientPassage(){ambientState=state;ambientDay=state.day;ambientInside.Clear();ambientCooldown.Clear();ambientRemarks.Clear();ambientPlayer=Player.position;ambientCheckAt=Time.time+.25f;ambientNextAt=Time.time+12;}
 void UpdateAmbientDialogue(){
  if(ambientState!=state||ambientDay!=state.day){ResetAmbientPassage();return;}
  if(Time.time<ambientCheckAt)return;ambientCheckAt=Time.time+.25f;
  float travelled=Vector3.Distance(Player.position,ambientPlayer);ambientPlayer=Player.position;
  // Only the player's passage counts: a roaming vacuum must not repeatedly
  // greet a stationary player. Hysteresis rearms only after leaving the area.
  string candidate=null;float nearest=2.7f;
  foreach(var d in Data.devices){
   var position=DevicePosition(d.id);position.y=Player.position.y;
   float distance=Vector3.Distance(Player.position,position);bool inside;ambientInside.TryGetValue(d.id,out inside);
   if(state.floor!=0||distance>3.5f){ambientInside[d.id]=false;continue;}
   if(distance<=2.7f&&!inside){ambientInside[d.id]=true;float ready;ambientCooldown.TryGetValue(d.id,out ready);if(distance<nearest&&Time.time>=ready){candidate=d.id;nearest=distance;}}
  }
  if(candidate==null||travelled<.08f||travelled>2.5f||Mode!="play"||!state.opened||state.floor!=0||TalkingTo!=null||busy||recording||settingsOpen||saveKind!=null||Typing||Time.time<ambientNextAt||Time.time<bubbleUntil+3)return;
  var screen=View.WorldToViewportPoint(DevicePosition(candidate));if(screen.z<=0||screen.x<0||screen.x>1||screen.y<0||screen.y>1)return;
  var approach=new Vector3(devices[candidate].approach[0],0,-devices[candidate].approach[1]);
  if(candidate!="vacuum"&&!Navigation.Clear(Player.position,approach))return;
  if(ambientRandom.NextDouble()>.55)return;
  EmitAmbientRemark(candidate);
 }
 void EmitAmbientRemark(string id){
  var lines=AmbientLines(id);string previous;ambientRemarks.TryGetValue(id,out previous);
  int index=ambientRandom.Next(lines.Length);if(lines.Length>1&&ResidentAddress(lines[index])==previous)index=(index+1)%lines.Length;
  string line=ResidentAddress(lines[index]);ambientRemarks[id]=line;
  Say(id,line);bubbleUntil=Time.time+SpeechSeconds;
  ambientNextAt=Time.time+20+(float)ambientRandom.NextDouble()*15;
  ambientCooldown[id]=Time.time+75+(float)ambientRandom.NextDouble()*35;
  PhoneEvent(DeviceName(id)+"："+line);
 }
 string AmbientMemory(string id){string line;return ambientRemarks.TryGetValue(id,out line)?"你刚才主动对路过的住户说过："+line+"。若住户接着问，记得这是你自己的话。":"";}
 string[] AmbientLines(string id){
  switch(id){
   case "light":return !state.lightsOn?new[]{"脚下慢一点。看不清就叫我。","还没睡？要亮一些就说。"}:new[]{"这边亮度还行吗？","走慢些，门边有个高低差。","看见你过去了。灯先留着。"};
   case "vacuum":return state.cleanRequested?new[]{"这块还没擦完，借过一下。","别急着踩回来，还湿。"}:state.traceCleaned?new[]{"这边干净了，尘盒里的记录没动。","刚擦过，脚下留意。"}:Has("keepTrace")?new[]{"你说留着的那块，我绕开了。","别处照常扫。那块没碰。"}:Trust("vacuum").value<25?new[]{"又一排脚印。行，最后还是我扫。","别堵着路，我还得干活。"}:new[]{"脚抬一下，马上过去。","椅子底下还差一点，别挪它。","这里刚走过，又有灰了。"};
   case "speaker":return state.musicMood==3?new[]{"音乐停了，风声倒更清楚了。","太安静也不习惯。你呢？"}:new[]{"这一段听着还行吗？","脚步声我听见了，不用喊。","要换一段就说，别勉强听。"};
   case "ac":return state.airMode==2?new[]{"风机停着。要送风再说。","没开风，屋里会慢慢闷。"}:state.airMode==1?new[]{"风量小了，讲话不用那么大声。","这个风量，听回声更清楚。"}:new[]{"风口底下别站太久。","你刚走过去，温度还没跟上。","冷了就说，别光把袖子拉下来。"};
   case "fridge":return new[]{"走来走去，不饿吗？","喝点东西？门边有干布，别洒地上。","想拿什么，先说一声。"};
   case "waterer":return state.waterStop?new[]{"水停着呢，这回记的是你的决定。","今天没再滴。盆底也留意一下。"}:new[]{"托盘里还有水，走路别碰翻了。","啾啾说的，我这回不直接照做。","别拿脚尖拨叶子。会折。"};
   case "mirror":return new[]{"路过不用看屏幕，照常用就行。","私人影像我不会交出去。","你要问什么，可以到跟前说。"};
   case "lock":return W.unlocked?new[]{"锁舌已经退了，别再硬压。","门边慢一点，椅子容易磕。"}:state.day==3?new[]{"别急着拽把手。受力我听得出来。","人在门边，和凭据有效，是两回事。"}:new[]{"门边别堆东西。","又走到门口了。有什么要核实？","关门时看着椅腿，别夹住。"};
   case "tv":return television=="raw"?new[]{"原始版本还在，没有再剪。","那几行字，我没换成摘要。"}:television=="forecast"?new[]{"配送公告刚更新。","外面的交通照常运行。"}:new[]{"不看屏幕也能跟我说话。","屏幕上是今天的接驳安排。","配餐和社区诊疗的消息刚更新。","你走过去了，声音要小些吗？"};
   default:return state.day==3?new[]{"居住服务仍在运行。","你可以随时提出复核。"}:new[]{"还在熟悉房间？","通勤和配餐都排好了，先把东西放下。","生活适应需要一点时间。","需要的时候，家会提醒你。"};
  }
 }
}
}
