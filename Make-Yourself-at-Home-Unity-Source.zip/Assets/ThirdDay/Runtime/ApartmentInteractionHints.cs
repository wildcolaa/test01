using System.Collections.Generic;
using UnityEngine;

namespace ThirdDay
{
    public partial class ApartmentGame
    {
        RectTransform hintRoot;
        readonly Dictionary<string,RectTransform> interactionHints = new Dictionary<string,RectTransform>();
        void UpdateInteractionHints()
        {
            if (!hintRoot) { hintRoot=Node(uiRoot,"Nearby interaction lights",new Rect(0,0,Width,Height));hintRoot.SetAsFirstSibling(); }
            bool show=Mode=="play"&&!settingsOpen&&saveKind==null;
            hintRoot.gameObject.SetActive(show);if(!show)return;
            foreach(var item in Data.objects)
            {
                var approach=new Vector3(item.approach[0],item.floor,-item.approach[1]);
                bool near=Mathf.Abs(state.floor-item.floor)<.1f&&Vector3.Distance(Player.position,approach)<1.4f;
                SetInteractionHint("object:"+item.id,ApartmentCoordinates.World(item.position)+Vector3.up*.12f,near);
            }
            foreach(var device in Data.devices)
                SetInteractionHint("device:"+device.id,DevicePosition(device.id)+Vector3.up*.25f,InRange(device.id));
        }
        void SetInteractionHint(string id,Vector3 world,bool show)
        {
            RectTransform marker;
            if(!interactionHints.TryGetValue(id,out marker))
            {
                if(!show)return;
                marker=Panel(hintRoot,new Rect(0,0,22,22),new Color32(238,241,246,245),id,ApartmentGraphic.Shape.LightPoint).rectTransform;
                marker.gameObject.AddComponent<CanvasGroup>().blocksRaycasts=false;interactionHints[id]=marker;
            }
            var position=View.WorldToScreenPoint(world);
            show&=position.z>0&&position.x>0&&position.x<Screen.width&&position.y>0&&position.y<Screen.height;
            marker.gameObject.SetActive(show);if(!show)return;
            Place(marker,new Rect(position.x/UIScale-11,Height-position.y/UIScale-11,22,22));
            marker.GetComponent<CanvasGroup>().alpha=.72f+.28f*Mathf.Sin(Time.unscaledTime*2.6f);
        }
    }
}
