using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ThirdDay
{
    public partial class ApartmentGame
    {
        float screenTime; readonly Dictionary<string,Texture2D> screens=new Dictionary<string,Texture2D>();
        readonly Dictionary<string,TextMesh> screenLabels=new Dictionary<string,TextMesh>();
        readonly Dictionary<string,Color32[]> screenPixels=new Dictionary<string,Color32[]>();
        readonly List<ParticleSystem> waterParticles=new List<ParticleSystem>();
        bool atmosphereReady;
        void AnimateHouse(float dt)
        {
            if(!atmosphereReady){CreateAtmosphere();atmosphereReady=true;}
            UpdateUtopiaDressing();float t=Time.time;var vac=parts["Vacuum"];
            if(!state.cleanRequested&&(vacuumPath==null||vacuumPath.Count==0)){var target=Navigation.Nearest(new Vector3(Random.Range(.5f,17.5f),0,-Random.Range(.5f,12.5f)));vacuumPath=Navigation.Path(vac.position,target);}
            if(state.welcome.vacuumDamage<2)Follow(vac,ref vacuumPath,.48f,dt);parts["SideBrush"].Rotate(Vector3.up,dt*1375,Space.Self);
            float scan=t%1.8f;parts["ScanRing"].localScale=Vector3.one*(1+scan*.6f);
            Opacity(parts["ScanRing"],.35f*(1-scan/1.8f));
            float beatLength=60f/(86*Mathf.Max(.1f,soundtrack.pitch));float beat=muted||state.musicMood==3?0:Mathf.Exp(-(t%beatLength)/beatLength*9);
            parts["SpeakerPulse"].localScale=Vector3.one*(1+beat*.18f);
            for(int i=0;i<3;i++){float k=(t*.65f+i/3f)%1;parts["SoundWave"+i].localScale=Vector3.one*(1+k*5);Opacity(parts["SoundWave"+i],(1-k)*(.15f+beat*.35f));}
            parts["ACVane"].localRotation=Quaternion.Euler(state.airMode==2?0:Mathf.Sin(t*(state.airMode==3?1.3f:.8f))*10,0,0);
            LEDGlow(parts["LockLED"],new Color(.5f,1,.68f),.45f+.55f*Mathf.Pow(Mathf.Max(0,Mathf.Sin(t*5)),6));
            LEDGlow(parts["VacuumLED"],Color.white,.5f+.5f*Mathf.Pow(Mathf.Sin(t*2),2));
            var bath=transform.Find("Bathroom");if(bath)bath.GetComponent<Light>().intensity=(state.day==3?2.2f:1.4f)*(1+.08f*Mathf.Sin(t*2));
            foreach(var p in parts)if(p.Key.Contains("Curtain"))p.Value.localRotation=Quaternion.Euler(0,p.Key.StartsWith("Living")?-90:0,Mathf.Sin(t*.9f+p.Key.Length)*.7f);
            for(int i=0;i<4;i++)parts["Aircraft"+i].position=new Vector3(((t*(.6f+i*.17f)+i*9)%38)-10,3.5f+i*.8f,3+i*2);
            foreach(var l in houseLights)if(state.lightsOn&&!state.lightAuto)l.intensity=1.5f*state.lightLevel*(1+.025f*Mathf.Sin(t*2+l.transform.position.x));
            foreach(var p in waterParticles){var em=p.emission;em.enabled=!state.waterStop||state.welcome.pumpRunning;}
            if(parts.ContainsKey("FloorTrace"))Opacity(parts["FloorTrace"],state.traceLit?.85f:.3f);
            var airflow=transform.Find("Airflow");if(airflow){var em=airflow.GetComponent<ParticleSystem>().emission;em.rateOverTime=state.airMode==2?0:state.airMode==1?3:state.airMode==3?24:12;}
            if(t-screenTime>.4f){screenTime=t;UpdateScreens(false);}
        }
        static readonly int ColorProperty=Shader.PropertyToID("_BaseColor");
        MaterialPropertyBlock propertyBlock;
        void Opacity(Transform root,float alpha)
        {
            if(propertyBlock==null)propertyBlock=new MaterialPropertyBlock();
            foreach(var r in root.GetComponentsInChildren<MeshRenderer>()){r.GetPropertyBlock(propertyBlock);Color c=r.sharedMaterial.HasProperty(ColorProperty)?r.sharedMaterial.GetColor(ColorProperty):Color.white;c.a=alpha;propertyBlock.SetColor(ColorProperty,c);r.SetPropertyBlock(propertyBlock);}
        }
        void LEDGlow(Transform root,Color color,float strength)
        {
            if(propertyBlock==null)propertyBlock=new MaterialPropertyBlock();foreach(var r in root.GetComponentsInChildren<MeshRenderer>()){r.GetPropertyBlock(propertyBlock);propertyBlock.SetColor(ColorProperty,new Color(color.r*strength,color.g*strength,color.b*strength,1));r.SetPropertyBlock(propertyBlock);}
        }
        void CreateAtmosphere()
        {
            gameObject.AddComponent<ApartmentCityRain>().Initialize(View);
            MakeParticles("WindowDust",new Vector3(.7f,1.2f,-9),new Vector3(.4f,.8f,2.8f),5,.015f,6,.03f,new Color(.8f,.86f,1,.25f));
            MakeParticles("VacuumDust",new Vector3(0,.06f,0),new Vector3(.25f,.015f,.25f),9,.013f,.8f,.06f,new Color(.75f,.8f,.85f,.2f),parts["Vacuum"]);
            MakeParticles("Airflow",new Vector3(1.8f,2.4f,-4.9f),new Vector3(.7f,.03f,.015f),12,.009f,1.8f,.25f,new Color(.7f,.85f,1,.22f),null,new Vector3(0,-.2f,-.18f));
            waterParticles.Add(MakeParticles("WaterDrops",new Vector3(-1.9f,.65f,-10.75f),new Vector3(.02f,.01f,.02f),.5f,.028f,.35f,.3f,new Color(.6f,.8f,1,.7f),null,new Vector3(0,-.8f,0)));
            foreach(var id in new[]{"TVScreen","FridgeScreen","HubScreen"})
            {
                var texture=new Texture2D(256,128,TextureFormat.RGBA32,false);texture.name=id+" Live Display";texture.filterMode=FilterMode.Bilinear;screens[id]=texture;screenPixels[id]=new Color32[256*128];
                foreach(var r in parts[id].GetComponentsInChildren<MeshRenderer>()){var m=r.material;m.SetTexture("_BaseMap",texture);m.SetColor("_BaseColor",Color.white);}
                var go=new GameObject("Live text");go.transform.SetParent(parts[id],false);go.transform.localPosition=new Vector3(id=="TVScreen"?-.95f:-.18f,id=="TVScreen"?.38f:.18f,-.01f);go.transform.localRotation=Quaternion.Euler(0,180,0);
                var text=go.AddComponent<TextMesh>();text.font=chineseFont;text.fontSize=48;text.characterSize=id=="TVScreen"?.037f:.012f;text.anchor=TextAnchor.UpperRight;text.color=new Color(.78f,.86f,.9f);go.GetComponent<MeshRenderer>().sharedMaterial=chineseFont.material;screenLabels[id]=text;
            }
            UpdateScreens(true);
        }
        ParticleSystem MakeParticles(string name,Vector3 position,Vector3 box,float rate,float size,float life,float speed,Color color,Transform parent=null,Vector3? velocity=null)
        {
            var go=new GameObject(name);go.transform.SetParent(parent?parent:transform,false);go.transform.localPosition=position;var ps=go.AddComponent<ParticleSystem>();var main=ps.main;main.startLifetime=life;main.startSize=size;main.startSpeed=speed;main.startColor=color;main.maxParticles=90;main.simulationSpace=ParticleSystemSimulationSpace.World;var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Box;shape.scale=box;var emission=ps.emission;emission.rateOverTime=rate;
            if(velocity.HasValue){var v=ps.velocityOverLifetime;v.enabled=true;v.x=velocity.Value.x;v.y=velocity.Value.y;v.z=velocity.Value.z;}
            var renderer=go.GetComponent<ParticleSystemRenderer>();var shader=Shader.Find("Universal Render Pipeline/Particles/Unlit");if(shader){var m=new Material(shader);m.SetFloat("_Surface",1);m.SetFloat("_ZWrite",0);m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");m.renderQueue=3000;renderer.sharedMaterial=m;}renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;return ps;
        }
        void UpdateScreens(bool force)
        {
            if(!atmosphereReady&&screens.Count==0)return;
            foreach(var item in screens)
            {
                var pixels=screenPixels[item.Key];int sweep=(int)(Time.time*25)%256;
                for(int y=0;y<128;y++)for(int x=0;x<256;x++)
                {
                    byte light=(byte)(item.Key=="TVScreen"&&television=="off"?8:20);if(y<10)light=38;if(x>sweep&&x<sweep+12)light+=8;if(item.Key!="TVScreen"&&y%22<2&&x>16&&x<220-(y%31))light=62;
                    pixels[y*256+x]=new Color32(light,(byte)(light+3),(byte)(light+6),255);
                }
                item.Value.SetPixels32(pixels);item.Value.Apply(false);
            }
            if(screenLabels.TryGetValue("TVScreen",out var tv))tv.text=television=="raw"?"材料来源核对\n独立来源："+IndependentSources():UtopiaCityNews();
            if(screenLabels.TryGetValue("FridgeScreen",out var fridge))fridge.text="库存已刷新\n"+Clock()+"\n一人份";
            if(screenLabels.TryGetValue("HubScreen",out var hub))hub.text="居住服务\n"+Clock()+"\n"+(state.welcome.hubRevoked?"独立接管已锁定":"适应期评估");
        }
    }
}
