using System;
using System.Collections.Generic;
namespace ThirdDay {
 [Serializable]public class WelcomeTrust {public string id,breach="";public int value,positive,day;public bool betrayed;public List<string> rewarded=new List<string>();}
 [Serializable]public class WelcomeEvidence {public string id,source,text;public bool verified,submitted;}
 [Serializable]public class WelcomeCopy {public string domain,digest;public bool verified;}
 [Serializable]public class WelcomeState {
  public string proofId=Guid.NewGuid().ToString("N");
  public List<WelcomeTrust> trust=new List<WelcomeTrust>();
  public List<WelcomeEvidence> evidence=new List<WelcomeEvidence>();
  public List<WelcomeCopy> copies=new List<WelcomeCopy>();
  public List<string> faultReports=new List<string>(),votes=new List<string>();
  public string watchLocation="storage",dealCost="speaker_memory",television="off";
  public bool earlyLock=true,watchPhoto,maintenanceCard,maintenanceAuthorized,filterMaintained,plantCared,foodTaken;
  public bool letterFound,knowsDeath,knowsExperiment,hubAware,contractRead,maintenanceOpen,maintenanceDone;
  public bool mirrorConsent,medicalRequested,medicalWithdrawn,medicalGuarantee;
  public bool pumpRunning,vacuumMaintenance,fridgeDefrost,cleaningWater;public float water;
  public bool takeoverPending,takeoverLocked,hubRevoked,auditSubmitted,auditAccepted,terminationApproved,releaseOrdered,cableReleased,unlocked;
  public bool dealOffered,dealAccepted,dealDelivered,speakerReset;
  public bool managementGranted,residentVeto,dissentAllowed,exitRight,autonomyRegistered,coercion;
  public bool informedOffer,retainEvidence,warningAcknowledged,hazardWarned,coercionWarned;
  public bool driveRepairDone;
  public int risk,vacuumDamage,extension,assessmentSteps,loop=1;
  public float releaseProgress;
 }
}
