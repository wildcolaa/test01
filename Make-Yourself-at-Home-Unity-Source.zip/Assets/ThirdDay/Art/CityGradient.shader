Shader "ThirdDay/CityGradient"
{
    Properties { _PaperGrain("Paper fibres", 2D)="white" {}
        _BaseColor("Color",Color)=(0.35,0.36,0.4,1) }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
        Pass
        {
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #pragma shader_feature_local_fragment _ CITY_PRINT_GRAIN
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            struct Attributes { float4 positionOS:POSITION; half4 color:COLOR; };
            struct Varyings { float4 positionCS:SV_POSITION; half4 color:COLOR; half fog:TEXCOORD0; };
            TEXTURE2D(_PaperGrain); SAMPLER(sampler_PaperGrain);
            CBUFFER_START(UnityPerMaterial)
            half4 _BaseColor;
            CBUFFER_END
            Varyings vert(Attributes v) { Varyings o;o.positionCS=TransformObjectToHClip(v.positionOS.xyz);o.color=v.color*_BaseColor;o.fog=ComputeFogFactor(o.positionCS.z);return o; }
            half4 frag(Varyings i):SV_Target { half3 color=MixFog(i.color.rgb,i.fog);
                #if defined(CITY_PRINT_GRAIN)
                    float2 uv=i.positionCS.xy / (_ScaledScreenParams.y * (640.0 / 675.0));
                    half4 grain=SAMPLE_TEXTURE2D(_PaperGrain,sampler_PaperGrain,uv);
                    color=lerp(color,grain.rgb,grain.a*.30h);
                #endif
                return half4(color,1); }
            ENDHLSL
        }
    }
}
